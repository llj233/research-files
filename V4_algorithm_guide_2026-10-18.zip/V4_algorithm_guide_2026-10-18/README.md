# V4 整体算法架构与实现详解

- 主文档：`V4_algorithm_architecture_detailed_2026-10-18.pdf`，31页、29节，有目录和书签，中文和英文字体已嵌入。
- 可编辑正文：同名 `.md`。
- 生成源码：`build_guide.py`；使用ReportLab、fontTools，以及系统DroidSansFallback与DejaVu字体。
- `DOCUMENT_MANIFEST.json` 记录依据的冻结版本和源码哈希；`DOCUMENT_QUALITY_CHECK.json` 记录文档检查。
- `current_test/`、`current_test_summary.csv` 为本次独立测试结果、地图、配置和日志，不并入原四组验收。

本次地图/策略种子为484794/677270，探索率96.99755%、ROI97.99519%，574秒成功返回部署点，位置误差0.157094米，36次记录的导航结果全部成功。

文档忠实于当前冻结单机版；双机保留模块、信息收益代理与严格主动SLAM、Q-learning和启发式评分均明确区分。本配套文档没有修改原V4冻结ZIP。
