# V4 主动 SLAM 探索系统：整体算法架构与实现详解

生成时间：2026-10-18 18:11:45（北京时间）。以冻结单机版实际源码为准。

## 01 版本定位：当前 V4 到底是什么

本手册以已经冻结、可上传 GitHub 的 V4_optimized_frozen_2026-10-18 为准。依据是运行源码、生成参数、四组预注册验收数据和一组独立随机补充数据；不是把 V4 方案书中的全部构想当作已经完成。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">问题</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='问题', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 113.81889763779529
'_wrapWidths': [113.81889763779529, 113.81889763779529]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(96.81889763779529, ['问题'])], link=[], rise=0, text='问题', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前代码的答案</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前代码的答案', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 365.45669291338584
'_wrapWidths': [365.45669291338584, 365.45669291338584]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(305.95669291338584, ['当前代码的答案'])], link=[], rise=0, text='当前代码的答案', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是否单机？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否单机？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 113.81889763779529
'_wrapWidths': [113.81889763779529, 113.81889763779529]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(71.31889763779529, ['是否单机？'])], link=[], rise=0, text='是否单机？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是。运行器、命令行和 </font><font name="Latin">launch</font><font name="CN"> 均拒绝非 </font><font name="Latin">single</font><font name="CN"> 模式，在线仅 </font><font name="Latin">robot1</font><font name="CN">。</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是。运行器、命令行和 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='launch', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 均拒绝非 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='single', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 模式，在线仅 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot1', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 365.45669291338584
'_wrapWidths': [365.45669291338584, 365.45669291338584]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=271.223876953125, descent=-2.0419921875, extraSpace=94.23281596026084, fontSize=8.5, kind=1, lineBreak=False, maxWidth=365.45669291338584, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是。运行器、命令行和 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='launch', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 均拒绝非 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='single', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 模式，在线仅 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot1', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是否使用 </font><font name="Latin">SLAM</font><font name="CN">？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否使用 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 113.81889763779529
'_wrapWidths': [113.81889763779529, 113.81889763779529]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=68.004150390625, descent=-2.0419921875, extraSpace=45.81474724717029, fontSize=8.5, kind=1, lineBreak=False, maxWidth=113.81889763779529, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否使用 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是。</font><font name="Latin">slam_toolbox</font><font name="CN"> 将激光、里程计</font><font name="Latin">/TF</font><font name="CN">组织成在线占据栅格地图。</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是。', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='slam_toolbox', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 将激光、里程计', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='组织成在线占据栅格地图。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 365.45669291338584
'_wrapWidths': [365.45669291338584, 365.45669291338584]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=249.919921875, descent=-2.0419921875, extraSpace=115.53677103838584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=365.45669291338584, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是。', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='slam_toolbox', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 将激光、里程计', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='组织成在线占据栅格地图。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是否主动选择探索目标？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否主动选择探索目标？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 113.81889763779529
'_wrapWidths': [113.81889763779529, 113.81889763779529]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(20.31889763779529, ['是否主动选择探索目标？'])], link=[], rise=0, text='是否主动选择探索目标？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是。程序依据地图中的未知边界、可见性代理和导航成本自主选取下一观测位姿。</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是。程序依据地图中的未知边界、可见性代理和导航成本自主选取下一观测位姿。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 365.45669291338584
'_wrapWidths': [365.45669291338584, 365.45669291338584]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(59.45669291338584, ['是。程序依据地图中的未知边界、可见性代理和导航成本自主选取下一观测位姿。'])], link=[], rise=0, text='是。程序依据地图中的未知边界、可见性代理和导航成本自主选取下一观测位姿。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是否强化学习？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否强化学习？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 113.81889763779529
'_wrapWidths': [113.81889763779529, 113.81889763779529]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(54.31889763779529, ['是否强化学习？'])], link=[], rise=0, text='是否强化学习？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前这版不是 </font><font name="Latin">Q-learning/DQN/PPO</font><font name="CN"> 训练器。没有 </font><font name="Latin">Q</font><font name="CN"> 表加载</font><font name="Latin">/</font><font name="CN">更新或策略网络训练；启发式得分不等于强化学习奖励。</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前这版不是 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Q-learning/DQN/PPO', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 训练器。没有 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Q', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 表加载', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='更新或策略网络训练；启发式得分不等于强化学习奖励。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 365.45669291338584
'_wrapWidths': [365.45669291338584, 365.45669291338584]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=368.799560546875, descent=-2.0419921875, extraSpace=5.157132366510837, fontSize=8.5, kind=1, lineBreak=False, maxWidth=365.45669291338584, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前这版不是 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Q-learning/DQN/PPO', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 训练器。没有 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Q', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 表加载', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='更新或策略网络训练；启发式得分', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=85.0, descent=-2.025390625, extraSpace=280.45669291338584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=365.45669291338584, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不等于强化学习奖励。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是否严格的信息论主动 </font><font name="Latin">SLAM</font><font name="CN">？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否严格的信息论主动 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 113.81889763779529
'_wrapWidths': [113.81889763779529, 113.81889763779529]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=119.004150390625, descent=-2.0419921875, extraSpace=3.3147472471702883, fontSize=8.5, kind=1, lineBreak=False, maxWidth=113.81889763779529, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否严格的信息论主动 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=8.5, descent=-2.025390625, extraSpace=105.31889763779529, fontSize=8.5, kind=1, lineBreak=False, maxWidth=113.81889763779529, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">不是联合优化地图熵、定位协方差和闭环收益的完整算法。本版属于基于 </font><font name="Latin">SLAM</font><font name="CN"> 的主动建图探索。</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不是联合优化地图熵、定位协方差和闭环收益的完整算法。本版属于基于 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 的主动建图探索。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 365.45669291338584
'_wrapWidths': [365.45669291338584, 365.45669291338584]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=367.728759765625, descent=-2.0419921875, extraSpace=-2.2720668522391634, fontSize=8.5, kind=1, lineBreak=False, maxWidth=365.45669291338584, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不是联合优化地图熵、定位协方差和闭环收益的完整算法。本版属于基于 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 的主动建图探索。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是否已验收双机？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否已验收双机？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 113.81889763779529
'_wrapWidths': [113.81889763779529, 113.81889763779529]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(45.81889763779529, ['是否已验收双机？'])], link=[], rise=0, text='是否已验收双机？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前发布只验收单机。代码保留融合</font><font name="Latin">/</font><font name="CN">分配组件，但双机实时执行被入口禁用。</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前发布只验收单机。代码保留融合', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分配组件，但双机实时执行被入口禁用。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 365.45669291338584
'_wrapWidths': [365.45669291338584, 365.45669291338584]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=291.86376953125, descent=-2.0419921875, extraSpace=73.59292338213584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=365.45669291338584, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前发布只验收单机。代码保留融合', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分配组件，但双机实时执行被入口禁用。', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

建议论文或答辩名称：基于 SLAM 地图与前沿安全观测位姿的自主探索及可靠返航系统。可称“启发式主动 SLAM 探索框架”，同时说明信息收益是代理指标、当前没有主动定位不确定性目标。

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:81 [TestExecutor]

代码依据：scripts/run_test.py:138 [main]

## 02 全局架构：探索与评估两条链

【PDF中为可选中文字的矢量结构图】

左侧是在线自主探索闭环；右侧是独立实验评估与任务阶段控制。评估器只传覆盖率/是否达标，不把未知几何给候选选择。返航同样交给Nav2执行，但目标依据真实部署记录和当前动态TF计算。

探索器只读 SLAM 地图、位姿、传感器与 Nav2 接口。独立评估器读取预先固定的世界几何，计算覆盖率，并把“是否达到返航门槛”交给状态机。它不把未知障碍的位置交给目标评分。场景审计插件读取实际模型位姿，只用于验证评估真值一致性。

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:342 [on_evaluation]

代码依据：src/v4_evaluator/v4_evaluator/node.py:16 [EvaluatorNode]

## 03 ROS 节点与话题：模块怎样接起来

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">数据 </font><font name="Latin">/</font><font name="CN"> 接口</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='数据 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 接口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=41.31298828125, descent=-2.0419921875, extraSpace=108.45416582448681, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='数据 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 接口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">发布方 </font><font name="Latin">→</font><font name="CN"> 使用方</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='发布方 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 使用方', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=62.5712890625, descent=-2.0419921875, extraSpace=87.19586504323681, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='发布方 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 使用方', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">作用</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='作用', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(150.74128233970754, ['作用'])], link=[], rise=0, text='作用', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/robot1/scan</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/robot1/scan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(96.31012285573681, ['/robot1/scan'])], link=[], rise=0, text='/robot1/scan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Gazebo</font><font name="CN"> 激光 </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">SLAM</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> 安全门 </font><font name="Latin">/</font><font name="CN"> 监督器</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 激光 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 安全门 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 监督器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=151.783935546875, descent=-2.0419921875, extraSpace=6.483218558861807, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 激光 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 安全门 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=8.5, descent=-2.025390625, extraSpace=141.2671541057368, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">LaserScan</font><font name="CN">，</font><font name="Latin">180</font><font name="CN">束、</font><font name="Latin">3Hz</font><font name="CN">、最大</font><font name="Latin">10m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='LaserScan', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='180', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='束、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、最大', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=146.3427734375, descent=-2.0419921875, extraSpace=21.39850890220754, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='LaserScan', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='180', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='束、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、最大', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/robot1/odom</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/robot1/odom', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(91.93146074636181, ['/robot1/odom'])], link=[], rise=0, text='/robot1/odom', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">差速驱动 </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">TF</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> 导航 </font><font name="Latin">/</font><font name="CN"> 监督器</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='差速驱动 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 导航 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 监督器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=112.778564453125, descent=-2.0419921875, extraSpace=36.98858965261181, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='差速驱动 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 导航 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 监督器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Odometry</font><font name="CN">；本仿真使用 </font><font name="Latin">WORLD</font><font name="CN"> 来源</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Odometry', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；本仿真使用 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='WORLD', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 来源', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=147.384521484375, descent=-2.0419921875, extraSpace=20.35676085533254, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Odometry', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；本仿真使用 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='WORLD', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 来源', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/robot1/map</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/robot1/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(97.12359941823681, ['/robot1/map'])], link=[], rise=0, text='/robot1/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">slam_toolbox</font><font name="CN"> </font><font name="Latin">→</font><font name="CN"> 探索监督器 </font><font name="Latin">/</font><font name="CN"> 静态层</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='slam_toolbox', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 探索监督器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 静态层', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=143.134521484375, descent=-2.0419921875, extraSpace=6.632632621361807, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='slam_toolbox', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 探索监督器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 静态层', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">OccupancyGrid</font><font name="CN">，地图分辨率</font><font name="Latin">0.1m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='OccupancyGrid', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，地图分辨率', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.1m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=137.755615234375, descent=-2.0419921875, extraSpace=29.98566710533254, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='OccupancyGrid', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，地图分辨率', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.1m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/map</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(128.0191072307368, ['/map'])], link=[], rise=0, text='/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">探索监督器 </font><font name="Latin">→</font><font name="CN"> 独立评估器</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索监督器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 独立评估器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=96.5712890625, descent=-2.0419921875, extraSpace=53.19586504323681, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索监督器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 独立评估器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">单机为地图转发，不是双机融合结果</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='单机为地图转发，不是双机融合结果', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(31.74128233970754, ['单机为地图转发，不是双机融合结果'])], link=[], rise=0, text='单机为地图转发，不是双机融合结果', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/robot1/compute_path_to_pose</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/robot1/compute_path_to_pose', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(17.647769340111807, ['/robot1/compute_path_to_pose'])], link=[], rise=0, text='/robot1/compute_path_to_pose', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">探索器 </font><font name="Latin">↔</font><font name="CN"> </font><font name="Latin">Nav2</font><font name="CN"> 规划器</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='↔', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 规划器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=86.80126953125, descent=-2.0419921875, extraSpace=62.96588457448681, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='↔', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 规划器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">ComputePathToPose</font><font name="CN"> 动作，返回路径长度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ComputePathToPose', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 动作，返回路径长度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=166.916259765625, descent=-2.0419921875, extraSpace=0.8250225740825385, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ComputePathToPose', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 动作，返回路径长度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/robot1/navigate_to_pose</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/robot1/navigate_to_pose', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(41.56647051198681, ['/robot1/navigate_to_pose'])], link=[], rise=0, text='/robot1/navigate_to_pose', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">监督器 </font><font name="Latin">↔</font><font name="CN"> </font><font name="Latin">bt_navigator</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='监督器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='↔', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='bt_navigator', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=90.66943359375, descent=-2.0419921875, extraSpace=59.09772051198681, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='监督器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='↔', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='bt_navigator', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">NavigateToPose</font><font name="CN"> 动作，执行目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavigateToPose', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 动作，执行目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=130.226806640625, descent=-2.0419921875, extraSpace=37.51447569908254, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavigateToPose', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 动作，执行目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">cmd_vel_nav</font><font name="CN"> </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">cmd_vel_unchecked</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel_nav', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel_unchecked', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=152.423095703125, descent=-2.0419921875, extraSpace=2.7395662151118074, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel_nav', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel_unchecke', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=5.3955078125, descent=-2.0419921875, extraSpace=144.3716462932368, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='d', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">控制器 </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">velocity_smoother</font><font name="CN"> </font><font name="Latin">→</font><font name="CN"> 安全门</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='控制器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='velocity_smoother', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 安全门', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=152.165771484375, descent=-2.0419921875, extraSpace=6.101382621361807, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='控制器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='velocity_smoother', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 安全', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=8.5, descent=-2.025390625, extraSpace=141.2671541057368, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='门', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">导航速度先平滑，再进行最终激光过滤</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='导航速度先平滑，再进行最终激光过滤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(23.24128233970754, ['导航速度先平滑，再进行最终激光过滤'])], link=[], rise=0, text='导航速度先平滑，再进行最终激光过滤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">cmd_vel_recovery</font><font name="CN"> </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">cmd_vel</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel_recovery', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=123.644287109375, descent=-2.0419921875, extraSpace=26.122866996361807, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel_recovery', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='cmd_vel', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">behavior_server</font><font name="CN"> </font><font name="Latin">→</font><font name="CN"> 安全门 </font><font name="Latin">→</font><font name="CN"> 驱动</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='behavior_server', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 安全门 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 驱动', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=134.107421875, descent=-2.0419921875, extraSpace=15.659732230736807, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='behavior_server', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 安全门 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 驱动', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">新鲜恢复指令优先；安全门统一输出</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='新鲜恢复指令优先；安全门统一输出', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(31.74128233970754, ['新鲜恢复指令优先；安全门统一输出'])], link=[], rise=0, text='新鲜恢复指令优先；安全门统一输出', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/v4/evaluation</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/v4/evaluation', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(88.89337480886181, ['/v4/evaluation'])], link=[], rise=0, text='/v4/evaluation', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">独立评估器 </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">Mission</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='独立评估器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Mission', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=85.57275390625, descent=-2.0419921875, extraSpace=64.19440019948681, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='独立评估器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Mission', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">JSON</font><font name="CN"> 指标和 </font><font name="Latin">coverage_passed</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='JSON', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 指标和 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='coverage_passed', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=124.698486328125, descent=-2.0419921875, extraSpace=43.04279601158254, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='JSON', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 指标和 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='coverage_passed', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">/tf</font><font name="CN">、</font><font name="Latin">/tf_static</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/tf', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/tf_static', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=54.465576171875, descent=-2.0419921875, extraSpace=95.30157793386181, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/tf', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/tf_static', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SLAM</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> 驱动 </font><font name="Latin">/</font><font name="CN"> 静态发布器 </font><font name="Latin">→</font><font name="CN"> 多个消费者</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 驱动 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 静态发布器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 多个消费者', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 149.7671541057368
'_wrapWidths': [149.7671541057368, 149.7671541057368]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=151.476806640625, descent=-2.0419921875, extraSpace=6.790347465111807, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 驱动 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 静态发布器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 多个消费', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=8.5, descent=-2.025390625, extraSpace=141.2671541057368, fontSize=8.5, kind=1, lineBreak=False, maxWidth=149.7671541057368, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='者', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">坐标转换；动态 </font><font name="Latin">map→odom</font><font name="CN"> 与固定机体外参分工不同</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='坐标转换；动态 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='map→odom', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 与固定机体外参分工不同', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=173.531982421875, descent=-2.0419921875, extraSpace=2.7092999178325385, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='坐标转换；动态 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='map→odom', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 与固定机体外', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=42.5, descent=-2.025390625, extraSpace=125.24128233970754, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='参分工不同', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

探索器没有直接常态输出行驶速度。它发的是目标位姿；真正的连续速度由 Nav2 产生，最终只由 SafetyNode 写到机器人 cmd_vel。/robot1/plan 是规划器路径，而 Humble RPP 的 received_global_plan 在本实现中是已经变换后的路径；不能只凭话题名字判断坐标系。

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:82 [__init__]

代码依据：src/active_slam_v4/active_slam_v4/safety_node.py:16 [SafetyNode]

## 04 坐标与部署点：为什么返航不能只记一个 map 点

坐标链：公共 map → robot1/map → robot1/odom → robot1/base_footprint → base_link / base_scan。公共 map 到 robot1/map 在这个已知坐标对齐的单机仿真中用单位静态关系；robot1/map 到 robot1/odom 由 SLAM 动态发布。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">坐标系</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='坐标系', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176608
'_wrapWidths': [131.79302587176608, 131.79302587176608]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(106.29302587176608, ['坐标系'])], link=[], rise=0, text='坐标系', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">含义</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='含义', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.7585301837271
'_wrapWidths': [155.7585301837271, 155.7585301837271]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(138.7585301837271, ['含义'])], link=[], rise=0, text='含义', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">本版用途</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='本版用途', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 179.7240344956881
'_wrapWidths': [179.7240344956881, 179.7240344956881]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(145.7240344956881, ['本版用途'])], link=[], rise=0, text='本版用途', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">map</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">robot1/map</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='map', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot1/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176608
'_wrapWidths': [131.79302587176608, 131.79302587176608]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=75.97705078125, descent=-2.0419921875, extraSpace=55.815975090516076, fontSize=8.5, kind=1, lineBreak=False, maxWidth=131.79302587176608, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='map', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot1/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SLAM</font><font name="CN"> 的全局参考，可随估计修正</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 的全局参考，可随估计修正', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.7585301837271
'_wrapWidths': [155.7585301837271, 155.7585301837271]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=127.504150390625, descent=-2.0419921875, extraSpace=28.25437979310209, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.7585301837271, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 的全局参考，可随估计修正', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">frontier</font><font name="CN">、</font><font name="Latin">Nav2</font><font name="CN"> 目标、覆盖率地图</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 目标、覆盖率地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 179.7240344956881
'_wrapWidths': [179.7240344956881, 179.7240344956881]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=132.22314453125, descent=-2.0419921875, extraSpace=47.5008899644381, fontSize=8.5, kind=1, lineBreak=False, maxWidth=179.7240344956881, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 目标、覆盖率地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">robot1/odom</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot1/odom', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176608
'_wrapWidths': [131.79302587176608, 131.79302587176608]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(76.82110204364108, ['robot1/odom'])], link=[], rise=0, text='robot1/odom', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">局部连续里程计参考</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='局部连续里程计参考', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.7585301837271
'_wrapWidths': [155.7585301837271, 155.7585301837271]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(79.25853018372709, ['局部连续里程计参考'])], link=[], rise=0, text='局部连续里程计参考', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">记录首次实际部署位姿，核验返航误差</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='记录首次实际部署位姿，核验返航误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 179.7240344956881
'_wrapWidths': [179.7240344956881, 179.7240344956881]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(35.2240344956881, ['记录首次实际部署位姿，核验返航误差'])], link=[], rise=0, text='记录首次实际部署位姿，核验返航误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">base_footprint</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">base_scan</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='base_footprint', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='base_scan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176608
'_wrapWidths': [131.79302587176608, 131.79302587176608]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=112.73291015625, descent=-2.0419921875, extraSpace=19.060115715516076, fontSize=8.5, kind=1, lineBreak=False, maxWidth=131.79302587176608, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='base_footprint', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='base_scan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">机器人地面投影 </font><font name="Latin">/</font><font name="CN"> 激光安装坐标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='机器人地面投影 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 激光安装坐标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.7585301837271
'_wrapWidths': [155.7585301837271, 155.7585301837271]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=117.81298828125, descent=-2.0419921875, extraSpace=37.94554190247709, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.7585301837271, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='机器人地面投影 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 激光安装坐标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">感知投影、足迹与控制</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='感知投影、足迹与控制', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 179.7240344956881
'_wrapWidths': [179.7240344956881, 179.7240344956881]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(94.7240344956881, ['感知投影、足迹与控制'])], link=[], rise=0, text='感知投影、足迹与控制', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SDF</font><font name="CN"> 世界坐标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SDF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 世界坐标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176608
'_wrapWidths': [131.79302587176608, 131.79302587176608]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=53.054443359375, descent=-2.0419921875, extraSpace=78.73858251239108, fontSize=8.5, kind=1, lineBreak=False, maxWidth=131.79302587176608, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SDF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 世界坐标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">仿真几何真值</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='仿真几何真值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.7585301837271
'_wrapWidths': [155.7585301837271, 155.7585301837271]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(104.75853018372709, ['仿真几何真值'])], link=[], rise=0, text='仿真几何真值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">只供离线场景生成和独立评估</font><font name="Latin">/</font><font name="CN">审计</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='只供离线场景生成和独立评估', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='审计', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 179.7240344956881
'_wrapWidths': [179.7240344956881, 179.7240344956881]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=130.36376953125, descent=-2.0419921875, extraSpace=49.3602649644381, fontSize=8.5, kind=1, lineBreak=False, maxWidth=179.7240344956881, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='只供离线场景生成和独立评估', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='审计', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

二维刚体变换：x_map = tx + cos(θ)x_odom − sin(θ)y_odom；y_map = ty + sin(θ)x_odom + cos(θ)y_odom。将地图原点平移当成永不变化的常数，会在 SLAM 修正后把目标指向错误的物理位置。

本版第一次收到有效 odom 时保存部署位姿 p_home_odom。每次返航请求前读取当前 map_from_odom，再转换成 Nav2 目标。目标坐标在每次返航请求时更新，并不是每个控制周期实时重写；因此动作完成后仍做部署误差核验。

真实机器人若 odom 漂移或多机地图未配准，不能直接照搬仿真中的单位公共坐标关系。这里的 WORLD 里程计没有编码器漂移，返航误差是这一仿真条件下的位置距离。

代码依据：src/active_slam_v4/active_slam_v4/model.py:47 [Transform2]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:228 [on_odometry]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:724 [schedule_return]

## 05 SLAM 层：感知怎样变成可用地图

slam_toolbox 是地图估计后端。激光通过 TF 转到机器人坐标，里程计提供运动关系；后端进行扫描匹配及地图维护，输出占据栅格与 map→odom 关系。探索器使用这些结果，并没有重写 SLAM 后端。[O2]

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">参数</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='参数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497495
'_wrapWidths': [171.00930565497495, 171.00930565497495]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(154.00930565497495, ['参数'])], link=[], rise=0, text='参数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">冻结值</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='冻结值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 90.94273443092341
'_wrapWidths': [90.94273443092341, 90.94273443092341]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(65.44273443092341, ['冻结值'])], link=[], rise=0, text='冻结值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">解释</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='解释', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 205.32355046528275
'_wrapWidths': [205.32355046528275, 205.32355046528275]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(188.32355046528275, ['解释'])], link=[], rise=0, text='解释', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">激光</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='激光', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497495
'_wrapWidths': [171.00930565497495, 171.00930565497495]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(154.00930565497495, ['激光'])], link=[], rise=0, text='激光', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">180</font><font name="CN">束 </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">3Hz</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">10m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='180', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='束 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 90.94273443092341
'_wrapWidths': [90.94273443092341, 90.94273443092341]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=74.70703125, descent=-2.0419921875, extraSpace=16.23570318092341, fontSize=8.5, kind=1, lineBreak=False, maxWidth=90.94273443092341, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='180', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='束 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际传感器；不能与评分用</font><font name="Latin">48</font><font name="CN">射线混淆</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际传感器；不能与评分用', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='48', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='射线混淆', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 205.32355046528275
'_wrapWidths': [205.32355046528275, 205.32355046528275]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=146.81591796875, descent=-2.0419921875, extraSpace=58.50763249653275, fontSize=8.5, kind=1, lineBreak=False, maxWidth=205.32355046528275, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际传感器；不能与评分用', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='48', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='射线混淆', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SLAM</font><font name="CN"> </font><font name="Latin">resolution</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='resolution', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497495
'_wrapWidths': [171.00930565497495, 171.00930565497495]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=67.887939453125, descent=-2.0419921875, extraSpace=103.12136620184995, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497495, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='resolution', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.10m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 90.94273443092341
'_wrapWidths': [90.94273443092341, 90.94273443092341]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(63.73692388404841, ['0.10m'])], link=[], rise=0, text='0.10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">地图每个栅格边长；不是局部代价地图的</font><font name="Latin">0.05m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图每个栅格边长；不是局部代价地图的', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.05m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 205.32355046528275
'_wrapWidths': [205.32355046528275, 205.32355046528275]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=180.205810546875, descent=-2.0419921875, extraSpace=25.11773991840775, fontSize=8.5, kind=1, lineBreak=False, maxWidth=205.32355046528275, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图每个栅格边长；不是局部代价地图的', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.05m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">map_update_interval</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='map_update_interval', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497495
'_wrapWidths': [171.00930565497495, 171.00930565497495]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(81.26955956122495, ['map_update_interval'])], link=[], rise=0, text='map_update_interval', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">2.0s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2.0s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 90.94273443092341
'_wrapWidths': [90.94273443092341, 90.94273443092341]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(72.99644536842341, ['2.0s'])], link=[], rise=0, text='2.0s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">地图输出更新间隔；评估与地图变化绑定</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图输出更新间隔；评估与地图变化绑定', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 205.32355046528275
'_wrapWidths': [205.32355046528275, 205.32355046528275]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(52.32355046528275, ['地图输出更新间隔；评估与地图变化绑定'])], link=[], rise=0, text='地图输出更新间隔；评估与地图变化绑定', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">minimum_travel_distance</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">heading</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='minimum_travel_distance', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='heading', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497495
'_wrapWidths': [171.00930565497495, 171.00930565497495]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=151.1904296875, descent=-2.0419921875, extraSpace=19.818875967474952, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497495, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='minimum_travel_distance', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='heading', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.25m</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">0.25rad</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.25m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.25rad', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 90.94273443092341
'_wrapWidths': [90.94273443092341, 90.94273443092341]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=67.54345703125, descent=-2.0419921875, extraSpace=23.39927739967341, fontSize=8.5, kind=1, lineBreak=False, maxWidth=90.94273443092341, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.25m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.25rad', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SLAM</font><font name="CN"> 接收运动更新的门槛</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 接收运动更新的门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 205.32355046528275
'_wrapWidths': [205.32355046528275, 205.32355046528275]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=102.004150390625, descent=-2.0419921875, extraSpace=103.31940007465775, fontSize=8.5, kind=1, lineBreak=False, maxWidth=205.32355046528275, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 接收运动更新的门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">transform_publish_period</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">timeout</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='transform_publish_period', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='timeout', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497495
'_wrapWidths': [171.00930565497495, 171.00930565497495]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=148.55078125, descent=-2.0419921875, extraSpace=22.458524404974952, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497495, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='transform_publish_period', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='timeout', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.05s</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">0.6s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.05s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.6s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 90.94273443092341
'_wrapWidths': [90.94273443092341, 90.94273443092341]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=48.613525390625, descent=-2.0419921875, extraSpace=42.32920904029841, fontSize=8.5, kind=1, lineBreak=False, maxWidth=90.94273443092341, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.05s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.6s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">动态变换发布和等待</font><font name="Latin">/</font><font name="CN">时间裕量配置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动态变换发布和等待', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='时间裕量配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 205.32355046528275
'_wrapWidths': [205.32355046528275, 205.32355046528275]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=130.36376953125, descent=-2.0419921875, extraSpace=74.95978093403275, fontSize=8.5, kind=1, lineBreak=False, maxWidth=205.32355046528275, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动态变换发布和等待', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='时间裕量配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">do_loop_closing</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='do_loop_closing', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497495
'_wrapWidths': [171.00930565497495, 171.00930565497495]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(103.94729393622495, ['do_loop_closing'])], link=[], rise=0, text='do_loop_closing', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">False</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 90.94273443092341
'_wrapWidths': [90.94273443092341, 90.94273443092341]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(68.82530279029841, ['False'])], link=[], rise=0, text='False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前冻结配置关闭闭环检测；不能把主动回环收益写成已部署目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前冻结配置关闭闭环检测；不能把主动回环收益写成已部署目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 205.32355046528275
'_wrapWidths': [205.32355046528275, 205.32355046528275]
'height': 25.0
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(1.32355046528275, ['当前冻结配置关闭闭环检测；不能把主动回环收益写成']), (162.82355046528275, ['已部署目标'])], link=[], rise=0, text='当前冻结配置关闭闭环检测；不能把主动回环收益写成已部署目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

栅格语义在规划器中明确划分：0～25 为空闲；65～100 为障碍；−1 为未知。26～64 的中间值不会直接当作安全空闲候选。未知不等于空闲，目标必须先落在已知可达区域。

当前优化对象主要是地图探索和导航可靠性。它不显式维护“下一目标能减少多少定位协方差”，也没有把姿态图闭环约束数写入目标函数。即使 SLAM 库本身具备更多功能，也应按实际启用参数介绍本版。

代码依据：scripts/run_test.py:58 [make_configs]

代码依据：src/active_slam_v4/active_slam_v4/planner.py:16 [reachable_free]

## 06 Frontier：从地图中找到下一片未知边界

Frontier 是“已知空闲格与未知格相邻”的边界，不是障碍轮廓，也不是直接把机器人开进未知格。先从机器人当前所在空闲格做四邻域 BFS，得到连通的已知空闲集合，再在这一集合上找前沿。

四邻域只包含上、下、左、右。一个可达空闲格只要有未知邻居，就加入 frontier 集合；再按四邻域连通性聚成簇。簇按大小降序与固定坐标顺序排序，为后续采样和复现提供稳定的输入顺序。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">步骤</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='步骤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 97.40773707634374
'_wrapWidths': [97.40773707634374, 97.40773707634374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(80.40773707634374, ['步骤'])], link=[], rise=0, text='步骤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">输入 </font><font name="Latin">→</font><font name="CN"> 输出</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='输入 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 输出', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 173.99315302978434
'_wrapWidths': [173.99315302978434, 173.99315302978434]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=45.5712890625, descent=-2.0419921875, extraSpace=128.42186396728434, fontSize=8.5, kind=1, lineBreak=False, maxWidth=173.99315302978434, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='输入 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 输出', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">为什么需要</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='为什么需要', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.8747004450531
'_wrapWidths': [195.8747004450531, 195.8747004450531]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(153.3747004450531, ['为什么需要'])], link=[], rise=0, text='为什么需要', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">reachable_free</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='reachable_free', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 97.40773707634374
'_wrapWidths': [97.40773707634374, 97.40773707634374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(34.022971451343736, ['reachable_free'])], link=[], rise=0, text='reachable_free', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SLAM</font><font name="CN">栅格 </font><font name="Latin">+</font><font name="CN"> 当前位姿 </font><font name="Latin">→</font><font name="CN"> 连通空闲格</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='栅格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 当前位姿 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 连通空闲格', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 173.99315302978434
'_wrapWidths': [173.99315302978434, 173.99315302978434]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=139.922119140625, descent=-2.0419921875, extraSpace=34.07103388915934, fontSize=8.5, kind=1, lineBreak=False, maxWidth=173.99315302978434, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='栅格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 当前位姿 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 连通空闲格', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">排除与当前机器人不连通的已知区域</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='排除与当前机器人不连通的已知区域', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.8747004450531
'_wrapWidths': [195.8747004450531, 195.8747004450531]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(59.874700445053094, ['排除与当前机器人不连通的已知区域'])], link=[], rise=0, text='排除与当前机器人不连通的已知区域', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">frontier_clusters</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier_clusters', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 97.40773707634374
'_wrapWidths': [97.40773707634374, 97.40773707634374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(28.328635513843736, ['frontier_clusters'])], link=[], rise=0, text='frontier_clusters', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">连通空闲格 </font><font name="Latin">+</font><font name="CN"> 未知邻接关系 </font><font name="Latin">→</font><font name="CN"> 前沿簇</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='连通空闲格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 未知邻接关系 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 前沿簇', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 173.99315302978434
'_wrapWidths': [173.99315302978434, 173.99315302978434]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=142.142578125, descent=-2.0419921875, extraSpace=31.850574904784338, fontSize=8.5, kind=1, lineBreak=False, maxWidth=173.99315302978434, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='连通空闲格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 未知邻接关系 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 前沿簇', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">减少逐格无组织枚举</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='减少逐格无组织枚举', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.8747004450531
'_wrapWidths': [195.8747004450531, 195.8747004450531]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(119.3747004450531, ['减少逐格无组织枚举'])], link=[], rise=0, text='减少逐格无组织枚举', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">簇内采样</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='簇内采样', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 97.40773707634374
'_wrapWidths': [97.40773707634374, 97.40773707634374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(63.407737076343736, ['簇内采样'])], link=[], rise=0, text='簇内采样', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">每簇靠近质心的最多</font><font name="Latin">4</font><font name="CN">格</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='每簇靠近质心的最多', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='4', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='格', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 173.99315302978434
'_wrapWidths': [173.99315302978434, 173.99315302978434]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=90.407958984375, descent=-2.0419921875, extraSpace=83.58519404540934, fontSize=8.5, kind=1, lineBreak=False, maxWidth=173.99315302978434, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='每簇靠近质心的最多', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='4', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='格', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">控制候选生成量，同时保留少量不同观测入口</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='控制候选生成量，同时保留少量不同观测入口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.8747004450531
'_wrapWidths': [195.8747004450531, 195.8747004450531]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(25.874700445053094, ['控制候选生成量，同时保留少量不同观测入口'])], link=[], rise=0, text='控制候选生成量，同时保留少量不同观测入口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">观测点回退</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='观测点回退', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 97.40773707634374
'_wrapWidths': [97.40773707634374, 97.40773707634374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(54.907737076343736, ['观测点回退'])], link=[], rise=0, text='观测点回退', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">前沿附近的已知安全格 </font><font name="Latin">→</font><font name="CN"> 位姿</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='前沿附近的已知安全格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 位姿', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 173.99315302978434
'_wrapWidths': [173.99315302978434, 173.99315302978434]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=113.5712890625, descent=-2.0419921875, extraSpace=60.42186396728434, fontSize=8.5, kind=1, lineBreak=False, maxWidth=173.99315302978434, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='前沿附近的已知安全格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 位姿', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">frontier</font><font name="CN"> 格自身可能贴墙、处于膨胀区或不可导航</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 格自身可能贴墙、处于膨胀区或不可导航', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.8747004450531
'_wrapWidths': [195.8747004450531, 195.8747004450531]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=186.7177734375, descent=-2.0419921875, extraSpace=9.156927007553094, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.8747004450531, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 格自身可能贴墙、处于膨胀区或不可导航', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

在线配置最多检查前160个簇，每簇最多采4个前沿格，再在邻域中挑选观测格。这不是“仅选择最近前沿”；最终目标还要经过安全距离、代理收益与实际 Nav2 路径代价过滤。

BFS 的连通性只是局部地图上的几何初筛，不包含完整机器人转弯与动力学可行性。最终仍必须向 Nav2 请求路径，不能把二维相邻格连通当作可执行的导航证明。

代码依据：src/active_slam_v4/active_slam_v4/planner.py:9 [neighbors]

代码依据：src/active_slam_v4/active_slam_v4/planner.py:30 [frontier_clusters]

## 07 安全观测位姿：目标为什么不直接落在黑边旁

每个被采样的前沿格，在其周围寻找已知连通空闲格。0.1m 分辨率下，搜索偏移约为0.05～0.90m，优先选距前沿约0.45m的位置；并以障碍间隙作为次级排序因素。观测朝向指向被选前沿。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">过滤项</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='过滤项', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.2650918635171
'_wrapWidths': [115.2650918635171, 115.2650918635171]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(89.7650918635171, ['过滤项'])], link=[], rise=0, text='过滤项', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际门槛</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 132.6194225721785
'_wrapWidths': [132.6194225721785, 132.6194225721785]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(98.61942257217851, ['实际门槛'])], link=[], rise=0, text='实际门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">作用与限制</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='作用与限制', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 219.39107611548562
'_wrapWidths': [219.39107611548562, 219.39107611548562]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(176.89107611548562, ['作用与限制'])], link=[], rise=0, text='作用与限制', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">障碍间隙</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='障碍间隙', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.2650918635171
'_wrapWidths': [115.2650918635171, 115.2650918635171]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(81.2650918635171, ['障碍间隙'])], link=[], rise=0, text='障碍间隙', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">safe_radius_m</font><font name="CN"> </font><font name="Latin">=</font><font name="CN"> </font><font name="Latin">0.50m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='safe_radius_m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='=', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.50m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 132.6194225721785
'_wrapWidths': [132.6194225721785, 132.6194225721785]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=99.6923828125, descent=-2.0419921875, extraSpace=32.92703975967851, fontSize=8.5, kind=1, lineBreak=False, maxWidth=132.6194225721785, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='safe_radius_m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='=', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.50m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">四邻域距离传播得到的栅格间隙；是近似量，不是精确圆形足迹证明</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='四邻域距离传播得到的栅格间隙；是近似量，不是精确圆形足迹证明', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 219.39107611548562
'_wrapWidths': [219.39107611548562, 219.39107611548562]
'height': 25.0
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(6.8910761154856175, ['四邻域距离传播得到的栅格间隙；是近似量，不是精确圆']), (176.89107611548562, ['形足迹证明'])], link=[], rise=0, text='四邻域距离传播得到的栅格间隙；是近似量，不是精确圆形足迹证明', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">未知边界间隙</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未知边界间隙', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.2650918635171
'_wrapWidths': [115.2650918635171, 115.2650918635171]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(64.2650918635171, ['未知边界间隙'])], link=[], rise=0, text='未知边界间隙', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">至少 </font><font name="Latin">min(0.2,</font><font name="CN">分辨率</font><font name="Latin">)</font><font name="CN">，当前为</font><font name="Latin">0.10m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='至少 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='min(0.2,', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分辨率', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=')', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，当前为', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 132.6194225721785
'_wrapWidths': [132.6194225721785, 132.6194225721785]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=136.53125, descent=-2.0419921875, extraSpace=15.013953822178507, fontSize=8.5, kind=1, lineBreak=False, maxWidth=132.6194225721785, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='至少 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='min(0.2,', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分辨率', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=')', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，当前为', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=27.205810546875, descent=-2.0419921875, extraSpace=105.41361202530351, fontSize=8.5, kind=1, lineBreak=False, maxWidth=132.6194225721785, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">避免目标直接落在未知边缘</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='避免目标直接落在未知边缘', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 219.39107611548562
'_wrapWidths': [219.39107611548562, 219.39107611548562]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(117.39107611548562, ['避免目标直接落在未知边缘'])], link=[], rise=0, text='避免目标直接落在未知边缘', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">距机器人位置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='距机器人位置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.2650918635171
'_wrapWidths': [115.2650918635171, 115.2650918635171]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(64.2650918635171, ['距机器人位置'])], link=[], rise=0, text='距机器人位置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">至少</font><font name="Latin">0.60m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='至少', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.60m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 132.6194225721785
'_wrapWidths': [132.6194225721785, 132.6194225721785]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=44.205810546875, descent=-2.0419921875, extraSpace=88.41361202530351, fontSize=8.5, kind=1, lineBreak=False, maxWidth=132.6194225721785, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='至少', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.60m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">减少立即成功却没有新视角的目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='减少立即成功却没有新视角的目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 219.39107611548562
'_wrapWidths': [219.39107611548562, 219.39107611548562]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(91.89107611548562, ['减少立即成功却没有新视角的目标'])], link=[], rise=0, text='减少立即成功却没有新视角的目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">失败目标近邻</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='失败目标近邻', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.2650918635171
'_wrapWidths': [115.2650918635171, 115.2650918635171]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(64.2650918635171, ['失败目标近邻'])], link=[], rise=0, text='失败目标近邻', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.55m</font><font name="CN"> 半径内排除</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.55m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 半径内排除', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 132.6194225721785
'_wrapWidths': [132.6194225721785, 132.6194225721785]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=71.930419921875, descent=-2.0419921875, extraSpace=60.68900265030351, fontSize=8.5, kind=1, lineBreak=False, maxWidth=132.6194225721785, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.55m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 半径内排除', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">失败位置记忆跨地图版本生效</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='失败位置记忆跨地图版本生效', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 219.39107611548562
'_wrapWidths': [219.39107611548562, 219.39107611548562]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(108.89107611548562, ['失败位置记忆跨地图版本生效'])], link=[], rise=0, text='失败位置记忆跨地图版本生效', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">代理收益</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='代理收益', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.2650918635171
'_wrapWidths': [115.2650918635171, 115.2650918635171]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(81.2650918635171, ['代理收益'])], link=[], rise=0, text='代理收益', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">至少</font><font name="Latin">2</font><font name="CN">个可见未知边界格</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='至少', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='个可见未知边界格', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 132.6194225721785
'_wrapWidths': [132.6194225721785, 132.6194225721785]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=90.407958984375, descent=-2.0419921875, extraSpace=42.21146358780351, fontSize=8.5, kind=1, lineBreak=False, maxWidth=132.6194225721785, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='至少', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='个可见未知边界格', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">剔除完全没有局部未知证据的目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='剔除完全没有局部未知证据的目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 219.39107611548562
'_wrapWidths': [219.39107611548562, 219.39107611548562]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(91.89107611548562, ['剔除完全没有局部未知证据的目标'])], link=[], rise=0, text='剔除完全没有局部未知证据的目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Nav2</font><font name="CN"> 路径</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 路径', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.2650918635171
'_wrapWidths': [115.2650918635171, 115.2650918635171]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=41.22998046875, descent=-2.0419921875, extraSpace=74.0351113947671, fontSize=8.5, kind=1, lineBreak=False, maxWidth=115.2650918635171, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 路径', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">有效、非空、有限且长度非负</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='有效、非空、有限且长度非负', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 132.6194225721785
'_wrapWidths': [132.6194225721785, 132.6194225721785]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(22.119422572178507, ['有效、非空、有限且长度非负'])], link=[], rise=0, text='有效、非空、有限且长度非负', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">将代价地图和导航可达性纳入最终过滤</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='将代价地图和导航可达性纳入最终过滤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 219.39107611548562
'_wrapWidths': [219.39107611548562, 219.39107611548562]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(74.89107611548562, ['将代价地图和导航可达性纳入最终过滤'])], link=[], rise=0, text='将代价地图和导航可达性纳入最终过滤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

注意距离传播采用四邻域 BFS，斜向的距离数值可能大于欧氏距离。因此“0.50m 安全间隙”应按代码中的离散近似理解；真正执行还依赖 Nav2 足迹、障碍膨胀、RPP 碰撞预测和最终激光门。不能据此宣称零碰撞。

当路径查询期间地图更新，派发前会在最新 SLAM 地图上重新确认目标仍为空闲，并绑定最新 map_version。这里重新核验的是目标格，并没有对整条旧路径做独立的全足迹重验证；Nav2 在执行时继续重规划。

代码依据：src/active_slam_v4/active_slam_v4/planner.py:107 [plan]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:631 [schedule_explore]

## 08 信息收益：当前真正计算了什么

当前 predicted_new_cells 由 visible_unknown 计算：以候选位姿为中心，在360°范围发48条评分射线，最大距离3.2m，每步约一个地图栅格。遇已知障碍停止；遇第一格未知时记入集合并立即停止该条射线。

因此它估计的是“从这个观测点可接触到多少个不同的未知边界格”，每条射线至多贡献一个首个未知格；去重后的数量不超过48。它不是沿每条光线累计3.2m内所有未知面积，也不是实际10m激光扫描的完整可见区域。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">指标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='指标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 148.1331424481031
'_wrapWidths': [148.1331424481031, 148.1331424481031]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(131.1331424481031, ['指标'])], link=[], rise=0, text='指标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是否在本版计算</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是否在本版计算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 102.38081603435934
'_wrapWidths': [102.38081603435934, 102.38081603435934]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(42.88081603435934, ['是否在本版计算'])], link=[], rise=0, text='是否在本版计算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">解释</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='解释', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 216.76163206871868
'_wrapWidths': [216.76163206871868, 216.76163206871868]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(199.76163206871868, ['解释'])], link=[], rise=0, text='解释', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">射线首个未知格计数</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='射线首个未知格计数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 148.1331424481031
'_wrapWidths': [148.1331424481031, 148.1331424481031]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(71.63314244810309, ['射线首个未知格计数'])], link=[], rise=0, text='射线首个未知格计数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">是</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 102.38081603435934
'_wrapWidths': [102.38081603435934, 102.38081603435934]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(93.88081603435934, ['是'])], link=[], rise=0, text='是', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">局部信息收益代理，几何遮挡先由已知障碍截断</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='局部信息收益代理，几何遮挡先由已知障碍截断', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 216.76163206871868
'_wrapWidths': [216.76163206871868, 216.76163206871868]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(38.26163206871868, ['局部信息收益代理，几何遮挡先由已知障碍截断'])], link=[], rise=0, text='局部信息收益代理，几何遮挡先由已知障碍截断', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">真实新覆盖面积</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='真实新覆盖面积', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 148.1331424481031
'_wrapWidths': [148.1331424481031, 148.1331424481031]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(88.63314244810309, ['真实新覆盖面积'])], link=[], rise=0, text='真实新覆盖面积', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">只在独立评估</font><font name="Latin">/</font><font name="CN">日志层观察</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='只在独立评估', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='日志层观察', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 102.38081603435934
'_wrapWidths': [102.38081603435934, 102.38081603435934]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=96.36376953125, descent=-2.0419921875, extraSpace=6.017046503109341, fontSize=8.5, kind=1, lineBreak=False, maxWidth=102.38081603435934, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='只在独立评估', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='日志层观察', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">到达前无法直接由代理数量精确预知</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='到达前无法直接由代理数量精确预知', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 216.76163206871868
'_wrapWidths': [216.76163206871868, 216.76163206871868]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(80.76163206871868, ['到达前无法直接由代理数量精确预知'])], link=[], rise=0, text='到达前无法直接由代理数量精确预知', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">地图熵的期望下降</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图熵的期望下降', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 148.1331424481031
'_wrapWidths': [148.1331424481031, 148.1331424481031]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(80.13314244810309, ['地图熵的期望下降'])], link=[], rise=0, text='地图熵的期望下降', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">否</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='否', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 102.38081603435934
'_wrapWidths': [102.38081603435934, 102.38081603435934]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(93.88081603435934, ['否'])], link=[], rise=0, text='否', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">没有观测概率模型、熵积分或期望后验计算</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='没有观测概率模型、熵积分或期望后验计算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 216.76163206871868
'_wrapWidths': [216.76163206871868, 216.76163206871868]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(55.26163206871868, ['没有观测概率模型、熵积分或期望后验计算'])], link=[], rise=0, text='没有观测概率模型、熵积分或期望后验计算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">定位协方差下降 </font><font name="Latin">/</font><font name="CN"> 回环收益</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='定位协方差下降 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 回环收益', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 148.1331424481031
'_wrapWidths': [148.1331424481031, 148.1331424481031]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=100.81298828125, descent=-2.0419921875, extraSpace=47.32015416685309, fontSize=8.5, kind=1, lineBreak=False, maxWidth=148.1331424481031, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='定位协方差下降 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 回环收益', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">否</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='否', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 102.38081603435934
'_wrapWidths': [102.38081603435934, 102.38081603435934]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(93.88081603435934, ['否'])], link=[], rise=0, text='否', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">没有把定位不确定性作为候选效用项</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='没有把定位不确定性作为候选效用项', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 216.76163206871868
'_wrapWidths': [216.76163206871868, 216.76163206871868]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(80.76163206871868, ['没有把定位不确定性作为候选效用项'])], link=[], rise=0, text='没有把定位不确定性作为候选效用项', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

严格的信息论收益常写作 IG(g)=H(Mt)−E[H(Mt+1)|g]。这需要地图/观测概率模型。本版没有计算这个期望，所以手册使用“信息收益代理”一词。不能把简单未知格数量命名为已经求出的地图熵下降。

代理高不保证实际覆盖增量大：未知格可能是墙体边缘、不可达阴影，或在途中已被观测。已知障碍后的未知被遮挡剔除，但未知内部是否存在遮挡无法提前确认。由此可能出现多次目标成功、覆盖率增长很少的情况。

代码依据：src/active_slam_v4/active_slam_v4/planner.py:68 [visible_unknown]

## 09 目标评分与候选预算：收益怎样和路程结合

候选先按 gain/(欧氏距离+1) 做便宜排序，再按2m×2m空间桶分散请求预算：各桶先取第1个，再取第2个。最终最多40个候选请求 Nav2 ComputePathToPose；欧氏距离只参与预筛，不代替可导航路径长度。

实际路径长度 L(g) 为返回路径相邻位姿欧氏段长的总和。不可达、动作失败、超时或空路径都按无效处理，不使用直线距离填补失败的路径代价。

实际效用：U(g) = gain(g) / ( L(g)/0.22 + 2 ) − 0.1 / max(c(g),0.1)。其中0.22m/s是评分用名义速度，不是控制器硬限速；c为障碍和未知边界距离的较小值。然后加上策略种子生成的至多±1%相对微扰。

例：若 gain=20、L=4.4m、c=0.2m，则旅行代理为22s，原始得分约20/22−0.5=0.409。若另一候选 gain相同但L=8.8m，旅行代理42s，得分约−0.024；在其他条件一致时前者优先。这是启发式相对排序，不是有物理意义的期望累计奖励。

本版没有将所有项统一归一化到[0,1]，没有在线学习权重，也没有单独的“转向角代价”或定位收益项。数值来自冻结实现，而不是把早期方案中的一般评分公式写成当前代码。

代码依据：src/active_slam_v4/active_slam_v4/planner.py:107 [plan]

代码依据：src/active_slam_v4/active_slam_v4/planner.py:91 [seeded_score]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:467 [query_path]

## 10 区域策略与双机组件：已用和未用的边界

本版的区域编号为 floor(x/2):floor(y/2)。这是一张固定2m空间分桶，并非语义房间识别、稀疏门口图、拓扑最短巡回或学习到的全局策略。分桶用于路径查询多样性和目标临时归属。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">组件</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='组件', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 124.30380577427826
'_wrapWidths': [124.30380577427826, 124.30380577427826]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(107.30380577427826, ['组件'])], link=[], rise=0, text='组件', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">代码中存在</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='代码中存在', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.24343832020998
'_wrapWidths': [166.24343832020998, 166.24343832020998]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(123.74343832020998, ['代码中存在'])], link=[], rise=0, text='代码中存在', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前单机执行情况</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前单机执行情况', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 176.72834645669295
'_wrapWidths': [176.72834645669295, 176.72834645669295]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(108.72834645669295, ['当前单机执行情况'])], link=[], rise=0, text='当前单机执行情况', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Allocator</font><font name="CN"> 贪心分配</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Allocator', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 贪心分配', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 124.30380577427826
'_wrapWidths': [124.30380577427826, 124.30380577427826]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=73.872802734375, descent=-2.0419921875, extraSpace=50.43100303990326, fontSize=8.5, kind=1, lineBreak=False, maxWidth=124.30380577427826, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Allocator', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 贪心分配', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">按得分排序，机器人和区域各至多占一个目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='按得分排序，机器人和区域各至多占一个目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.24343832020998
'_wrapWidths': [166.24343832020998, 166.24343832020998]
'height': 25.0
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(4.743438320209975, ['按得分排序，机器人和区域各至多占一个目']), (157.74343832020998, ['标'])], link=[], rise=0, text='按得分排序，机器人和区域各至多占一个目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">单机退化为为 </font><font name="Latin">robot1</font><font name="CN"> 选择一个有效候选</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='单机退化为为 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot1', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 选择一个有效候选', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 176.72834645669295
'_wrapWidths': [176.72834645669295, 176.72834645669295]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=151.48095703125, descent=-2.0419921875, extraSpace=25.247389425442947, fontSize=8.5, kind=1, lineBreak=False, maxWidth=176.72834645669295, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='单机退化为为 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot1', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 选择一个有效候选', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Lease</font><font name="CN"> 临时归属</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 临时归属', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 124.30380577427826
'_wrapWidths': [124.30380577427826, 124.30380577427826]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=61.056396484375, descent=-2.0419921875, extraSpace=63.24740928990326, fontSize=8.5, kind=1, lineBreak=False, maxWidth=124.30380577427826, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 临时归属', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">持有机器人、区域、地图版本和到期时刻</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='持有机器人、区域、地图版本和到期时刻', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.24343832020998
'_wrapWidths': [166.24343832020998, 166.24343832020998]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(13.243438320209975, ['持有机器人、区域、地图版本和到期时刻'])], link=[], rise=0, text='持有机器人、区域、地图版本和到期时刻', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">运行配置</font><font name="Latin">50s</font><font name="CN">；地图版本变化也会令旧</font><font name="Latin">lease</font><font name="CN">失效</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='运行配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='50s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；地图版本变化也会令旧', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='失效', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 176.72834645669295
'_wrapWidths': [176.72834645669295, 176.72834645669295]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=182.2021484375, descent=-2.0419921875, extraSpace=3.0261980191929467, fontSize=8.5, kind=1, lineBreak=False, maxWidth=176.72834645669295, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='运行配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='50s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；地图版本变化也会令旧', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='失', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=8.5, descent=-2.025390625, extraSpace=168.22834645669295, fontSize=8.5, kind=1, lineBreak=False, maxWidth=176.72834645669295, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='效', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">AlignmentFusion</font><font name="CN"> 双图融合</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='AlignmentFusion', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 双图融合', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 124.30380577427826
'_wrapWidths': [124.30380577427826, 124.30380577427826]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=107.4287109375, descent=-2.0419921875, extraSpace=16.87509483677826, fontSize=8.5, kind=1, lineBreak=False, maxWidth=124.30380577427826, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='AlignmentFusion', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 双图融合', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">重采样、障碍优先、重叠</font><font name="Latin">/</font><font name="CN">冲突门槛</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重采样、障碍优先、重叠', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='冲突门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.24343832020998
'_wrapWidths': [166.24343832020998, 166.24343832020998]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=130.36376953125, descent=-2.0419921875, extraSpace=35.879668788959975, fontSize=8.5, kind=1, lineBreak=False, maxWidth=166.24343832020998, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重采样、障碍优先、重叠', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='冲突门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">单机分支绕过双图融合，直接转发本地地图到</font><font name="Latin">/map</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='单机分支绕过双图融合，直接转发本地地图到', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 176.72834645669295
'_wrapWidths': [176.72834645669295, 176.72834645669295]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=181.143798828125, descent=-2.025390625, extraSpace=6.728346456692947, fontSize=8.5, kind=1, lineBreak=False, maxWidth=176.72834645669295, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='单机分支绕过双图融合，直接转发本地地图到', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=21.748046875, descent=-2.0419921875, extraSpace=154.98029958169295, fontSize=8.5, kind=1, lineBreak=False, maxWidth=176.72834645669295, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/map', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">双机在线导航</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='双机在线导航', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 124.30380577427826
'_wrapWidths': [124.30380577427826, 124.30380577427826]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(73.30380577427826, ['双机在线导航'])], link=[], rise=0, text='双机在线导航', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">源码保留多机数据结构</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='源码保留多机数据结构', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.24343832020998
'_wrapWidths': [166.24343832020998, 166.24343832020998]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(81.24343832020998, ['源码保留多机数据结构'])], link=[], rise=0, text='源码保留多机数据结构', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">入口明确只允许</font><font name="Latin">single</font><font name="CN">；并未完成本发布的双机验收</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='入口明确只允许', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='single', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；并未完成本发布的双机验收', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 176.72834645669295
'_wrapWidths': [176.72834645669295, 176.72834645669295]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=178.163818359375, descent=-2.0419921875, extraSpace=7.064528097317947, fontSize=8.5, kind=1, lineBreak=False, maxWidth=176.72834645669295, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='入口明确只允许', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='single', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；并未完成本发布的双', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=25.5, descent=-2.025390625, extraSpace=151.22834645669295, fontSize=8.5, kind=1, lineBreak=False, maxWidth=176.72834645669295, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='机验收', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">HPHS</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">RangeTAP</font><font name="CN"> 完整算法</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='HPHS', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RangeTAP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 完整算法', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 124.30380577427826
'_wrapWidths': [124.30380577427826, 124.30380577427826]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=110.1015625, descent=-2.0419921875, extraSpace=14.20224327427826, fontSize=8.5, kind=1, lineBreak=False, maxWidth=124.30380577427826, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='HPHS', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RangeTAP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 完整算法', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">没有完整实现</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='没有完整实现', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.24343832020998
'_wrapWidths': [166.24343832020998, 166.24343832020998]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(115.24343832020998, ['没有完整实现'])], link=[], rise=0, text='没有完整实现', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">仅能把局部采样、区域分桶和路径成本视为相关工程思路，不能称完整论文复现</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='仅能把局部采样、区域分桶和路径成本视为相关工程思路，不能称完整论文复现', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 176.72834645669295
'_wrapWidths': [176.72834645669295, 176.72834645669295]
'height': 25.0
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(6.728346456692947, ['仅能把局部采样、区域分桶和路径成本视为相']), (49.22834645669295, ['关工程思路，不能称完整论文复现'])], link=[], rise=0, text='仅能把局部采样、区域分桶和路径成本视为相关工程思路，不能称完整论文复现', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

双图融合类本身要求两张地图和变换同时存在，按占据冲突比例、地图新鲜度和重叠数做检查；但这不等于实现了未知初始位姿下的地图配准。仿真公共坐标来自已知关系，真实多机需要另外验证配准与动态TF。

当前没有匈牙利匹配、完整视野集合的双机器人去重、同时会车防死锁或已验收的同房间双机协同。介绍“整体V4架构”时必须把这些保留组件与单机已运行主链分开。

代码依据：src/active_slam_v4/active_slam_v4/allocator.py:17 [Allocator]

代码依据：src/active_slam_v4/active_slam_v4/fusion.py:18 [AlignmentFusion]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:438 [update_fusion]

## 11 Nav2 执行层：规划路径与连续速度分工

选中观测位姿后，监督器发送 NavigateToPose 动作。bt_navigator 运行冻结行为树；规划器计算一条路径，控制器跟踪路径，恢复行为处理局部失败。探索模块负责“去哪里”，Nav2负责“怎样沿已知可通行区域过去”。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">模块</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='模块', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(98.08979559373263, ['模块'])], link=[], rise=0, text='模块', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">本版实际配置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='本版实际配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(120.00930565497498, ['本版实际配置'])], link=[], rise=0, text='本版实际配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">功能</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='功能', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(164.17648930247358, ['功能'])], link=[], rise=0, text='功能', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">全局规划 </font><font name="Latin">GridBased</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='全局规划 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='GridBased', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=80.156494140625, descent=-2.0419921875, extraSpace=34.93330145310763, fontSize=8.5, kind=1, lineBreak=False, maxWidth=115.08979559373263, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='全局规划 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='GridBased', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">NavfnPlanner</font><font name="CN">，</font><font name="Latin">use_astar=False</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavfnPlanner', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='use_astar=False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=135.879638671875, descent=-2.0419921875, extraSpace=35.12966698309998, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497498, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavfnPlanner', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='use_astar=False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前是</font><font name="Latin">NavFn</font><font name="CN">的</font><font name="Latin">Dijkstra</font><font name="CN">方式；不要描述为已启用</font><font name="Latin">A*</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前是', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavFn', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='的', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Dijkstra', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='方式；不要描述为已启用', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='A*', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=187.029052734375, descent=-2.0419921875, extraSpace=2.647436568098584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=181.17648930247358, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前是', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavFn', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='的', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Dijkstra', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='方式；不要描述为已启', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=18.564697265625, descent=-2.0419921875, extraSpace=162.61179203684858, fontSize=8.5, kind=1, lineBreak=False, maxWidth=181.17648930247358, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='用', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='A*', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">未知通行</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未知通行', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(81.08979559373263, ['未知通行'])], link=[], rise=0, text='未知通行', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">allow_unknown=False</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='allow_unknown=False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(76.81204002997498, ['allow_unknown=False'])], link=[], rise=0, text='allow_unknown=False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">规划路径不主动穿越未知区域</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='规划路径不主动穿越未知区域', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(70.67648930247358, ['规划路径不主动穿越未知区域'])], link=[], rise=0, text='规划路径不主动穿越未知区域', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">全局代价地图</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='全局代价地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(64.08979559373263, ['全局代价地图'])], link=[], rise=0, text='全局代价地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">静态地图层 </font><font name="Latin">+</font><font name="CN"> 膨胀层，更新</font><font name="Latin">1Hz</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='静态地图层 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 膨胀层，更新', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='1Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=121.33251953125, descent=-2.0419921875, extraSpace=49.67678612372498, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497498, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='静态地图层 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 膨胀层，更新', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='1Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SLAM</font><font name="CN">地图作为基础，膨胀半径</font><font name="Latin">0.70m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图作为基础，膨胀半径', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.70m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=143.9853515625, descent=-2.0419921875, extraSpace=37.191137739973584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=181.17648930247358, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图作为基础，膨胀半径', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.70m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">局部代价地图</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='局部代价地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(64.08979559373263, ['局部代价地图'])], link=[], rise=0, text='局部代价地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">障碍层 </font><font name="Latin">+</font><font name="CN"> 膨胀层，</font><font name="Latin">4m×4m</font><font name="CN">，更新</font><font name="Latin">2Hz</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='障碍层 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 膨胀层，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='4m×4m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，更新', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=147.33056640625, descent=-2.0419921875, extraSpace=23.67873924872498, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497498, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='障碍层 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 膨胀层，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='4m×4m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，更新', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">用激光更新近距离障碍，膨胀半径</font><font name="Latin">0.65m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='用激光更新近距离障碍，膨胀半径', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.65m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=154.705810546875, descent=-2.0419921875, extraSpace=26.470678755598584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=181.17648930247358, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='用激光更新近距离障碍，膨胀半径', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.65m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">代价地图几何</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='代价地图几何', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(64.08979559373263, ['代价地图几何'])], link=[], rise=0, text='代价地图几何', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">配置</font><font name="Latin">resolution=0.05m</font><font name="CN">，</font><font name="Latin">robot_radius=0.22m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='resolution=0.05m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot_radius=0.22m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=176.00146484375, descent=-2.0419921875, extraSpace=68.79763573309998, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497498, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='resolution=0.05m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=87.477783203125, descent=-2.0419921875, extraSpace=83.53152245184998, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497498, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='robot_radius=0.22m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">全局</font><font name="Latin">StaticLayer</font><font name="CN">可能随输入地图尺寸</font><font name="Latin">/</font><font name="CN">分辨率匹配，实际以发布头为准</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='全局', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='StaticLayer', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='可能随输入地图尺寸', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分辨率匹配，实际以发布头为准', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=186.8671875, descent=-2.0419921875, extraSpace=2.809301802473584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=181.17648930247358, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='全局', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='StaticLayer', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='可能随输入地图尺寸', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分辨率匹', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=85.0, descent=-2.025390625, extraSpace=96.17648930247358, fontSize=8.5, kind=1, lineBreak=False, maxWidth=181.17648930247358, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='配，实际以发布头为准', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">连续控制器</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='连续控制器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(72.58979559373263, ['连续控制器'])], link=[], rise=0, text='连续控制器', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">RPP</font><font name="CN">，控制频率</font><font name="Latin">8Hz</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，控制频率', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=74.918701171875, descent=-2.0419921875, extraSpace=96.09060448309998, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497498, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，控制频率', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">跟踪前视点，结合曲率调速和碰撞预测</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='跟踪前视点，结合曲率调速和碰撞预测', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(36.676489302473584, ['跟踪前视点，结合曲率调速和碰撞预测'])], link=[], rise=0, text='跟踪前视点，结合曲率调速和碰撞预测', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">速度平滑</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='速度平滑', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 115.08979559373263
'_wrapWidths': [115.08979559373263, 115.08979559373263]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(81.08979559373263, ['速度平滑'])], link=[], rise=0, text='速度平滑', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">20Hz</font><font name="CN">，线速度上限</font><font name="Latin">0.26m/s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，线速度上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.26m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 171.00930565497498
'_wrapWidths': [171.00930565497498, 171.00930565497498]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=107.167236328125, descent=-2.0419921875, extraSpace=63.84206932684998, fontSize=8.5, kind=1, lineBreak=False, maxWidth=171.00930565497498, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，线速度上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.26m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">RPP</font><font name="CN">期望</font><font name="Latin">0.28m/s</font><font name="CN">不等于最后实际输出速度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='期望', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.28m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不等于最后实际输出速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 181.17648930247358
'_wrapWidths': [181.17648930247358, 181.17648930247358]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=161.155517578125, descent=-2.0419921875, extraSpace=20.020971724348584, fontSize=8.5, kind=1, lineBreak=False, maxWidth=181.17648930247358, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='期望', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.28m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不等于最后实际输出速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

规划服务返回有效路径，不能保证整个未来执行过程永远成功。机器人运动、传感器噪声、地图更新或局部障碍仍可能导致控制器中止，因此需要后续看门狗、取消确认与重新选择目标。

源码里的 query_path 发送请求等待上限6秒，等待结果上限8秒，使用线程事件的墙上时间。这些RPC等待与启动墙时保护说明整个软件并非完全只由仿真时间驱动；任务截止、前沿冷却和多数导航诊断使用仿真秒。

代码依据：scripts/run_test.py:58 [make_configs]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:467 [query_path]

## 12 RPP 路径跟随：为什么会旋转，如何避免配置陷阱

RPP从已规划路径上取前视点，依据机器人与前视点的相对位置生成角速度/线速度，并按曲率与接近目标情况调节线速度。开启的碰撞预测会检查短时间运动是否与代价地图冲突。[O1]

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">参数</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='参数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(138.75853018372703, ['参数'])], link=[], rise=0, text='参数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">冻结值</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='冻结值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 99.8390201224847
'_wrapWidths': [99.8390201224847, 99.8390201224847]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(74.3390201224847, ['冻结值'])], link=[], rise=0, text='冻结值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">含义</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='含义', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(194.6780402449694, ['含义'])], link=[], rise=0, text='含义', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">desired_linear_vel</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='desired_linear_vel', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(79.05931143372703, ['desired_linear_vel'])], link=[], rise=0, text='desired_linear_vel', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.28m/s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.28m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 99.8390201224847
'_wrapWidths': [99.8390201224847, 99.8390201224847]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(65.3409732474847, ['0.28m/s'])], link=[], rise=0, text='0.28m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">控制器期望；后续平滑上限</font><font name="Latin">0.26m/s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='控制器期望；后续平滑上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.26m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=136.498046875, descent=-2.0419921875, extraSpace=75.1799933699694, fontSize=8.5, kind=1, lineBreak=False, maxWidth=211.6780402449694, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='控制器期望；后续平滑上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.26m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">min</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">max</font><font name="CN"> </font><font name="Latin">lookahead</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='min', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='max', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lookahead', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=88.199951171875, descent=-2.0419921875, extraSpace=67.55857901185203, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.75853018372703, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='min', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='max', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lookahead', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.45</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">0.70m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.45', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.70m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 99.8390201224847
'_wrapWidths': [99.8390201224847, 99.8390201224847]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=53.444580078125, descent=-2.0419921875, extraSpace=46.3944400443597, fontSize=8.5, kind=1, lineBreak=False, maxWidth=99.8390201224847, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.45', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.70m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际启用速度相关前视，静态</font><font name="Latin">lookahead_dist=0.40</font><font name="CN">不是此时最小值</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际启用速度相关前视，静态', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lookahead_dist=0.40', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不是此时最小值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=217.4306640625, descent=-2.0419921875, extraSpace=2.747376182469395, fontSize=8.5, kind=1, lineBreak=False, maxWidth=211.6780402449694, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际启用速度相关前视，静态', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lookahead_dist=0.40', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=51.0, descent=-2.025390625, extraSpace=160.6780402449694, fontSize=8.5, kind=1, lineBreak=False, maxWidth=211.6780402449694, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='是此时最小值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">rotate_to_heading_angular_vel</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='rotate_to_heading_angular_vel', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(24.996323152477032, ['rotate_to_heading_angular_vel'])], link=[], rise=0, text='rotate_to_heading_angular_vel', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.60rad/s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.60rad/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 99.8390201224847
'_wrapWidths': [99.8390201224847, 99.8390201224847]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(59.5221255912347, ['0.60rad/s'])], link=[], rise=0, text='0.60rad/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">约</font><font name="Latin">34.4</font><font name="CN">度</font><font name="Latin">/</font><font name="CN">秒，短暂对准路径可正常发生</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='约', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='34.4', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='度', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='秒，短暂对准路径可正常发生', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=149.28955078125, descent=-2.0419921875, extraSpace=62.388489463719395, fontSize=8.5, kind=1, lineBreak=False, maxWidth=211.6780402449694, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='约', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='34.4', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='度', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='秒，短暂对准路径可正常发生', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">use_collision_detection</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='use_collision_detection', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(57.73460440247703, ['use_collision_detection'])], link=[], rise=0, text='use_collision_detection', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">True</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='True', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 99.8390201224847
'_wrapWidths': [99.8390201224847, 99.8390201224847]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(80.5355533256097, ['True'])], link=[], rise=0, text='True', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">预测碰撞，窗口上限</font><font name="Latin">1.2s</font><font name="CN">，受前视点限制</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='预测碰撞，窗口上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='1.2s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，受前视点限制', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=153.9462890625, descent=-2.0419921875, extraSpace=57.731751182469395, fontSize=8.5, kind=1, lineBreak=False, maxWidth=211.6780402449694, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='预测碰撞，窗口上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='1.2s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，受前视点限制', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">曲率调速 </font><font name="Latin">/</font><font name="CN"> 代价调速</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='曲率调速 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 代价调速', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=75.31298828125, descent=-2.0419921875, extraSpace=80.44554190247703, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.75853018372703, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='曲率调速 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 代价调速', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">True</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">False</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='True', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 99.8390201224847
'_wrapWidths': [99.8390201224847, 99.8390201224847]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=48.73388671875, descent=-2.0419921875, extraSpace=51.1051334037347, fontSize=8.5, kind=1, lineBreak=False, maxWidth=99.8390201224847, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='True', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='False', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">不要把两种不同的速度调节开关混为一项</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不要把两种不同的速度调节开关混为一项', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(58.678040244969395, ['不要把两种不同的速度调节开关混为一项'])], link=[], rise=0, text='不要把两种不同的速度调节开关混为一项', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">最小受控速度 </font><font name="Latin">/</font><font name="CN"> 接近速度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='最小受控速度 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 接近速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=92.31298828125, descent=-2.0419921875, extraSpace=63.44554190247703, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.75853018372703, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='最小受控速度 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 接近速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.08</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">0.05m/s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.08', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.05m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 99.8390201224847
'_wrapWidths': [99.8390201224847, 99.8390201224847]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=60.73681640625, descent=-2.0419921875, extraSpace=39.1022037162347, fontSize=8.5, kind=1, lineBreak=False, maxWidth=99.8390201224847, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.08', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.05m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">弯曲路径与接近终点时可显著慢于期望速度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='弯曲路径与接近终点时可显著慢于期望速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(50.178040244969395, ['弯曲路径与接近终点时可显著慢于期望速度'])], link=[], rise=0, text='弯曲路径与接近终点时可显著慢于期望速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

调试中出现过最小前视0.25m而探索XY容差0.35m的错误配置。Humble RPP 的目标朝向判断使用前视点距离，可能过早进入目标朝向旋转。本版以0.45m大于所有XY容差为约束，并在参数生成时自动拒绝冲突。

正常转向与故障转圈要分开：对准路径、转弯与到达后的目标朝向校正有明确的后续平移/完成结果；长期无平移、路径/足迹时间戳冻结或超时才需要诊断。换RPP不代表消灭所有旋转，也不保证所有窄门都有可行轨迹。

代码依据：scripts/run_test.py:29 [validate_rpp_config]

代码依据：src/active_slam_v4/active_slam_v4/navigation_health.py:22 [navigation_fault]

## 13 行为树与目标稳定性：谁来负责恢复

冻结行为树的主链为 PipelineSequence：以1Hz重算当前目标的路径，再由 FollowPath 执行。全局规划失败时清全局代价地图并有限重试；控制失败时清局部代价地图并有限重试。

外层 RecoveryNode 最多2次重试，恢复候选按 RoundRobin 使用等待1秒和后退0.25m（0.05m/s）。没有 Spin 恢复节点。这里的“无Spin恢复”不等于控制器不会为对准路径而旋转。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">层级</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='层级', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(89.11569982323638, ['层级'])], link=[], rise=0, text='层级', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">本版实际行为</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='本版实际行为', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 178.0122127591194
'_wrapWidths': [178.0122127591194, 178.0122127591194]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(127.0122127591194, ['本版实际行为'])], link=[], rise=0, text='本版实际行为', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">不能误写成</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不能误写成', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 183.14767796882532
'_wrapWidths': [183.14767796882532, 183.14767796882532]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(140.64767796882532, ['不能误写成'])], link=[], rise=0, text='不能误写成', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Nav2</font><font name="CN">路径重规划</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='路径重规划', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=64.50537109375, descent=-2.0419921875, extraSpace=41.61032872948638, fontSize=8.5, kind=1, lineBreak=False, maxWidth=106.11569982323638, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='路径重规划', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前目标不变，约</font><font name="Latin">1Hz</font><font name="CN">重算路径</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前目标不变，约', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='1Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重算路径', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 178.0122127591194
'_wrapWidths': [178.0122127591194, 178.0122127591194]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=118.26123046875, descent=-2.0419921875, extraSpace=59.75098229036939, fontSize=8.5, kind=1, lineBreak=False, maxWidth=178.0122127591194, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前目标不变，约', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='1Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重算路径', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">每秒重新选择一个</font><font name="Latin">frontier</font><font name="CN">目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='每秒重新选择一个', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 183.14767796882532
'_wrapWidths': [183.14767796882532, 183.14767796882532]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=116.4931640625, descent=-2.0419921875, extraSpace=66.65451390632532, fontSize=8.5, kind=1, lineBreak=False, maxWidth=183.14767796882532, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='每秒重新选择一个', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">探索目标重选</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索目标重选', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(55.11569982323638, ['探索目标重选'])], link=[], rise=0, text='探索目标重选', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">完成、失败、取消或阶段变化后再选择</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='完成、失败、取消或阶段变化后再选择', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 178.0122127591194
'_wrapWidths': [178.0122127591194, 178.0122127591194]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(33.51221275911939, ['完成、失败、取消或阶段变化后再选择'])], link=[], rise=0, text='完成、失败、取消或阶段变化后再选择', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">不断在所有候选间每秒来回跳转</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不断在所有候选间每秒来回跳转', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 183.14767796882532
'_wrapWidths': [183.14767796882532, 183.14767796882532]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(64.14767796882532, ['不断在所有候选间每秒来回跳转'])], link=[], rise=0, text='不断在所有候选间每秒来回跳转', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">外层调度冷却</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='外层调度冷却', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(55.11569982323638, ['外层调度冷却'])], link=[], rise=0, text='外层调度冷却', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">最少</font><font name="Latin">7</font><font name="CN">仿真秒启动一次候选规划，忙时不发新目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='最少', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='7', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='仿真秒启动一次候选规划，忙时不发新目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 178.0122127591194
'_wrapWidths': [178.0122127591194, 178.0122127591194]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=183.907958984375, descent=-2.0419921875, extraSpace=2.604253774744393, fontSize=8.5, kind=1, lineBreak=False, maxWidth=178.0122127591194, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='最少', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='7', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='仿真秒启动一次候选规划，忙时不发新目', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=8.5, descent=-2.025390625, extraSpace=169.5122127591194, fontSize=8.5, kind=1, lineBreak=False, maxWidth=178.0122127591194, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">固定每</font><font name="Latin">7</font><font name="CN">秒强制取消当前目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='固定每', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='7', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='秒强制取消当前目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 183.14767796882532
'_wrapWidths': [183.14767796882532, 183.14767796882532]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=107.407958984375, descent=-2.0419921875, extraSpace=75.73971898445032, fontSize=8.5, kind=1, lineBreak=False, maxWidth=183.14767796882532, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='固定每', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='7', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='秒强制取消当前目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Mission</font><font name="CN">的</font><font name="Latin">20%</font><font name="CN">切换接口</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Mission', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='的', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='切换接口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=92.89404296875, descent=-2.0419921875, extraSpace=13.221656854486383, fontSize=8.5, kind=1, lineBreak=False, maxWidth=106.11569982323638, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Mission', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='的', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='切换接口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">类中支持</font><font name="Latin">switch_margin=0.2</font><font name="CN">和</font><font name="Latin">current_score</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='类中支持', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='switch_margin=0.2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='和', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='current_score', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 178.0122127591194
'_wrapWidths': [178.0122127591194, 178.0122127591194]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=182.928466796875, descent=-2.0419921875, extraSpace=53.35938072786939, fontSize=8.5, kind=1, lineBreak=False, maxWidth=178.0122127591194, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='类中支持', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='switch_margin=0.2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='和', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=58.275634765625, descent=-2.0419921875, extraSpace=119.7365779934944, fontSize=8.5, kind=1, lineBreak=False, maxWidth=178.0122127591194, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='current_score', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">已部署每轮比较新旧目标并启用</font><font name="Latin">20%</font><font name="CN">滞后</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已部署每轮比较新旧目标并启用', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='滞后', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 183.14767796882532
'_wrapWidths': [183.14767796882532, 183.14767796882532]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=154.892578125, descent=-2.0419921875, extraSpace=28.25509984382532, fontSize=8.5, kind=1, lineBreak=False, maxWidth=183.14767796882532, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已部署每轮比较新旧目标并启用', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='滞后', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

关键源码事实：schedule_explore 跳过有活动目标的机器人，也没有向 Mission.dispatch 传 current_score。因此当前在线路径以“完成/失败后重选”为主，不能把类里存在的20%门槛当作已经启用的持续在线切换策略。

失败后先取消旧动作、等终止结果/短暂保持，再派新目标；避免旧goal迟到接受或尚未取消时与新goal竞争。Nav2拥有主要运动恢复，监督器拥有诊断和目标生命周期，减少多个恢复模块互相抢控制。

代码依据：assets/navigate_bounded.xml:1

代码依据：src/active_slam_v4/active_slam_v4/mission.py:78 [dispatch]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:252 [navigation_busy]

## 14 最终速度安全门：防碰撞的最后一层

SafetyNode以20Hz运行，订阅平滑后的导航速度、恢复速度和激光，最终发布cmd_vel。恢复指令在足够新鲜且非零时优先；否则使用新鲜导航指令；两者都旧则输出零。

前向与后向各取±35°激光扇区最小距离。正向速度检查前方，倒车检查后方。停止距离的启发式为：d_stop = 0.19 + 0.10 + v²/(2×0.45)。在0.26m/s时约0.365m；小于等于停止距离就切掉平移，再往外0.35m的缓行区把线速度降到最多0.08m/s。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">条件</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='条件', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 133.39072615923013
'_wrapWidths': [133.39072615923013, 133.39072615923013]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(116.39072615923013, ['条件'])], link=[], rise=0, text='条件', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">输出</font><font name="Latin">/</font><font name="CN">动作</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='输出', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动作', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 122.20682414698163
'_wrapWidths': [122.20682414698163, 122.20682414698163]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=36.86376953125, descent=-2.0419921875, extraSpace=85.34305461573163, fontSize=8.5, kind=1, lineBreak=False, maxWidth=122.20682414698163, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='输出', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动作', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">说明</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='说明', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(194.6780402449694, ['说明'])], link=[], rise=0, text='说明', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">激光接收超过</font><font name="Latin">0.7s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='激光接收超过', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.7s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 133.39072615923013
'_wrapWidths': [133.39072615923013, 133.39072615923013]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=68.9462890625, descent=-2.0419921875, extraSpace=64.44443709673013, fontSize=8.5, kind=1, lineBreak=False, maxWidth=133.39072615923013, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='激光接收超过', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.7s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">零速度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='零速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 122.20682414698163
'_wrapWidths': [122.20682414698163, 122.20682414698163]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(96.70682414698163, ['零速度'])], link=[], rise=0, text='零速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">这里按回调接收时间判新鲜度，并非所有地方都用消息原始头时间</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='这里按回调接收时间判新鲜度，并非所有地方都用消息原始头时间', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 25.0
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(7.678040244969395, ['这里按回调接收时间判新鲜度，并非所有地方都用消息']), (169.1780402449694, ['原始头时间'])], link=[], rise=0, text='这里按回调接收时间判新鲜度，并非所有地方都用消息原始头时间', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">恢复指令年龄</font><font name="Latin">≤0.25s</font><font name="CN">且非零</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='恢复指令年龄', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.25s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='且非零', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 133.39072615923013
'_wrapWidths': [133.39072615923013, 133.39072615923013]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=106.976318359375, descent=-2.0419921875, extraSpace=26.414407799855127, fontSize=8.5, kind=1, lineBreak=False, maxWidth=133.39072615923013, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='恢复指令年龄', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.25s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='且非零', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">优先恢复速度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='优先恢复速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 122.20682414698163
'_wrapWidths': [122.20682414698163, 122.20682414698163]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(71.20682414698163, ['优先恢复速度'])], link=[], rise=0, text='优先恢复速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">依旧经过激光过滤</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='依旧经过激光过滤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(143.6780402449694, ['依旧经过激光过滤'])], link=[], rise=0, text='依旧经过激光过滤', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">导航指令年龄</font><font name="Latin">≤0.5s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='导航指令年龄', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.5s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 133.39072615923013
'_wrapWidths': [133.39072615923013, 133.39072615923013]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=76.068359375, descent=-2.0419921875, extraSpace=57.32236678423013, fontSize=8.5, kind=1, lineBreak=False, maxWidth=133.39072615923013, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='导航指令年龄', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.5s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">采用导航速度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='采用导航速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 122.20682414698163
'_wrapWidths': [122.20682414698163, 122.20682414698163]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(71.20682414698163, ['采用导航速度'])], link=[], rise=0, text='采用导航速度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">未满足新鲜条件则</font><font name="Latin">idle</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未满足新鲜条件则', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='idle', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=83.34814453125, descent=-2.0419921875, extraSpace=128.3298957137194, fontSize=8.5, kind=1, lineBreak=False, maxWidth=211.6780402449694, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未满足新鲜条件则', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='idle', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">导航</font><font name="Latin">hold</font><font name="CN">为真</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='导航', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='hold', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='为真', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 133.39072615923013
'_wrapWidths': [133.39072615923013, 133.39072615923013]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=52.3447265625, descent=-2.0419921875, extraSpace=81.04599959673013, fontSize=8.5, kind=1, lineBreak=False, maxWidth=133.39072615923013, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='导航', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='hold', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='为真', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">立即输出零并清理临时恢复</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='立即输出零并清理临时恢复', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 122.20682414698163
'_wrapWidths': [122.20682414698163, 122.20682414698163]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(20.20682414698163, ['立即输出零并清理临时恢复'])], link=[], rise=0, text='立即输出零并清理临时恢复', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">配合故障处理和生命周期重置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='配合故障处理和生命周期重置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(101.1780402449694, ['配合故障处理和生命周期重置'])], link=[], rise=0, text='配合故障处理和生命周期重置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">纯旋转命令</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='纯旋转命令', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 133.39072615923013
'_wrapWidths': [133.39072615923013, 133.39072615923013]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(90.89072615923013, ['纯旋转命令'])], link=[], rise=0, text='纯旋转命令', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">允许角速度通过</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='允许角速度通过', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 122.20682414698163
'_wrapWidths': [122.20682414698163, 122.20682414698163]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(62.70682414698163, ['允许角速度通过'])], link=[], rise=0, text='允许角速度通过', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">不能将这个门描述为对非圆形足迹旋转提供完整碰撞证明</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不能将这个门描述为对非圆形足迹旋转提供完整碰撞证明', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 211.6780402449694
'_wrapWidths': [211.6780402449694, 211.6780402449694]
'height': 25.0
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(7.678040244969395, ['不能将这个门描述为对非圆形足迹旋转提供完整碰撞证']), (203.1780402449694, ['明'])], link=[], rise=0, text='不能将这个门描述为对非圆形足迹旋转提供完整碰撞证明', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

安全门的圆形半径近似、前后扇区以及扫描采样都存在限制；Nav2 使用的0.22m足迹与这里启发式0.19m+0.10m不同。它是叠加保护而不是替代Nav2足迹检查。全部激光值无有效有限读数时，sector_min 返回无穷大，也不是独立的传感器健康证明。

源码保留 escape/backtrack 接口，但当前主要失败分支没有主动发布 escape_request；不能把这段备用能力描述为每次卡住都会自动触发的主恢复流程。

代码依据：src/active_slam_v4/active_slam_v4/safety.py:18 [safe_velocity]

代码依据：src/active_slam_v4/active_slam_v4/safety_node.py:103 [tick]

## 15 防卡住监督：控制、任务、输入三层看门狗

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">保护层</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='保护层', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(80.61569982323638, ['保护层'])], link=[], rise=0, text='保护层', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">冻结门槛</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='冻结门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(159.4186083882372, ['冻结门槛'])], link=[], rise=0, text='冻结门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">处理</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='处理', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(150.74128233970754, ['处理'])], link=[], rise=0, text='处理', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Nav2</font><font name="CN"> </font><font name="Latin">progress</font><font name="CN"> </font><font name="Latin">checker</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='progress', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='checker', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=97.131591796875, descent=-2.0419921875, extraSpace=8.984108026361383, fontSize=8.5, kind=1, lineBreak=False, maxWidth=106.11569982323638, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='progress', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='checker', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">12s</font><font name="CN">内需约</font><font name="Latin">0.12m</font><font name="CN">位置变化</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='12s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='内需约', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.12m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='位置变化', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=101.9501953125, descent=-2.0419921875, extraSpace=91.4684130757372, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='12s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='内需约', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.12m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='位置变化', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">控制器判无进展，进入有限行为树恢复</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='控制器判无进展，进入有限行为树恢复', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(23.24128233970754, ['控制器判无进展，进入有限行为树恢复'])], link=[], rise=0, text='控制器判无进展，进入有限行为树恢复', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">外层平移监督</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='外层平移监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(55.11569982323638, ['外层平移监督'])], link=[], rise=0, text='外层平移监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">同一目标</font><font name="Latin">35s</font><font name="CN">未产生</font><font name="Latin">0.12m</font><font name="CN">净位移</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='同一目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='35s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未产生', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.12m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='净位移', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=127.4501953125, descent=-2.0419921875, extraSpace=65.9684130757372, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='同一目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='35s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未产生', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.12m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='净位移', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">判</font><font name="Latin">blocked</font><font name="CN">，取消目标并重选；转向不会重置平移计时</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='判', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='blocked', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，取消目标并重选；转向不会重置平移计时', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=169.17822265625, descent=-2.0419921875, extraSpace=7.0630596834575385, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='判', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='blocked', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，取消目标并重选；转向不会重', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=42.5, descent=-2.025390625, extraSpace=125.24128233970754, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='置平移计时', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">单目标预算</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='单目标预算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(63.61569982323638, ['单目标预算'])], link=[], rise=0, text='单目标预算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">max(70,min(150,L/0.18+15))</font><font name="CN">秒</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='max(70,min(150,L/0.18+15))', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='秒', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=133.21923828125, descent=-2.0419921875, extraSpace=60.1993701069872, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='max(70,min(150,L/0.18+15))', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='秒', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">到期按</font><font name="Latin">timeout</font><font name="CN">处理，不能无限占用任务</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='到期按', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='timeout', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='处理，不能无限占用任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=152.124267578125, descent=-2.0419921875, extraSpace=15.617014761582539, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='到期按', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='timeout', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='处理，不能无限占用任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">导航输入监督</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='导航输入监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(55.11569982323638, ['导航输入监督'])], link=[], rise=0, text='导航输入监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">goal</font><font name="CN">年龄</font><font name="Latin">≥8s</font><font name="CN">；局部图或足迹头时间落后</font><font name="Latin">&gt;4s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='goal', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='年龄', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≥8s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；局部图或足迹头时间落后', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='4s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=171.083251953125, descent=-2.0419921875, extraSpace=22.335356435112203, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='goal', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='年龄', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≥8s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；局部图或足迹头时间落后', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>4s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">记录</font><font name="Latin">fault</font><font name="CN">、</font><font name="Latin">hold</font><font name="CN">停止、取消并至多一次</font><font name="Latin">Nav2</font><font name="CN">重置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='fault', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='hold', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='停止、取消并至多一次', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=170.1328125, descent=-2.0419921875, extraSpace=19.61384093345754, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='fault', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='hold', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='停止、取消并至多一次', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=39.00537109375, descent=-2.0419921875, extraSpace=128.73591124595754, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">变换后路径监督</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='变换后路径监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(46.61569982323638, ['变换后路径监督'])], link=[], rise=0, text='变换后路径监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">原计划新鲜</font><font name="Latin">&lt;2.5s</font><font name="CN">，但变换路径缺失或落后</font><font name="Latin">&gt;5s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='原计划新鲜', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='<', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2.5s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，但变换路径缺失或落后', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='5s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=178.02685546875, descent=-2.0419921875, extraSpace=15.391752919487203, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='原计划新鲜', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='<2.5s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，但变换路径缺失或落后', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>5s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">判控制器消费路径不新鲜</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='判控制器消费路径不新鲜', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(74.24128233970754, ['判控制器消费路径不新鲜'])], link=[], rise=0, text='判控制器消费路径不新鲜', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">取消卡住</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='取消卡住', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(72.11569982323638, ['取消卡住'])], link=[], rise=0, text='取消卡住', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">等待终止超过</font><font name="Latin">8s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='等待终止超过', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=60.83642578125, descent=-2.0419921875, extraSpace=132.5821826069872, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='等待终止超过', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">触发受限重置路径，避免反复重叠目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='触发受限重置路径，避免反复重叠目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(23.24128233970754, ['触发受限重置路径，避免反复重叠目标'])], link=[], rise=0, text='触发受限重置路径，避免反复重叠目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">总体健康 </font><font name="Latin">/</font><font name="CN"> 总预算</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='总体健康 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 总预算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 106.11569982323638
'_wrapWidths': [106.11569982323638, 106.11569982323638]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=66.81298828125, descent=-2.0419921875, extraSpace=39.30271154198638, fontSize=8.5, kind=1, lineBreak=False, maxWidth=106.11569982323638, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='总体健康 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 总预算', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">就绪输入通常</font><font name="Latin">≤6s</font><font name="CN">；不健康宽限</font><font name="Latin">10s</font><font name="CN">；任务</font><font name="Latin">700s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='就绪输入通常', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤6s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；不健康宽限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='700s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=180.355224609375, descent=-2.0419921875, extraSpace=13.063383778862203, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='就绪输入通常', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤6s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；不健康宽限', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='700s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">无法恢复则明确</font><font name="Latin">FAILED</font><font name="CN">，不持续假装探索</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='无法恢复则明确', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='FAILED', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，不持续假装探索', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 167.74128233970754
'_wrapWidths': [167.74128233970754, 167.74128233970754]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=157.362060546875, descent=-2.0419921875, extraSpace=10.379221792832539, fontSize=8.5, kind=1, lineBreak=False, maxWidth=167.74128233970754, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='无法恢复则明确', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='FAILED', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，不持续假装探索', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

外层35秒监督基于 map 位姿的净平移。它不是完整的轨迹环路检测器；小范围平移往返可能重置这个计时。distance_remaining 的0.25m改善值虽在反馈中记录，目前没有在tick中成为独立超时触发条件。

失败位置在0.55m半径内抑制180仿真秒；若目标“成功”但起终位移小于0.35m，则抑制60秒，减少没有新观测视角的即时成功。失败ID和物理位置记忆分别处理，不只依赖会变化的地图版本号。

运行构造器把max_retries设为20，覆盖Mission类默认值2；成功会清零，超过20次连续非成功才触发对应任务失败。Nav2重置次数仍最多1次，行为树外层重试仍为2次，这三个数字属于不同层级。

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:821 [tick]

代码依据：src/active_slam_v4/active_slam_v4/navigation_health.py:9 [travel_goal_budget]

## 16 永久停更根因：为什么换前沿也救不活死锁

故障诊断曾出现：时钟和部分外部TF仍更新，但控制器内部足迹与路径时间戳冻结。独立GDB两次线程栈记录显示，一个线程持有定时器/请求映射锁并等待变换请求锁；另一个线程持有变换请求锁并在回调中等待前一把锁。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">线程</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='线程', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.5816611633223
'_wrapWidths': [166.5816611633223, 166.5816611633223]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(149.5816611633223, ['线程'])], link=[], rise=0, text='线程', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">持有</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='持有', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 150.34696469392938
'_wrapWidths': [150.34696469392938, 150.34696469392938]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(133.34696469392938, ['持有'])], link=[], rise=0, text='持有', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">等待</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='等待', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 150.34696469392938
'_wrapWidths': [150.34696469392938, 150.34696469392938]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(133.34696469392938, ['等待'])], link=[], rise=0, text='等待', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">激光</font><font name="Latin">/MessageFilter</font><font name="CN">回调 </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">waitForTransform</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='激光', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/MessageFilter', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='回调 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='waitForTransform', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.5816611633223
'_wrapWidths': [166.5816611633223, 166.5816611633223]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=170.701416015625, descent=-2.0419921875, extraSpace=59.22350686644731, fontSize=8.5, kind=1, lineBreak=False, maxWidth=166.5816611633223, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='激光', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/MessageFilter', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='回调 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=75.117919921875, descent=-2.0419921875, extraSpace=91.46374124144731, fontSize=8.5, kind=1, lineBreak=False, maxWidth=166.5816611633223, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='waitForTransform', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">timer_to_request_map_mutex_</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='timer_to_request_map_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 150.34696469392938
'_wrapWidths': [150.34696469392938, 150.34696469392938]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(19.22367367830438, ['timer_to_request_map_mutex_'])], link=[], rise=0, text='timer_to_request_map_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">transformable_requests_mutex_</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='transformable_requests_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 150.34696469392938
'_wrapWidths': [150.34696469392938, 150.34696469392938]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(13.39652524080438, ['transformable_requests_mutex_'])], link=[], rise=0, text='transformable_requests_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">TF</font><font name="CN">接收 </font><font name="Latin">→</font><font name="CN"> </font><font name="Latin">testTransformableRequests</font><font name="CN"> </font><font name="Latin">→</font><font name="CN"> 回调</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='接收 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='testTransformableRequests', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 回调', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 166.5816611633223
'_wrapWidths': [166.5816611633223, 166.5816611633223]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=167.7587890625, descent=-2.0419921875, extraSpace=8.169551788322309, fontSize=8.5, kind=1, lineBreak=False, maxWidth=166.5816611633223, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='接收 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='testTransformableRequests', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=26.3466796875, descent=-2.0419921875, extraSpace=140.2349814758223, fontSize=8.5, kind=1, lineBreak=False, maxWidth=166.5816611633223, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='→', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 回调', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">transformable_requests_mutex_</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='transformable_requests_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 150.34696469392938
'_wrapWidths': [150.34696469392938, 150.34696469392938]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(13.39652524080438, ['transformable_requests_mutex_'])], link=[], rise=0, text='transformable_requests_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">timer_to_request_map_mutex_</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='timer_to_request_map_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 150.34696469392938
'_wrapWidths': [150.34696469392938, 150.34696469392938]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(19.22367367830438, ['timer_to_request_map_mutex_'])], link=[], rise=0, text='timer_to_request_map_mutex_', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

这是ABBA锁顺序死锁：两线程彼此等待，单纯增加旋转、修改frontier得分或缩短DDS发布间隔不能释放锁。重置也可能在清理时等住，因此必须先修复底层锁循环，再讨论局部导航性能。

冻结版使用官方Humble修复tf2/tf2_ros 0.25.24，在提取满足条件的请求后释放锁，再执行相关回调。[O3] 官方DEB只解包到vendor，子进程设置本地库路径，不替换系统旧实验安装。

验证不只看“这次没卡”：同一C++回调重入测试在旧0.25.23加载下确定性超时，在隔离0.25.24下立即通过；最终运行还保存过实际/proc进程库映射，确认SLAM和控制器加载本地修复库。

该结论针对抓到的TF内部永久停更。地图目标不可达、局部足迹受阻或任务预算耗尽是其他故障类别，需要分别记录，不能全部归为TF或frontier问题。

代码依据：src/tf_deadlock_regression/src/callback_reentry.cpp:1

原始证据：ROOT_CAUSE.md、TF_DEADLOCK_REGRESSION.json、evidence/diagnostic_controller_threads.log、各次loaded_tf2_libraries.json。

## 17 任务状态机：从启动到结束的明确条件

【PDF中为可选中文字的矢量结构图】

STARTUP：任务第一次tick记录sim_start_s，数据与Nav2动作服务就绪后进入EXPLORE。仿真启动预算90秒，额外还有120秒墙上启动保护。总体任务仿真计时包含启动，并不在导航重置后重新计时。

EXPLORE：单机同一时刻只有一个活动目标；如果独立评估器报告coverage_passed，就清除探索活动目标并请求取消Nav2动作，切入RETURN。路径重规划仍由Nav2行为树负责。

RETURN：查询当前位姿到动态换算部署点的可行路径，执行返航。已在0.35m范围内的机器人可直接记already_home；否则动作成功还需误差核验。完成后进入COMPLETE。

FAILED：覆盖率超时、返航超时、定位不健康、无法恢复的导航故障等都保存分类。最终地图和日志仍导出。没有候选时会触发诊断并继续尝试，源码中的NO_FRONTIER枚举并不代表在线立即以这个原因退出。

代码依据：src/active_slam_v4/active_slam_v4/mission.py:7 [Mission]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:786 [finish]

## 18 真值覆盖率与返航：两个百分比怎样算

独立评估器从SDF读取与机器人高度相交的盒形碰撞几何，按机器人半径0.22m膨胀，在0.1m评估栅格上从部署点四邻域洪泛，固定真值可达空闲集合F。它没有通用的任意网格/mesh世界解析能力；当前随机生成器只支持room.world。

探索率 C_free = 100 × |{c∈F : 0≤M(c)≤25}| / |F|。探索面积 A_free = 已识别可达空闲格数 × (0.1m)²。注意：这是SLAM分类与真值可达空闲格的重合比例，不是机器人车轮实际压过的面积。

ROI集合 R = F ∪ B，其中B为与F四邻接的膨胀障碍边界格。ROI已知率 C_ROI = 100 × |{c∈R : M(c)≥0}| / |R|；空闲或障碍都算已知，未知不算。不同布局的固定真值分母可能略有不同。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">指标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='指标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 126.26252487669811
'_wrapWidths': [126.26252487669811, 126.26252487669811]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(109.26252487669811, ['指标'])], link=[], rise=0, text='指标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">返航门槛</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='返航门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 109.67102189149433
'_wrapWidths': [109.67102189149433, 109.67102189149433]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(75.67102189149433, ['返航门槛'])], link=[], rise=0, text='返航门槛', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">计数差别</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='计数差别', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 231.34204378298867
'_wrapWidths': [231.34204378298867, 231.34204378298867]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(197.34204378298867, ['计数差别'])], link=[], rise=0, text='计数差别', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">可达空闲探索率</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='可达空闲探索率', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 126.26252487669811
'_wrapWidths': [126.26252487669811, 126.26252487669811]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(66.76252487669811, ['可达空闲探索率'])], link=[], rise=0, text='可达空闲探索率', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">严格 </font><font name="Latin">&gt;95%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='严格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 109.67102189149433
'_wrapWidths': [109.67102189149433, 109.67102189149433]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=45.2392578125, descent=-2.0419921875, extraSpace=64.43176407899433, fontSize=8.5, kind=1, lineBreak=False, maxWidth=109.67102189149433, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='严格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>95%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">真值空闲还需被</font><font name="Latin">SLAM</font><font name="CN">判为空闲</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='真值空闲还需被', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='判为空闲', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 231.34204378298867
'_wrapWidths': [231.34204378298867, 231.34204378298867]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=116.779541015625, descent=-2.0419921875, extraSpace=114.56250276736367, fontSize=8.5, kind=1, lineBreak=False, maxWidth=231.34204378298867, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='真值空闲还需被', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='判为空闲', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">固定</font><font name="Latin">ROI</font><font name="CN">已知率</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='固定', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已知率', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 126.26252487669811
'_wrapWidths': [126.26252487669811, 126.26252487669811]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=57.603271484375, descent=-2.0419921875, extraSpace=68.65925339232311, fontSize=8.5, kind=1, lineBreak=False, maxWidth=126.26252487669811, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='固定', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已知率', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">严格 </font><font name="Latin">&gt;90%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='严格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='90%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 109.67102189149433
'_wrapWidths': [109.67102189149433, 109.67102189149433]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=45.2392578125, descent=-2.0419921875, extraSpace=64.43176407899433, fontSize=8.5, kind=1, lineBreak=False, maxWidth=109.67102189149433, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='严格 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='>90%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">ROI</font><font name="CN">内任何非未知分类都计已知</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='内任何非未知分类都计已知', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 231.34204378298867
'_wrapWidths': [231.34204378298867, 231.34204378298867]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=117.103271484375, descent=-2.0419921875, extraSpace=114.23877229861367, fontSize=8.5, kind=1, lineBreak=False, maxWidth=231.34204378298867, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='内任何非未知分类都计已知', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">返航位置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='返航位置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 126.26252487669811
'_wrapWidths': [126.26252487669811, 126.26252487669811]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(92.26252487669811, ['返航位置'])], link=[], rise=0, text='返航位置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际部署点误差 </font><font name="Latin">≤0.35m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际部署点误差 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 109.67102189149433
'_wrapWidths': [109.67102189149433, 109.67102189149433]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=96.052490234375, descent=-2.0419921875, extraSpace=13.618531657119334, fontSize=8.5, kind=1, lineBreak=False, maxWidth=109.67102189149433, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际部署点误差 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">不依赖屏幕看起来很近或动作回报单独判断</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不依赖屏幕看起来很近或动作回报单独判断', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 231.34204378298867
'_wrapWidths': [231.34204378298867, 231.34204378298867]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(69.84204378298867, ['不依赖屏幕看起来很近或动作回报单独判断'])], link=[], rise=0, text='不依赖屏幕看起来很近或动作回报单独判断', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

评估器随/map回调更新，并限制至少间隔约5秒；并不是严格每5秒一定有采样，地图不更新就没有新回调评估。因此表中的达标时间具有采样间隔粒度。返航途中仍可更新地图，最终覆盖率可能与触发返航时不同，曲线也不保证严格单调。

“ROI已知率90%”不是原始地图外接矩形面积的90%，也不是所有墙体内部都必须扫描到。论文中必须明确分母，否则无法和其他算法的coverage对齐。

代码依据：src/v4_evaluator/v4_evaluator/truth.py:116 [GroundTruth]

代码依据：src/v4_evaluator/v4_evaluator/metrics.py:27 [observable_roi]

代码依据：src/v4_evaluator/v4_evaluator/metrics.py:45 [evaluate]

## 19 可靠返航：目标位置和完成结果双重核验

部署点不是硬编码的地图点。首次有效里程计写入deployment_odom.json；每次返航前把这个点经当时的map_from_odom变换到SLAM地图，再请求ComputePathToPose验证可达性。

g_home_map = T_map_from_odom(now_request) · p_home_odome_home = sqrt((x_odom−x_home)² + (y_odom−y_home)²)

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">环节</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='环节', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 105.78790417155304
'_wrapWidths': [105.78790417155304, 105.78790417155304]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(88.78790417155304, ['环节'])], link=[], rise=0, text='环节', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际处理</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际处理', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(146.74384318981404, ['实际处理'])], link=[], rise=0, text='实际处理', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">原因</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='原因', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(163.74384318981404, ['原因'])], link=[], rise=0, text='原因', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">返航路径查询</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='返航路径查询', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 105.78790417155304
'_wrapWidths': [105.78790417155304, 105.78790417155304]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(54.78790417155304, ['返航路径查询'])], link=[], rise=0, text='返航路径查询', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">从当前位姿重查路径长度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='从当前位姿重查路径长度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(87.24384318981404, ['从当前位姿重查路径长度'])], link=[], rise=0, text='从当前位姿重查路径长度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">路径未找到时计重试，不用直线导航替代</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='路径未找到时计重试，不用直线导航替代', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(27.743843189814044, ['路径未找到时计重试，不用直线导航替代'])], link=[], rise=0, text='路径未找到时计重试，不用直线导航替代', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">返航行为树</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='返航行为树', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 105.78790417155304
'_wrapWidths': [105.78790417155304, 105.78790417155304]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(63.28790417155304, ['返航行为树'])], link=[], rise=0, text='返航行为树', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">沿用有限恢复树，换</font><font name="Latin">deployment_goal_checker</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='沿用有限恢复树，换', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='deployment_goal_checker', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=184.123779296875, descent=-2.0419921875, extraSpace=1.8495560804390436, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='沿用有限恢复树，换', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='deployment_goal_check', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=8.72412109375, descent=-2.0419921875, extraSpace=172.01972209606404, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='er', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">探索与返航允许不同目标容差</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索与返航允许不同目标容差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(70.24384318981404, ['探索与返航允许不同目标容差'])], link=[], rise=0, text='探索与返航允许不同目标容差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Nav2</font><font name="CN">目标检查</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标检查', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 105.78790417155304
'_wrapWidths': [105.78790417155304, 105.78790417155304]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=56.00537109375, descent=-2.0419921875, extraSpace=49.78253307780304, fontSize=8.5, kind=1, lineBreak=False, maxWidth=105.78790417155304, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标检查', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">XY</font><font name="CN"> </font><font name="Latin">0.20m</font><font name="CN">，</font><font name="Latin">yaw</font><font name="CN"> </font><font name="Latin">0.80rad</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='XY', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.20m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='yaw', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.80rad', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=101.3857421875, descent=-2.0419921875, extraSpace=79.35810100231404, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='XY', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.20m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='yaw', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.80rad', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">比探索</font><font name="Latin">0.35m</font><font name="CN">位置容差更紧</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='比探索', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='位置容差更紧', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=103.705810546875, descent=-2.0419921875, extraSpace=77.03803264293904, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='比探索', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='位置容差更紧', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际位置检查</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际位置检查', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 105.78790417155304
'_wrapWidths': [105.78790417155304, 105.78790417155304]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(54.78790417155304, ['实际位置检查'])], link=[], rise=0, text='实际位置检查', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">动作成功后</font><font name="Latin">e_home</font><font name="CN">需</font><font name="Latin">≤0.35m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动作成功后', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='e_home', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='需', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=118.904541015625, descent=-2.0419921875, extraSpace=61.839302174189044, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动作成功后', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='e_home', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='需', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">动态</font><font name="Latin">SLAM</font><font name="CN">修正可能令</font><font name="Latin">map</font><font name="CN">目标成功但物理点偏离</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动态', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='修正可能令', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='map', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标成功但物理点偏离', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=186.663818359375, descent=-2.0419921875, extraSpace=2.5800248304390436, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='动态', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='修正可能令', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='map', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标成功但物理点偏', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=8.5, descent=-2.025390625, extraSpace=172.24384318981404, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='离', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">核验未通过</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='核验未通过', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 105.78790417155304
'_wrapWidths': [105.78790417155304, 105.78790417155304]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(63.28790417155304, ['核验未通过'])], link=[], rise=0, text='核验未通过', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">记录</font><font name="Latin">home_verification_failed</font><font name="CN">并记</font><font name="Latin">home_not_reached</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='home_verification_failed', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='并记', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='home_not_reached', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=184.298095703125, descent=-2.0419921875, extraSpace=42.963325611689044, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='home_verification_failed', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='并记', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=81.135986328125, descent=-2.0419921875, extraSpace=99.60785686168904, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='home_not_reached', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">重新查询</font><font name="Latin">/</font><font name="CN">转换目标，不伪造</font><font name="Latin">returned=true</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重新查询', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='转换目标，不伪造', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='returned=true', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=166.380859375, descent=-2.0419921875, extraSpace=14.362983814814044, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='重新查询', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='转换目标，不伪造', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='returned=true', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">已在家</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已在家', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 105.78790417155304
'_wrapWidths': [105.78790417155304, 105.78790417155304]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(80.28790417155304, ['已在家'])], link=[], rise=0, text='已在家', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">无活动返航目标且</font><font name="Latin">e_home≤0.35m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='无活动返航目标且', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='e_home≤0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=135.904541015625, descent=-2.0419921875, extraSpace=44.839302174189044, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='无活动返航目标且', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='e_home≤0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">可直接完成，记录</font><font name="Latin">already_home</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='可直接完成，记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='already_home', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 180.74384318981404
'_wrapWidths': [180.74384318981404, 180.74384318981404]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=128.276123046875, descent=-2.0419921875, extraSpace=52.467720142939044, fontSize=8.5, kind=1, lineBreak=False, maxWidth=180.74384318981404, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='可直接完成，记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='already_home', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

目标朝向由初始部署yaw转换得到，但本次任务的额外实际核验主要是XY距离。这里不是严格要求精确重合到同一个数学点，而是明确的0.35m部署点容差。报告必须同时给出容差和实际误差。

全局700秒预算在返航期间继续运行。单目标时限按路径计算不代表返航阶段自动获得额外700秒。若探索消耗过多，即使覆盖率达标也可能在回程超时，这类样本应保留为return_failed。

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:724 [schedule_return]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:550 [on_goal_done]

代码依据：src/active_slam_v4/active_slam_v4/navigation_health.py:16 [deployment_error]

## 20 场景一致性：覆盖率评估为什么需要审计

早期世界生成器挪动model/pose，却留下源文件保存的state。Gazebo加载state后把两个已有箱子覆盖回旧位置，而评估器读取model定义，导致实际场景与评估真值不同。这是数据有效性问题，不能靠漂亮的覆盖率曲线消除。

本版生成器删除所有保存state，将两个原箱子设为静态，加上六个新增静态箱子；新增箱子边长0.45～0.70m、高0.60m，位置和角度由地图种子产生。构图检查按0.2m栅格验证可达自由区面积至少为原参考的95%，最多尝试50次。这个95%是生成器几何检查，不是任务探索率阈值。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">检查</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='检查', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 100.98023461353047
'_wrapWidths': [100.98023461353047, 100.98023461353047]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(83.98023461353047, ['检查'])], link=[], rise=0, text='检查', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">本版方式</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='本版方式', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(159.4186083882372, ['本版方式'])], link=[], rise=0, text='本版方式', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">数据隔离</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='数据隔离', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 172.87674754941347
'_wrapWidths': [172.87674754941347, 172.87674754941347]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(138.87674754941347, ['数据隔离'])], link=[], rise=0, text='数据隔离', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际障碍位姿</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际障碍位姿', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 100.98023461353047
'_wrapWidths': [100.98023461353047, 100.98023461353047]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(49.98023461353047, ['实际障碍位姿'])], link=[], rise=0, text='实际障碍位姿', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Gazebo</font><font name="CN">服务器第一次世界更新读取</font><font name="Latin">8</font><font name="CN">个</font><font name="Latin">Model::WorldPose</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='服务器第一次世界更新读取', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='个', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Model::WorldPose', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=196.33837890625, descent=-2.0419921875, extraSpace=45.4281298726122, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='服务器第一次世界更新读取', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='个', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=76.089111328125, descent=-2.0419921875, extraSpace=117.3294970601122, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Model::WorldPose', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">只读，不设位姿、不施力、不发导航目标</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='只读，不设位姿、不施力、不发导航目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 172.87674754941347
'_wrapWidths': [172.87674754941347, 172.87674754941347]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(19.876747549413466, ['只读，不设位姿、不施力、不发导航目标'])], link=[], rise=0, text='只读，不设位姿、不施力、不发导航目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">模型静态属性</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='模型静态属性', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 100.98023461353047
'_wrapWidths': [100.98023461353047, 100.98023461353047]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(49.98023461353047, ['模型静态属性'])], link=[], rise=0, text='模型静态属性', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">8</font><font name="CN">个均须</font><font name="Latin">static=true</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='个均须', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='static=true', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=78.811767578125, descent=-2.0419921875, extraSpace=114.6068408101122, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='个均须', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='static=true', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">确保运行时不被机器人推移而改变真值</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='确保运行时不被机器人推移而改变真值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 172.87674754941347
'_wrapWidths': [172.87674754941347, 172.87674754941347]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(28.376747549413466, ['确保运行时不被机器人推移而改变真值'])], link=[], rise=0, text='确保运行时不被机器人推移而改变真值', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">坐标误差</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='坐标误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 100.98023461353047
'_wrapWidths': [100.98023461353047, 100.98023461353047]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(66.98023461353047, ['坐标误差'])], link=[], rise=0, text='坐标误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">XY≤0.005m</font><font name="CN">，</font><font name="Latin">yaw≤0.01rad</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='XY≤0.005m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='yaw≤0.01rad', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=116.588623046875, descent=-2.0419921875, extraSpace=76.8299853413622, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='XY≤0.005m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='，', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='yaw≤0.01rad', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">与独立</font><font name="Latin">SDF</font><font name="CN">定义比较</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='与独立', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SDF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='定义比较', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 172.87674754941347
'_wrapWidths': [172.87674754941347, 172.87674754941347]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=76.329833984375, descent=-2.0419921875, extraSpace=96.54691356503847, fontSize=8.5, kind=1, lineBreak=False, maxWidth=172.87674754941347, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='与独立', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SDF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='定义比较', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">场景存档</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='场景存档', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 100.98023461353047
'_wrapWidths': [100.98023461353047, 100.98023461353047]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(66.98023461353047, ['场景存档'])], link=[], rise=0, text='场景存档', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">scene_actual_poses.json</font><font name="CN"> </font><font name="Latin">+</font><font name="CN"> </font><font name="Latin">scene_audit.json</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scene_actual_poses.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scene_audit.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=186.9169921875, descent=-2.0419921875, extraSpace=6.501616200737203, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scene_actual_poses.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scene_audit.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">原始实际采样和独立判定分别保存</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='原始实际采样和独立判定分别保存', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 172.87674754941347
'_wrapWidths': [172.87674754941347, 172.87674754941347]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(45.376747549413466, ['原始实际采样和独立判定分别保存'])], link=[], rise=0, text='原始实际采样和独立判定分别保存', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">历史数据</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='历史数据', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 100.98023461353047
'_wrapWidths': [100.98023461353047, 100.98023461353047]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(66.98023461353047, ['历史数据'])], link=[], rise=0, text='历史数据', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">旧场景不一致</font><font name="Latin">/CLI</font><font name="CN">审计超时单独标记</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='旧场景不一致', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/CLI', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='审计超时单独标记', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 193.4186083882372
'_wrapWidths': [193.4186083882372, 193.4186083882372]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=135.041259765625, descent=-2.0419921875, extraSpace=58.3773486226122, fontSize=8.5, kind=1, lineBreak=False, maxWidth=193.4186083882372, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='旧场景不一致', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/CLI', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='审计超时单独标记', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">不能混入最终真值通过率</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='不能混入最终真值通过率', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 172.87674754941347
'_wrapWidths': [172.87674754941347, 172.87674754941347]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(79.37674754941347, ['不能混入最终真值通过率'])], link=[], rise=0, text='不能混入最终真值通过率', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

一次性原生审计替代了父版不稳定的gz model命令行请求链。插件验证场景，不给探索器提供未知地图。场景生成器和离线评估器使用真值做实验定义，与在线规划直接读取真值是不同的数据流。

代码依据：scripts/map_variants.py:13 [generate_room]

代码依据：src/gazebo_scene_audit/src/scene_pose_audit.cpp:1

代码依据：scripts/audit_scene.py:7 [compare_scene]

## 21 一轮闭环的伪代码与时序

下面为按源码整理的逻辑摘要，不是可直接替换运行代码的简化控制器。关键是保留“异步规划、动作生命周期、任务阶段和独立评估”四种状态。

每1仿真秒 tick(): 刷新位姿TF与 map_from_odom 如SLAM地图时间戳变化: 更新/map与版本号 检查就绪、足迹/路径原始头时间、取消状态 处理最多一次Nav2重置与健康超时 Mission.tick(): 启动 / 健康 / 全局预算 对过期或35秒无平移的活动目标: 取消并分类 EXPLORE且空闲: 异步生成候选 → Nav2路径查询 候选完成后: 最新图空闲重检 → 贪心选目标 RETURN且空闲: 转换实际部署点 → 查询路径 → 派发 每30秒及结束时: 导出当前地图与日志

独立 on_map(): 若距上次评估足够久: 统计C_free和C_ROI 发布 /v4/evaluation监督器 on_evaluation(): EXPLORE且严格双门槛通过 → RETURN并取消探索目标动作 on_goal_done(): 普通成功/失败 → 更新目标状态、重试与失败记忆 返航成功 → 额外核验部署点误差 全部返回 → COMPLETE

规划工作线程max_workers=1，使大量候选路径请求不直接阻塞ROS回调；生命周期重置有单独线程。虽然目标和多数超时使用仿真时间，RPC等待仍有墙时截止，所以机器过载可能改变服务返回/候选集合。

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:821 [tick]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:485 [plan_candidates]

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:530 [on_goal_accepted]

## 22 参数总表与源码阅读路线

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">层</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='层', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(78.18148834336885, ['层'])], link=[], rise=0, text='层', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">关键配置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='关键配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(161.23112552107463, ['关键配置'])], link=[], rise=0, text='关键配置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">源码入口</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='源码入口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(151.3629766867377, ['源码入口'])], link=[], rise=0, text='源码入口', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">传感器 </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">SLAM</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='传感器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=56.092529296875, descent=-2.0419921875, extraSpace=30.588959046493855, fontSize=8.5, kind=1, lineBreak=False, maxWidth=86.68148834336885, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='传感器 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">180</font><font name="CN">束、</font><font name="Latin">3Hz</font><font name="CN">、</font><font name="Latin">10m</font><font name="CN">；栅格</font><font name="Latin">0.1m</font><font name="CN">、地图</font><font name="Latin">2s</font><font name="CN">、关闭</font><font name="Latin">loop</font><font name="CN"> </font><font name="Latin">closing</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='180', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='束、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；栅格', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.1m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、关闭', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='loop', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='closing', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=197.977783203125, descent=-2.0419921875, extraSpace=10.015793489824631, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='180', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='束、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='10m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；栅格', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.1m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、关闭', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=50.190673828125, descent=-2.0419921875, extraSpace=145.04045169294963, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='loop', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='closing', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">scripts/run_test.py::make_model</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">make_configs</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scripts/run_test.py::make_model', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='make_configs', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=189.49853515625, descent=-2.0419921875, extraSpace=39.01605285861271, fontSize=8.5, kind=1, lineBreak=False, maxWidth=185.3629766867377, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scripts/run_test.py::make_model', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=58.32958984375, descent=-2.0419921875, extraSpace=127.03338684298771, fontSize=8.5, kind=1, lineBreak=False, maxWidth=185.3629766867377, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='make_configs', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">候选</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='候选', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(69.68148834336885, ['候选'])], link=[], rise=0, text='候选', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">最多</font><font name="Latin">160</font><font name="CN">簇，每簇</font><font name="Latin">≤4</font><font name="CN">样本；最多</font><font name="Latin">40</font><font name="CN">条</font><font name="Latin">Nav2</font><font name="CN">查询</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='最多', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='160', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='簇，每簇', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤4', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='样本；最多', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='40', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='条', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='查询', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=180.5751953125, descent=-2.0419921875, extraSpace=14.655930208574631, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='最多', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='160', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='簇，每簇', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='≤4', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='样本；最多', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='40', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='条', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='查询', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">planner.py::plan</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='planner.py::plan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(115.69036926486271, ['planner.py::plan'])], link=[], rise=0, text='planner.py::plan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">收益 </font><font name="Latin">/</font><font name="CN"> 评分</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='收益 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 评分', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=41.31298828125, descent=-2.0419921875, extraSpace=45.368500062118855, fontSize=8.5, kind=1, lineBreak=False, maxWidth=86.68148834336885, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='收益 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 评分', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">48</font><font name="CN">评分射线、</font><font name="Latin">3.2m</font><font name="CN">、首未知停止；</font><font name="Latin">v_score=0.22m/s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='48', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='评分射线、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3.2m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、首未知停止；', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='v_score=0.22m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=201.248291015625, descent=-2.0419921875, extraSpace=60.61735598982463, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='48', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='评分射线、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='3.2m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、首未知停止；', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=73.9267578125, descent=-2.0419921875, extraSpace=121.30436770857463, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='v_score=0.22m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">planner.py::visible_unknown</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">plan</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='planner.py::visible_unknown', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='plan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=147.027587890625, descent=-2.0419921875, extraSpace=38.33538879611271, fontSize=8.5, kind=1, lineBreak=False, maxWidth=185.3629766867377, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='planner.py::visible_unknown', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='plan', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">区域 </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">lease</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='区域 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=46.770751953125, descent=-2.0419921875, extraSpace=39.910736390243855, fontSize=8.5, kind=1, lineBreak=False, maxWidth=86.68148834336885, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='区域 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">2m</font><font name="CN">分桶；</font><font name="Latin">lease50s</font><font name="CN">；地图版本变化可释放</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分桶；', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lease50s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；地图版本变化可释放', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=161.89013671875, descent=-2.0419921875, extraSpace=33.34098880232463, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='2m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='分桶；', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lease50s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；地图版本变化可释放', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">planner.py::region_id</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">allocator.py</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='planner.py::region_id', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='allocator.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=147.87841796875, descent=-2.0419921875, extraSpace=37.48455871798771, fontSize=8.5, kind=1, lineBreak=False, maxWidth=185.3629766867377, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='planner.py::region_id', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='allocator.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">执行 </font><font name="Latin">/</font><font name="CN"> 平滑</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='执行 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 平滑', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=41.31298828125, descent=-2.0419921875, extraSpace=45.368500062118855, fontSize=8.5, kind=1, lineBreak=False, maxWidth=86.68148834336885, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='执行 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 平滑', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">NavFn</font><font name="CN"> </font><font name="Latin">Dijkstra</font><font name="CN">；</font><font name="Latin">RPP8Hz</font><font name="CN">；平滑</font><font name="Latin">20Hz</font><font name="CN">、</font><font name="Latin">0.26m/s</font><font name="CN">上限</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavFn', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Dijkstra', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP8Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；平滑', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.26m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=201.339599609375, descent=-2.0419921875, extraSpace=2.391525911699631, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='NavFn', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Dijkstra', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP8Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；平滑', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='、', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.26m/s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=17.0, descent=-2.025390625, extraSpace=178.23112552107463, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='上限', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">run_test.py::make_configs</font><font name="CN"> </font><font name="Latin">+</font><font name="CN"> 系统模板</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='run_test.py::make_configs', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 系统模板', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=157.5986328125, descent=-2.0419921875, extraSpace=27.76434387423771, fontSize=8.5, kind=1, lineBreak=False, maxWidth=185.3629766867377, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='run_test.py::make_configs', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 系统模板', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">安全 </font><font name="Latin">/</font><font name="CN"> 监督</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='安全 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=41.31298828125, descent=-2.0419921875, extraSpace=45.368500062118855, fontSize=8.5, kind=1, lineBreak=False, maxWidth=86.68148834336885, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='安全 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">激光门</font><font name="Latin">20Hz</font><font name="CN">；</font><font name="Latin">scan</font><font name="CN">接收</font><font name="Latin">0.7s</font><font name="CN">；平移</font><font name="Latin">35s</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='激光门', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scan', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='接收', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.7s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；平移', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='35s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=151.0576171875, descent=-2.0419921875, extraSpace=44.17350833357463, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='激光门', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='20Hz', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scan', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='接收', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.7s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；平移', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='35s', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">safety_node.py</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">ros_runtime.py::tick</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='safety_node.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ros_runtime.py::tick', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=157.1171875, descent=-2.0419921875, extraSpace=28.24578918673771, fontSize=8.5, kind=1, lineBreak=False, maxWidth=185.3629766867377, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='safety_node.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ros_runtime.py::tick', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">预算 </font><font name="Latin">/</font><font name="CN"> 返回</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='预算 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 返回', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 86.68148834336885
'_wrapWidths': [86.68148834336885, 86.68148834336885]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=41.31298828125, descent=-2.0419921875, extraSpace=45.368500062118855, fontSize=8.5, kind=1, lineBreak=False, maxWidth=86.68148834336885, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='预算 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 返回', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">任务</font><font name="Latin">700s</font><font name="CN">；目标</font><font name="Latin">70</font><font name="CN">～</font><font name="Latin">150s</font><font name="CN">；返航</font><font name="Latin">XY0.20m</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> 核验</font><font name="Latin">0.35m</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='700s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='70', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='～', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='150s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；返航', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='XY0.20m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 核验', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 195.23112552107463
'_wrapWidths': [195.23112552107463, 195.23112552107463]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=196.5625, descent=-2.0419921875, extraSpace=4.076584505449631, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='700s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；目标', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='70', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='～', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='150s', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='；返航', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='XY0.20m', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 核验', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=27.205810546875, descent=-2.0419921875, extraSpace=168.02531497419963, fontSize=8.5, kind=1, lineBreak=False, maxWidth=195.23112552107463, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.35m', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">mission.py</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">navigation_health.py</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='mission.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='navigation_health.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 185.3629766867377
'_wrapWidths': [185.3629766867377, 185.3629766867377]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=142.047119140625, descent=-2.0419921875, extraSpace=43.31585754611271, fontSize=8.5, kind=1, lineBreak=False, maxWidth=185.3629766867377, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='mission.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='navigation_health.py', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

建议按以下顺序看代码：model.py理解数据结构 → mission.py理解阶段 → planner.py理解目标 → ros_runtime.py理解ROS拼装与异步回调 → run_test.py与launch理解真正启用的参数 → safety.py理解最终速度门 → evaluator理解真值口径 → audit插件与报告脚本理解证据链。

不要只看类构造默认值或文件顶部注释：运行构造器可能覆盖默认值，某些注释保留双机描述，而入口已经限制单机。PDF中的数字以运行器覆盖值和本次生成YAML为准。

代码依据：src/active_slam_v4/launch/v4_test.launch.py:74 [generate_launch_description]

## 23 已有实验结果：四组验收与一次补充测试

以下数据来自冻结版原始CSV。原四组是预先固定的功能验收，额外一组是在冻结后随机选择种子的补充测试；两类数据分开统计。本次新开的484794/677270在后附章节单列。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">地图</font><font name="Latin">/</font><font name="CN">策略</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='策略', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 104.14052089642644
'_wrapWidths': [104.14052089642644, 104.14052089642644]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=36.86376953125, descent=-2.0419921875, extraSpace=67.27675136517644, fontSize=8.5, kind=1, lineBreak=False, maxWidth=104.14052089642644, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='策略', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">探索率 </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">ROI</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索率 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 142.85402786190193
'_wrapWidths': [142.85402786190193, 142.85402786190193]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=47.916259765625, descent=-2.0419921875, extraSpace=94.93776809627693, fontSize=8.5, kind=1, lineBreak=False, maxWidth=142.85402786190193, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索率 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">达标 </font><font name="Latin">/</font><font name="CN"> 总任务</font><font name="Latin">(s)</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='达标 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 总任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='(s)', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 123.49727437916417
'_wrapWidths': [123.49727437916417, 123.49727437916417]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=60.873779296875, descent=-2.0419921875, extraSpace=62.62349508228917, fontSize=8.5, kind=1, lineBreak=False, maxWidth=123.49727437916417, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='达标 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 总任务', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='(s)', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">返航误差</font><font name="Latin">(m)</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='返航误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='(m)', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 84.7837674136887
'_wrapWidths': [84.7837674136887, 84.7837674136887]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=48.912353515625, descent=-2.0419921875, extraSpace=35.87141389806369, fontSize=8.5, kind=1, lineBreak=False, maxWidth=84.7837674136887, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='返航误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='(m)', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| --- | --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">7/11</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='7/11', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 104.14052089642644
'_wrapWidths': [104.14052089642644, 104.14052089642644]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(85.05287441205144, ['7/11'])], link=[], rise=0, text='7/11', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">95.73%</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">96.46%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.73%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='96.46%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 142.85402786190193
'_wrapWidths': [142.85402786190193, 142.85402786190193]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=72.1337890625, descent=-2.0419921875, extraSpace=70.72023879940193, fontSize=8.5, kind=1, lineBreak=False, maxWidth=142.85402786190193, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.73%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='96.46%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">522.0</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">583.0</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='522.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='583.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 123.49727437916417
'_wrapWidths': [123.49727437916417, 123.49727437916417]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=55.98046875, descent=-2.0419921875, extraSpace=67.51680562916417, fontSize=8.5, kind=1, lineBreak=False, maxWidth=123.49727437916417, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='522.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='583.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.198</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.198', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 84.7837674136887
'_wrapWidths': [84.7837674136887, 84.7837674136887]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(60.45002717931369, ['0.198'])], link=[], rise=0, text='0.198', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">9/13</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='9/13', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 104.14052089642644
'_wrapWidths': [104.14052089642644, 104.14052089642644]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(85.05287441205144, ['9/13'])], link=[], rise=0, text='9/13', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">95.22%</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">95.39%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.22%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.39%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 142.85402786190193
'_wrapWidths': [142.85402786190193, 142.85402786190193]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=72.1337890625, descent=-2.0419921875, extraSpace=70.72023879940193, fontSize=8.5, kind=1, lineBreak=False, maxWidth=142.85402786190193, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.22%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.39%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">550.0</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">618.0</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='550.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='618.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 123.49727437916417
'_wrapWidths': [123.49727437916417, 123.49727437916417]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=55.98046875, descent=-2.0419921875, extraSpace=67.51680562916417, fontSize=8.5, kind=1, lineBreak=False, maxWidth=123.49727437916417, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='550.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='618.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.195</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.195', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 84.7837674136887
'_wrapWidths': [84.7837674136887, 84.7837674136887]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(60.45002717931369, ['0.195'])], link=[], rise=0, text='0.195', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">101/501</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='101/501', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 104.14052089642644
'_wrapWidths': [104.14052089642644, 104.14052089642644]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(68.82899745892644, ['101/501'])], link=[], rise=0, text='101/501', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">98.26%</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">98.54%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='98.26%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='98.54%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 142.85402786190193
'_wrapWidths': [142.85402786190193, 142.85402786190193]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=72.1337890625, descent=-2.0419921875, extraSpace=70.72023879940193, fontSize=8.5, kind=1, lineBreak=False, maxWidth=142.85402786190193, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='98.26%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='98.54%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">626.0</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">689.0</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='626.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='689.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 123.49727437916417
'_wrapWidths': [123.49727437916417, 123.49727437916417]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=55.98046875, descent=-2.0419921875, extraSpace=67.51680562916417, fontSize=8.5, kind=1, lineBreak=False, maxWidth=123.49727437916417, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='626.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='689.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.204</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.204', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 84.7837674136887
'_wrapWidths': [84.7837674136887, 84.7837674136887]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(60.45002717931369, ['0.204'])], link=[], rise=0, text='0.204', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">202/602</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='202/602', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 104.14052089642644
'_wrapWidths': [104.14052089642644, 104.14052089642644]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(68.82899745892644, ['202/602'])], link=[], rise=0, text='202/602', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">95.59%</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">95.73%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.59%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.73%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 142.85402786190193
'_wrapWidths': [142.85402786190193, 142.85402786190193]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=72.1337890625, descent=-2.0419921875, extraSpace=70.72023879940193, fontSize=8.5, kind=1, lineBreak=False, maxWidth=142.85402786190193, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.59%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.73%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">474.0</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">536.0</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='474.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='536.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 123.49727437916417
'_wrapWidths': [123.49727437916417, 123.49727437916417]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=55.98046875, descent=-2.0419921875, extraSpace=67.51680562916417, fontSize=8.5, kind=1, lineBreak=False, maxWidth=123.49727437916417, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='474.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='536.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.141</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.141', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 84.7837674136887
'_wrapWidths': [84.7837674136887, 84.7837674136887]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(60.45002717931369, ['0.141'])], link=[], rise=0, text='0.141', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">375954/868225</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='375954/868225', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 104.14052089642644
'_wrapWidths': [104.14052089642644, 104.14052089642644]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(36.38124355267644, ['375954/868225'])], link=[], rise=0, text='375954/868225', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">95.22%</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">95.34%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.22%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.34%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 142.85402786190193
'_wrapWidths': [142.85402786190193, 142.85402786190193]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=72.1337890625, descent=-2.0419921875, extraSpace=70.72023879940193, fontSize=8.5, kind=1, lineBreak=False, maxWidth=142.85402786190193, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.22%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='95.34%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">558.0</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">587.0</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='558.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='587.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 123.49727437916417
'_wrapWidths': [123.49727437916417, 123.49727437916417]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=55.98046875, descent=-2.0419921875, extraSpace=67.51680562916417, fontSize=8.5, kind=1, lineBreak=False, maxWidth=123.49727437916417, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='558.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='587.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.170</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.170', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 84.7837674136887
'_wrapWidths': [84.7837674136887, 84.7837674136887]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(60.45002717931369, ['0.170'])], link=[], rise=0, text='0.170', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

原四组的132次已记录导航结果全部成功，目标超时、输入故障、重置、Spin恢复请求均为0；最长同目标无0.12m净位移区间约4秒。该量由约1Hz记录估计，不是碰撞计数，也不包含所有可能的局部回旋行为。

![图示](figures/reference_coverage.png)

曲线横轴为任务仿真时间，不是墙上时间。绿色101/501存在较长覆盖平台，但仍在预算内完成；这说明“可靠完成”与“始终保持最高探索速度”是两个不同的目标。原四组不构成多地图族、多重复种子的统计优势证明。

来源：VALIDATION_RESULTS.csv、SUPPLEMENTARY_RESULTS.csv、各run/evaluation.csv、mission_events.jsonl。

## 24 建图输出：地图图像应该怎样解读

![图示](figures/reference_map202.png)

示例为已验收地图种子202的最终SLAM地图，显示方式与冻结版一致：浅蓝为空闲、深色为障碍、黄色为未知；8倍放大只影响显示，不增加地图空间精度。黄色也可能出现在障碍内部或被遮挡区域。

PGM/YAML用于标准栅格地图存储，PNG是便于查看的统一配色预览。一个0.1m栅格即使放大8×8像素，真实边长仍然是0.1m。几何画布大小、已知区域大小和真值可达面积也不是同一个概念。

95%探索率允许仍有约5%的真值可达空闲区未被SLAM判定为空闲，因此最终PNG不必完全去除黄色。反过来，一张看起来大部分浅蓝的图，也不能替代固定分母、真值坐标对齐和场景审计。

代码依据：src/active_slam_v4/active_slam_v4/ros_runtime.py:763 [export_map]

代码依据：src/active_slam_v4/active_slam_v4/preview.py:6 [write_map_preview]

## 25 工程贡献、算法边界与可改进项

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">类别</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='类别', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 92.45342445401873
'_wrapWidths': [92.45342445401873, 92.45342445401873]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(75.45342445401873, ['类别'])], link=[], rise=0, text='类别', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">可据代码与证据说明的内容</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='可据代码与证据说明的内容', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(85.41108304858119, ['可据代码与证据说明的内容'])], link=[], rise=0, text='可据代码与证据说明的内容', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">当前不能直接推断</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='当前不能直接推断', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(119.41108304858119, ['当前不能直接推断'])], link=[], rise=0, text='当前不能直接推断', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">探索架构</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索架构', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 92.45342445401873
'_wrapWidths': [92.45342445401873, 92.45342445401873]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(58.45342445401873, ['探索架构'])], link=[], rise=0, text='探索架构', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">SLAM</font><font name="CN">前沿、安全观测位姿、实际</font><font name="Latin">Nav2</font><font name="CN">路径成本、状态机串成闭环</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='前沿、安全观测位姿、实际', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='路径成本、状态机串成闭环', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=189.784912109375, descent=-2.0419921875, extraSpace=-2.3738290607938097, fontSize=8.5, kind=1, lineBreak=False, maxWidth=187.4110830485812, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='前沿、安全观测位姿、实际', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='路径成本、', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=59.5, descent=-2.025390625, extraSpace=127.91108304858119, fontSize=8.5, kind=1, lineBreak=False, maxWidth=187.4110830485812, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='状态机串成闭环', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">前沿探索或</font><font name="Latin">RPP</font><font name="CN">算法本身为本项目原创</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='前沿探索或', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='算法本身为本项目原创', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=143.657470703125, descent=-2.0419921875, extraSpace=43.75361234545619, fontSize=8.5, kind=1, lineBreak=False, maxWidth=187.4110830485812, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='前沿探索或', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='算法本身为本项目原创', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">导航可靠性</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='导航可靠性', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 92.45342445401873
'_wrapWidths': [92.45342445401873, 92.45342445401873]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(49.95342445401873, ['导航可靠性'])], link=[], rise=0, text='导航可靠性', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">TF</font><font name="CN">死锁证据、本地修复、有限恢复、取消屏障和输入监督</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='死锁证据、本地修复、有限恢复、取消屏障和输入监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=188.581298828125, descent=-2.0419921875, extraSpace=7.32978422045619, fontSize=8.5, kind=1, lineBreak=False, maxWidth=187.4110830485812, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='TF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='死锁证据、本地修复、有限恢复、取消屏障和', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=34.0, descent=-2.025390625, extraSpace=153.4110830485812, fontSize=8.5, kind=1, lineBreak=False, maxWidth=187.4110830485812, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='输入监督', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">任意障碍密度下永不碰撞或卡住</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='任意障碍密度下永不碰撞或卡住', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(68.41108304858119, ['任意障碍密度下永不碰撞或卡住'])], link=[], rise=0, text='任意障碍密度下永不碰撞或卡住', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">任务闭环</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='任务闭环', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 92.45342445401873
'_wrapWidths': [92.45342445401873, 92.45342445401873]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(58.45342445401873, ['任务闭环'])], link=[], rise=0, text='任务闭环', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">双覆盖门槛、动态部署点转换、返航位置核验</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='双覆盖门槛、动态部署点转换、返航位置核验', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(17.41108304858119, ['双覆盖门槛、动态部署点转换、返航位置核验'])], link=[], rise=0, text='双覆盖门槛、动态部署点转换、返航位置核验', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">真实机器人具有相同返航精度</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='真实机器人具有相同返航精度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(76.91108304858119, ['真实机器人具有相同返航精度'])], link=[], rise=0, text='真实机器人具有相同返航精度', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实验可审计性</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实验可审计性', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 92.45342445401873
'_wrapWidths': [92.45342445401873, 92.45342445401873]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(41.45342445401873, ['实验可审计性'])], link=[], rise=0, text='实验可审计性', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际障碍坐标核对、种子与哈希、失败原始记录、阶段时间分离</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际障碍坐标核对、种子与哈希、失败原始记录、阶段时间分离', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 25.0
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(0.41108304858119027, ['实际障碍坐标核对、种子与哈希、失败原始记录、']), (136.4110830485812, ['阶段时间分离'])], link=[], rise=0, text='实际障碍坐标核对、种子与哈希、失败原始记录、阶段时间分离', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">少量单模板测试代表普遍泛化优势</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='少量单模板测试代表普遍泛化优势', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(59.91108304858119, ['少量单模板测试代表普遍泛化优势'])], link=[], rise=0, text='少量单模板测试代表普遍泛化优势', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">研究创新</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='研究创新', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 92.45342445401873
'_wrapWidths': [92.45342445401873, 92.45342445401873]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(58.45342445401873, ['研究创新'])], link=[], rise=0, text='研究创新', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">可作为系统集成与可靠性改进的工程贡献</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='可作为系统集成与可靠性改进的工程贡献', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(34.41108304858119, ['可作为系统集成与可靠性改进的工程贡献'])], link=[], rise=0, text='可作为系统集成与可靠性改进的工程贡献', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">未经文献对照就宣称新的强化学习</font><font name="Latin">/</font><font name="CN">信息论主动</font><font name="Latin">SLAM</font><font name="CN">算法</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未经文献对照就宣称新的强化学习', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='信息论主动', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='算法', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 187.4110830485812
'_wrapWidths': [187.4110830485812, 187.4110830485812]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=188.8095703125, descent=-2.0419921875, extraSpace=14.54731351733119, fontSize=8.5, kind=1, lineBreak=False, maxWidth=187.4110830485812, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='未经文献对照就宣称新的强化学习', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='信息论主动', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.507812500000001, currentWidth=40.279541015625, descent=-2.0419921875, extraSpace=147.1315420329562, fontSize=8.5, kind=1, lineBreak=False, maxWidth=187.4110830485812, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SLAM', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='算法', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

明确的后续能力缺口：语义房间/稀疏拓扑层、路径访问历史和真实覆盖增量反馈、位姿不确定性/主动回环目标、动态障碍、未知初始对齐多机融合，以及同时双机导航的会车与死锁处理。它们是后续方向，没有在本次文档中伪装为已部署功能。

现有机制也有可测量的局限：收益只统计首个未知边界，可能偏好低真实增量的目标；区域分桶不是全局最优路线；成功目标若移动足够远但新增覆盖极低，当前没有独立的“真实收益学习”更新。应先收集配对日志与消融结果，再决定是否新增模型。

如果后续引入强化学习，需要明确状态、动作、奖励、Q/网络更新、训练和测试隔离；仅给启发式分数或累计收益命名为“奖励”，不会使现有代码自动成为强化学习。

## 26 冻结与复现：怎样让别人检查同一套系统

冻结包标识为V4_optimized_frozen_2026-10-18。ZIP的SHA256为b971098c73c25c99b683b3534a3f8d9a954930543514d9ffc485d4a18eb03f00。核心源码和运行参数生成器与已验收协议一致；本PDF单独放在说明文档目录，没有改写原ZIP。

参考环境：Ubuntu22.04 x86_64、Python3.10、ROS2 Humble、Gazebo Classic11.10.2、Nav2 1.1.20、slam_toolbox2.6.10。本地vendor固定tf2/tf2_ros0.25.24和Cyclone DDS。模型资源依赖TurtleBot3 Gazebo包。准确Debian构建版本见environment/。

python3 scripts/verify_release.pypython3 scripts/check_environment.pybash scripts/build_isolated.shbash scripts/run_gui.sh --map-seed 7 --policy-seed 11# 原四组重新验收python3 scripts/run_validation_suite.pypython3 scripts/export_reproduction_report.py

固定两个种子、生成器、源世界和参数可以重建同一输入。策略种子对坐标字符串做BLAKE2b微扰；SLAM坐标或消息时序发生小变化，后续候选顺序也可能不同，因此相同种子不保证轨迹和耗时逐次相同。

保存世界文件哈希、完整生成YAML、依赖版本和原始结果，报告重复运行的分布，才是可核查的复现。墙上时间受硬件/负载影响；某些RPC与启动保护还采用墙时截止，不能把运行器描述为完全硬件无关。

每个新实验都有独立ROS domain、Gazebo master和UUID目录。报告工具写入reproduction_reports，保留发布参考表。运行失败与未运行组分别记录，不从成功率分母里删除。

## 27 数据文件索引与术语对照

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">文件</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='文件', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(146.5612525178539, ['文件'])], link=[], rise=0, text='文件', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">回答的问题</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='回答的问题', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(273.2143380333273, ['回答的问题'])], link=[], rise=0, text='回答的问题', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">manifest.json</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='manifest.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(106.26095954910389, ['manifest.json'])], link=[], rise=0, text='manifest.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">用了什么源文件、种子、参数生成器、运行库和哈希？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='用了什么源文件、种子、参数生成器、运行库和哈希？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(111.7143380333273, ['用了什么源文件、种子、参数生成器、运行库和哈希？'])], link=[], rise=0, text='用了什么源文件、种子、参数生成器、运行库和哈希？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">world.sdf</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">scene_actual_poses.json</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='world.sdf', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scene_actual_poses.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=150.61767578125, descent=-2.0419921875, extraSpace=12.943576736603887, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='world.sdf', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scene_actual_poses.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">定义的障碍布局与</font><font name="Latin">Gazebo</font><font name="CN">实际加载位置分别是什么？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='定义的障碍布局与', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际加载位置分别是什么？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=202.08251953125, descent=-2.0419921875, extraSpace=113.6318185020773, fontSize=8.5, kind=1, lineBreak=False, maxWidth=315.7143380333273, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='定义的障碍布局与', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际加载位置分别是什么？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">scene_audit.json</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='scene_audit.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(92.59787361160389, ['scene_audit.json'])], link=[], rise=0, text='scene_audit.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">八个静态模型的实际坐标是否和独立评估几何一致？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='八个静态模型的实际坐标是否和独立评估几何一致？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(120.2143380333273, ['八个静态模型的实际坐标是否和独立评估几何一致？'])], link=[], rise=0, text='八个静态模型的实际坐标是否和独立评估几何一致？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">deployment_odom.json</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">result.json</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='deployment_odom.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='result.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=150.875, descent=-2.0419921875, extraSpace=12.686252517853887, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='deployment_odom.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='result.json', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">实际部署点、最终位姿、覆盖率与终止原因是什么？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='实际部署点、最终位姿、覆盖率与终止原因是什么？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(120.2143380333273, ['实际部署点、最终位姿、覆盖率与终止原因是什么？'])], link=[], rise=0, text='实际部署点、最终位姿、覆盖率与终止原因是什么？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">evaluation.csv</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='evaluation.csv', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(102.01926033035389, ['evaluation.csv'])], link=[], rise=0, text='evaluation.csv', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">覆盖率随仿真时间怎样变化？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='覆盖率随仿真时间怎样变化？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(205.2143380333273, ['覆盖率随仿真时间怎样变化？'])], link=[], rise=0, text='覆盖率随仿真时间怎样变化？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">navigation_health.csv</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='navigation_health.csv', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(70.69626228347889, ['navigation_health.csv'])], link=[], rise=0, text='navigation_health.csv', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">路径</font><font name="Latin">/</font><font name="CN">足迹输入是否新鲜，机器人是否移动，最后输出什么速度？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='路径', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='足迹输入是否新鲜，机器人是否移动，最后输出什么速度？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=240.86376953125, descent=-2.0419921875, extraSpace=74.8505685020773, fontSize=8.5, kind=1, lineBreak=False, maxWidth=315.7143380333273, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='路径', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='足迹输入是否新鲜，机器人是否移动，最后输出什么速度？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">mission_events.jsonl</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">safety_events.jsonl</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='mission_events.jsonl', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='safety_events.jsonl', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=163.69140625, descent=-2.0419921875, extraSpace=68.47165290847889, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='mission_events.jsonl', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=81.551025390625, descent=-2.0419921875, extraSpace=82.01022712722889, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='safety_events.jsonl', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">目标何时分配</font><font name="Latin">/</font><font name="CN">失败</font><font name="Latin">/</font><font name="CN">取消、何时返航、安全门是否介入？</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标何时分配', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='失败', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='取消、何时返航、安全门是否介入？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=209.7275390625, descent=-2.0419921875, extraSpace=105.9867989708273, fontSize=8.5, kind=1, lineBreak=False, maxWidth=315.7143380333273, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='目标何时分配', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='失败', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='取消、何时返航、安全门是否介入？', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">fused_slam_map.pgm</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">yaml</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">preview.png</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='fused_slam_map.pgm', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='yaml', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='preview.png', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=164.7705078125, descent=-2.0419921875, extraSpace=35.18552009597889, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='fused_slam_map.pgm', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='yaml', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=52.572998046875, descent=-2.0419921875, extraSpace=110.98825447097889, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='preview.png', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">标准地图和统一</font><font name="Latin">8</font><font name="CN">倍显示预览；不是</font><font name="Latin">SDF</font><font name="CN">真值地图</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='标准地图和统一', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='倍显示预览；不是', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SDF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='真值地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=183.73779296875, descent=-2.0419921875, extraSpace=131.9765450645773, fontSize=8.5, kind=1, lineBreak=False, maxWidth=315.7143380333273, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='标准地图和统一', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='8', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='倍显示预览；不是', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SDF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='真值地图', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">ROOT_CAUSE</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">RETURN_FIX</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">SCENE_FIX</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROOT_CAUSE', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RETURN_FIX', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SCENE_FIX', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 163.5612525178539
'_wrapWidths': [163.5612525178539, 163.5612525178539]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=164.592041015625, descent=-2.0419921875, extraSpace=39.04538337722889, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROOT_CAUSE', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RETURN_FIX', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=45.899169921875, descent=-2.0419921875, extraSpace=117.66208259597889, fontSize=8.5, kind=1, lineBreak=False, maxWidth=163.5612525178539, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='SCENE_FIX', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">死锁、返航控制及场景一致性的诊断与修改依据</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='死锁、返航控制及场景一致性的诊断与修改依据', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 315.7143380333273
'_wrapWidths': [315.7143380333273, 315.7143380333273]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(137.2143380333273, ['死锁、返航控制及场景一致性的诊断与修改依据'])], link=[], rise=0, text='死锁、返航控制及场景一致性的诊断与修改依据', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">术语</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='术语', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(114.79302587176605, ['术语'])], link=[], rise=0, text='术语', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">本版语境</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='本版语境', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(313.4825646794151, ['本版语境'])], link=[], rise=0, text='本版语境', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">frontier</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(100.29986180926605, ['frontier'])], link=[], rise=0, text='frontier', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">已知可达空闲格与未知相邻的边界</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已知可达空闲格与未知相邻的边界', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(219.98256467941508, ['已知可达空闲格与未知相邻的边界'])], link=[], rise=0, text='已知可达空闲格与未知相邻的边界', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">观测位姿</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='观测位姿', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(97.79302587176605, ['观测位姿'])], link=[], rise=0, text='观测位姿', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">已知可通行区内的位置</font><font name="Latin">+</font><font name="CN">朝向</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已知可通行区内的位置', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='朝向', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=109.1220703125, descent=-2.0419921875, extraSpace=238.36049436691508, fontSize=8.5, kind=1, lineBreak=False, maxWidth=347.4825646794151, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已知可通行区内的位置', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='+', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='朝向', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">IG</font><font name="CN">代理</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='IG', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='代理', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=26.093505859375, descent=-2.0419921875, extraSpace=105.69952001239105, fontSize=8.5, kind=1, lineBreak=False, maxWidth=131.79302587176605, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='IG', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='代理', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">48</font><font name="CN">评分射线首个未知格的去重计数</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='48', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='评分射线首个未知格的去重计数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=129.81591796875, descent=-2.0419921875, extraSpace=217.66664671066508, fontSize=8.5, kind=1, lineBreak=False, maxWidth=347.4825646794151, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='48', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='评分射线首个未知格的去重计数', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Nav2</font><font name="CN"> </font><font name="Latin">goal</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='goal', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=42.396240234375, descent=-2.0419921875, extraSpace=89.39678563739105, fontSize=8.5, kind=1, lineBreak=False, maxWidth=131.79302587176605, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='goal', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">要去的位置，不是要执行的速度动作</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='要去的位置，不是要执行的速度动作', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(211.48256467941508, ['要去的位置，不是要执行的速度动作'])], link=[], rise=0, text='要去的位置，不是要执行的速度动作', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">lease</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(109.33526219989105, ['lease'])], link=[], rise=0, text='lease', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">临时区域归属，当前单机仅用于候选选择框架</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='临时区域归属，当前单机仅用于候选选择框架', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(177.48256467941508, ['临时区域归属，当前单机仅用于候选选择框架'])], link=[], rise=0, text='临时区域归属，当前单机仅用于候选选择框架', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">策略种子</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='策略种子', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(97.79302587176605, ['策略种子'])], link=[], rise=0, text='策略种子', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">同分附近目标偏好，不是强化学习权重</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='同分附近目标偏好，不是强化学习权重', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(202.98256467941508, ['同分附近目标偏好，不是强化学习权重'])], link=[], rise=0, text='同分附近目标偏好，不是强化学习权重', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">RTF</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> 墙上时间</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RTF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 墙上时间', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 131.79302587176605
'_wrapWidths': [131.79302587176605, 131.79302587176605]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=57.30029296875, descent=-2.0419921875, extraSpace=74.49273290301605, fontSize=8.5, kind=1, lineBreak=False, maxWidth=131.79302587176605, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RTF', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 墙上时间', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">计算运行效率相关量，与探索路径效率分开</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='计算运行效率相关量，与探索路径效率分开', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 347.4825646794151
'_wrapWidths': [347.4825646794151, 347.4825646794151]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(185.98256467941508, ['计算运行效率相关量，与探索路径效率分开'])], link=[], rise=0, text='计算运行效率相关量，与探索路径效率分开', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |

## 28 源码与官方参考

本手册的主要依据是冻结包中的源码与实际生成参数。章节底部给出了相对路径、函数和起始行号，便于在VSCode定位。入口/模型参数以scripts/run_test.py和src/active_slam_v4/launch/v4_test.launch.py为准；接口类默认值可能被运行构造器覆盖。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">编号</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='编号', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 33.75232641374374
'_wrapWidths': [33.75232641374374, 33.75232641374374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(16.752326413743738, ['编号'])], link=[], rise=0, text='编号', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">外部参考（只作为库接口与修复背景）</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='外部参考（只作为库接口与修复背景）', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 445.52326413743737
'_wrapWidths': [445.52326413743737, 445.52326413743737]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(301.02326413743737, ['外部参考（只作为库接口与修复背景）'])], link=[], rise=0, text='外部参考（只作为库接口与修复背景）', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">O1</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='O1', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 33.75232641374374
'_wrapWidths': [33.75232641374374, 33.75232641374374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(21.653937741868738, ['O1'])], link=[], rise=0, text='O1', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Nav2</font><font name="CN"> </font><font name="Latin">Humble</font><font name="CN"> </font><font name="Latin">RPP</font><font name="CN">官方源码：</font><link href="https://github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp" color="#087F8C"><font name="Latin">github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp</font></link>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Humble', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='官方源码：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp')], rise=0, text='github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp', textColor=Color(.031373,.498039,.54902,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 445.52326413743737
'_wrapWidths': [445.52326413743737, 445.52326413743737]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=447.441162109375, descent=-2.0419921875, extraSpace=3.4693090593123657, fontSize=8.5, kind=1, lineBreak=False, maxWidth=445.52326413743737, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Nav2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Humble', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='RPP', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='官方源码：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp')], rise=0, text='github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_p', textColor=Color(.031373,.498039,.54902,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=249.683349609375, descent=-2.0419921875, extraSpace=195.83991452806237, fontSize=8.5, kind=1, lineBreak=False, maxWidth=445.52326413743737, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp')], rise=0, text='ursuit_controller/src/regulated_pure_pursuit_controller.cpp', textColor=Color(.031373,.498039,.54902,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">O2</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='O2', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 33.75232641374374
'_wrapWidths': [33.75232641374374, 33.75232641374374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(21.653937741868738, ['O2'])], link=[], rise=0, text='O2', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">slam_toolbox</font><font name="CN"> </font><font name="Latin">Humble</font><font name="CN"> </font><font name="Latin">README</font><font name="CN">：</font><link href="https://github.com/SteveMacenski/slam_toolbox/blob/humble/README.md" color="#087F8C"><font name="Latin">github.com/SteveMacenski/slam_toolbox/blob/humble/README.md</font></link>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='slam_toolbox', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Humble', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='README', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/SteveMacenski/slam_toolbox/blob/humble/README.md')], rise=0, text='github.com/SteveMacenski/slam_toolbox/blob/humble/README.md', textColor=Color(.031373,.498039,.54902,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 445.52326413743737
'_wrapWidths': [445.52326413743737, 445.52326413743737]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=424.14501953125, descent=-2.0419921875, extraSpace=21.378244606187366, fontSize=8.5, kind=1, lineBreak=False, maxWidth=445.52326413743737, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='slam_toolbox', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Humble', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='README', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/SteveMacenski/slam_toolbox/blob/humble/README.md')], rise=0, text='github.com/SteveMacenski/slam_toolbox/blob/humble/README.md', textColor=Color(.031373,.498039,.54902,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">O3</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='O3', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 33.75232641374374
'_wrapWidths': [33.75232641374374, 33.75232641374374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(21.653937741868738, ['O3'])], link=[], rise=0, text='O3', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">geometry2</font><font name="CN"> </font><font name="Latin">Humble</font><font name="CN"> </font><font name="Latin">ABBA</font><font name="CN">死锁修复</font><font name="Latin">#990</font><font name="CN">：</font><link href="https://github.com/ros2/geometry2/pull/990" color="#087F8C"><font name="Latin">github.com/ros2/geometry2/pull/990</font></link>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='geometry2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Humble', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ABBA', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='死锁修复', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='#990', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros2/geometry2/pull/990')], rise=0, text='github.com/ros2/geometry2/pull/990', textColor=Color(.031373,.498039,.54902,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 445.52326413743737
'_wrapWidths': [445.52326413743737, 445.52326413743737]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=329.66552734375, descent=-2.0419921875, extraSpace=115.85773679368737, fontSize=8.5, kind=1, lineBreak=False, maxWidth=445.52326413743737, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='geometry2', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Humble', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ABBA', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='死锁修复', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='#990', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros2/geometry2/pull/990')], rise=0, text='github.com/ros2/geometry2/pull/990', textColor=Color(.031373,.498039,.54902,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">O4</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='O4', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 33.75232641374374
'_wrapWidths': [33.75232641374374, 33.75232641374374]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(21.653937741868738, ['O4'])], link=[], rise=0, text='O4', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">Gazebo</font><font name="CN"> </font><font name="Latin">ROS</font><font name="CN">差速驱动源码：</font><link href="https://github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp" color="#087F8C"><font name="Latin">github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp</font></link>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROS', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='差速驱动源码：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp')], rise=0, text='github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp', textColor=Color(.031373,.498039,.54902,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 445.52326413743737
'_wrapWidths': [445.52326413743737, 445.52326413743737]
'height': 25.0
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=448.752685546875, descent=-2.0419921875, extraSpace=2.0000707780623657, fontSize=8.5, kind=1, lineBreak=False, maxWidth=445.52326413743737, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='Gazebo', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROS', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='差速驱动源码：', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp')], rise=0, text='github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gaz', textColor=Color(.031373,.498039,.54902,1), us_lines=[])]), FragLine(ascent=6.458007812500001, currentWidth=95.11865234375, descent=-2.0419921875, extraSpace=350.40461179368737, fontSize=8.5, kind=1, lineBreak=False, maxWidth=445.52326413743737, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[(0, 'https://github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp')], rise=0, text='ebo_ros_diff_drive.cpp', textColor=Color(.031373,.498039,.54902,1), us_lines=[])])])
) #Paragraph,) |

这些上游链接的分支内容可能继续变化；复现实验优先对照冻结包的Debian版本、源文件哈希与实际参数快照。本文没有从上游文档推断本项目启用了全部库功能，也没有把未配置的闭环、A*或学习策略写成本版实现。

证据分类：①代码直接执行的事实；②由运行数据支持的功能结果；③关于局限的工程分析。未来研究方向仅出现在边界/后续章节，不计入当前成功率或实现功能。

文档生成日期按Asia/Shanghai（北京时间）记录。本文是配套技术手册，不替换冻结ZIP内的发布报告、原始数据或校验清单。

## 29 本次随机观察测试记录

本次观察测试：地图种子484794，策略种子677270；窗口启动后独立保存，未更改冻结版本。记录时刻：2026-10-18 18:11:45（北京时间）。

| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">项目</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='项目', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(138.75853018372703, ['项目'])], link=[], rise=0, text='项目', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">本次记录</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='本次记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(289.51706036745406, ['本次记录'])], link=[], rise=0, text='本次记录', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| --- | --- |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">任务状态</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='任务状态', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(121.75853018372703, ['任务状态'])], link=[], rise=0, text='任务状态', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">COMPLETE</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='COMPLETE', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='Latin', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(277.76315411745406, ['COMPLETE'])], link=[], rise=0, text='COMPLETE', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">探索率 </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">ROI</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索率 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=47.916259765625, descent=-2.0419921875, extraSpace=107.84227041810203, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.75853018372703, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='探索率 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='ROI', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">96.99755%</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">97.99519%</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='96.99755%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='97.99519%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=104.58154296875, descent=-2.0419921875, extraSpace=218.93551739870406, fontSize=8.5, kind=1, lineBreak=False, maxWidth=323.51706036745406, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='96.99755%', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='97.99519%', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">任务仿真时间</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='任务仿真时间', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(104.75853018372703, ['任务仿真时间'])], link=[], rise=0, text='任务仿真时间', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">574.0</font><font name="CN"> 秒</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='574.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 秒', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=35.058349609375, descent=-2.0419921875, extraSpace=288.45871075807906, fontSize=8.5, kind=1, lineBreak=False, maxWidth=323.51706036745406, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='574.0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 秒', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">返航位置误差</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='返航位置误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(104.75853018372703, ['返航位置误差'])], link=[], rise=0, text='返航位置误差', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0.157094</font><font name="CN"> 米</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.157094', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 米', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=51.2822265625, descent=-2.0419921875, extraSpace=272.23483380495406, fontSize=8.5, kind=1, lineBreak=False, maxWidth=323.51706036745406, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0.157094', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 米', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">场景审计</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='场景审计', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(121.75853018372703, ['场景审计'])], link=[], rise=0, text='场景审计', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">通过</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='通过', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaFrag(__tag__='font', ascent=8.5, bold=1, descent=-1.7000000000000002, fontName='CN', fontSize=8.5, greek=0, italic=1, kind=0, lines=[(306.51706036745406, ['通过'])], link=[], rise=0, text='通过', textColor=Color(.145098,.207843,.290196,1), us_lines=[])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">已记录导航成功 </font><font name="Latin">/</font><font name="CN"> 非成功</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已记录导航成功 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 非成功', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=92.31298828125, descent=-2.0419921875, extraSpace=63.44554190247703, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.75853018372703, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='已记录导航成功 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 非成功', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">36</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">0</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='36', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=23.536865234375, descent=-2.0419921875, extraSpace=299.98019513307906, fontSize=8.5, kind=1, lineBreak=False, maxWidth=323.51706036745406, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='36', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |
| (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="CN">输入故障 </font><font name="Latin">/</font><font name="CN"> 重置</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='输入故障 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 重置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 155.75853018372703
'_wrapWidths': [155.75853018372703, 155.75853018372703]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=58.31298828125, descent=-2.0419921875, extraSpace=97.44554190247703, fontSize=8.5, kind=1, lineBreak=False, maxWidth=155.75853018372703, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='输入故障 ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' 重置', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) | (Paragraph(
'caseSensitive': 1
'encoding': 'utf8'
'text': '<font name="Latin">0</font><font name="CN"> </font><font name="Latin">/</font><font name="CN"> </font><font name="Latin">0</font>'
'frags': [ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])]
'style': <ParagraphStyle 'cell'>
'bulletText': None
'debug': 0
'width': 323.51706036745406
'_wrapWidths': [323.51706036745406, 323.51706036745406]
'height': 12.5
'blPara': ParaLines(kind=1, lines=[FragLine(ascent=6.507812500000001, currentWidth=18.12890625, descent=-2.0419921875, extraSpace=305.38815411745406, fontSize=8.5, kind=1, lineBreak=False, maxWidth=323.51706036745406, wordCount=1, words=[ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='/', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='CN', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text=' ', textColor=Color(.145098,.207843,.290196,1), us_lines=[]), ParaFrag(__tag__='font', bold=1, fontName='Latin', fontSize=8.5, greek=0, italic=1, link=[], rise=0, text='0', textColor=Color(.145098,.207843,.290196,1), us_lines=[])])])
) #Paragraph,) |

本次已实际完成探索与返航：最终result为COMPLETE、双覆盖率符合标准、部署点误差小于0.35米，场景审计通过。记录的36次导航结果全部成功，无输入故障或导航重置。该运行作为新的独立测试附录，原四组验收数据和发布ZIP保持冻结。

![图示](figures/current_test_map.png)
