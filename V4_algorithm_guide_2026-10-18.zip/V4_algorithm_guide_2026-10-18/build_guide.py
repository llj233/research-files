from pathlib import Path
import json,csv,hashlib,ast,html,sys,math
from datetime import datetime
from zoneinfo import ZoneInfo
from reportlab.platypus import SimpleDocTemplate,BaseDocTemplate,PageTemplate,Frame,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing,Rect,Line,String,Polygon
ROOT=Path(__file__).resolve().parent
SRC=Path('/home/lemuel/Downloads/V4_optimized_frozen_2026-10-18')
LIVE=Path('/home/lemuel/Downloads/V4_single_native_audit_2026-10-18')
RUN=LIVE/'experiments/single/room/map_seed_484794/policy_seed_677270/20261018T095750Z_dea69d56'
pdfmetrics.registerFont(TTFont('CN','/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf'))
pdfmetrics.registerFont(TTFont('Latin','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
from fontTools.ttLib import TTFont as FontProbe
CN_CHARS=set(FontProbe('/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf').getBestCmap())
pdfmetrics.registerFont(TTFont('Mono','/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))
W,H=A4; M=46; CW=W-2*M
NAVY=colors.HexColor('#142B45'); TEAL=colors.HexColor('#087F8C'); INK=colors.HexColor('#25354A'); GRAY=colors.HexColor('#5D6D7E'); LIGHT=colors.HexColor('#EFF5F8')
styles={
 'body':ParagraphStyle('body',fontName='CN',fontSize=10.2,leading=16.2,textColor=INK,wordWrap='CJK',spaceAfter=7),
 'h1':ParagraphStyle('h1',fontName='CN',fontSize=19,leading=27,textColor=NAVY,spaceAfter=15),
 'h2':ParagraphStyle('h2',fontName='CN',fontSize=12.5,leading=19,textColor=TEAL,spaceBefore=9,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='CN',fontSize=8.2,leading=12.2,textColor=GRAY,wordWrap='CJK',spaceAfter=5),
 'cell':ParagraphStyle('cell',fontName='CN',fontSize=8.5,leading=12.5,textColor=INK,wordWrap='CJK'),
 'code':ParagraphStyle('code',fontName='Mono',fontSize=7.5,leading=11,textColor=NAVY,wordWrap='CJK',backColor=LIGHT,borderPadding=8,spaceAfter=8),
 'cover':ParagraphStyle('cover',fontName='CN',fontSize=30,leading=42,textColor=NAVY,spaceAfter=20),
}
PAGES=[]
def font_runs(text,style='body'):
 runs=[]
 for c in text:
  font='CN' if ord(c) in CN_CHARS else ('Mono' if style=='code' else 'Latin')
  if runs and runs[-1][0]==font:runs[-1]=(font,runs[-1][1]+c)
  else:runs.append((font,c))
 return runs

def font_html(text,style='body'):
 return ''.join('<font name="'+font+'">'+html.escape(txt).replace('\n','<br/>')+'</font>' for font,txt in font_runs(text,style))

def p(text,style='body'):
 import re
 pieces=re.split(r'(https?://[^\s]+|github\.com/[^\s]+)',text)
 markup=''
 for piece in pieces:
  if piece.startswith(('http://','https://','github.com/')):
   url=piece if piece.startswith('http') else 'https://'+piece
   markup+='<link href="'+html.escape(url,quote=True)+'" color="#087F8C">'+font_html(piece,style)+'</link>'
  else:markup+=font_html(piece,style)
 return Paragraph(markup,styles[style])

def canvas_text(c,x,y,text,size=8,right=False):
 runs=font_runs(text);total=sum(pdfmetrics.stringWidth(t,f,size) for f,t in runs)
 if right:x-=total
 for font,t in runs:
  c.setFont(font,size);c.drawString(x,y,t);x+=pdfmetrics.stringWidth(t,font,size)

def fix_drawing_fonts(d):
 from reportlab.graphics.shapes import Group
 for i,shape in enumerate(list(d.contents)):
  if isinstance(shape,String):
   group=Group();runs=font_runs(shape.text);size=shape.fontSize
   total=sum(pdfmetrics.stringWidth(t,f,size) for f,t in runs)
   x=shape.x-(total/2 if shape.textAnchor=='middle' else total if shape.textAnchor=='end' else 0)
   for font,t in runs:
    group.add(String(x,shape.y,t,fontName=font,fontSize=size,fillColor=shape.fillColor));x+=pdfmetrics.stringWidth(t,font,size)
   d.contents[i]=group

def page(title,items):PAGES.append((title,items))
def table(headers,rows,widths=None):
 data=[[p(str(x),'cell') for x in headers]]+[[p(str(x),'cell') for x in row] for row in rows]
 t=Table(data,colWidths=[CW*v/sum(widths) for v in widths] if widths else [CW/len(headers)]*len(headers),repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DCEAF0')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#CBD8DF')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]));return t

def diagram(boxes,edges,height=280):
 d=Drawing(CW,height)
 for key,(x,y,w,h,lines,kind) in boxes.items():
  bg=colors.HexColor('#E3F2F0') if kind=='eval' else LIGHT
  d.add(Rect(x,y,w,h,rx=5,ry=5,fillColor=bg,strokeColor=TEAL if kind=='eval' else colors.HexColor('#9AB2C3'),strokeWidth=.8))
  lines=lines.split('\n')
  for i,line in enumerate(lines):d.add(String(x+w/2,y+h/2+(len(lines)-1)*6-i*12,line,fontName='CN',fontSize=8.7,textAnchor='middle',fillColor=INK))
 for a,b,label in edges:
  ax,ay,aw,ah,*_=boxes[a];bx,by,bw,bh,*_=boxes[b]
  if abs(ay-by)<10:
   x1,y1=ax+aw,ay+ah/2;x2,y2=bx,by+bh/2
  else:x1,y1=ax+aw/2,ay;x2,y2=bx+bw/2,by+bh
  d.add(Line(x1,y1,x2,y2,strokeColor=TEAL,strokeWidth=1))
  ang=math.atan2(y2-y1,x2-x1);r=5
  d.add(Polygon([x2,y2,x2-r*math.cos(ang-.45),y2-r*math.sin(ang-.45),x2-r*math.cos(ang+.45),y2-r*math.sin(ang+.45)],fillColor=TEAL,strokeColor=TEAL))
  if label:d.add(String((x1+x2)/2+4,(y1+y2)/2+4,label,fontName='CN',fontSize=7.5,fillColor=GRAY))
 return d

def cite(path,name=None):
 path=Path(path);line=1
 if name:
  tree=ast.parse((SRC/path).read_text())
  found=[n.lineno for n in ast.walk(tree) if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name]
  if found:line=min(found)
 return p(f'代码依据：{path}:{line}'+(f'  [{name}]' if name else ''),'small')
A=Path('src/active_slam_v4/active_slam_v4');E=Path('src/v4_evaluator/v4_evaluator')

page('01 版本定位：当前 V4 到底是什么',[
 p('本手册以已经冻结、可上传 GitHub 的 V4_optimized_frozen_2026-10-18 为准。依据是运行源码、生成参数、四组预注册验收数据和一组独立随机补充数据；不是把 V4 方案书中的全部构想当作已经完成。'),
 table(['问题','当前代码的答案'],[
 ('是否单机？','是。运行器、命令行和 launch 均拒绝非 single 模式，在线仅 robot1。'),
 ('是否使用 SLAM？','是。slam_toolbox 将激光、里程计/TF组织成在线占据栅格地图。'),
 ('是否主动选择探索目标？','是。程序依据地图中的未知边界、可见性代理和导航成本自主选取下一观测位姿。'),
 ('是否强化学习？','当前这版不是 Q-learning/DQN/PPO 训练器。没有 Q 表加载/更新或策略网络训练；启发式得分不等于强化学习奖励。'),
 ('是否严格的信息论主动 SLAM？','不是联合优化地图熵、定位协方差和闭环收益的完整算法。本版属于基于 SLAM 的主动建图探索。'),
 ('是否已验收双机？','当前发布只验收单机。代码保留融合/分配组件，但双机实时执行被入口禁用。')],[1,3]),
 p('建议论文或答辩名称：基于 SLAM 地图与前沿安全观测位姿的自主探索及可靠返航系统。可称“启发式主动 SLAM 探索框架”，同时说明信息收益是代理指标、当前没有主动定位不确定性目标。'),
 cite(A/'ros_runtime.py','TestExecutor'),cite('scripts/run_test.py','main')])

page('02 全局架构：探索与评估两条链',[
 diagram({'a':(0,235,140,48,'Gazebo 仿真\n激光 / 里程计','run'),'b':(180,235,140,48,'slam_toolbox\n地图 + 动态 TF','run'),'c':(360,235,140,48,'frontier + 安全候选\n收益与路径代价','run'),'d':(360,130,140,52,'区域选择 / 目标派发\nNavigateToPose','run'),'e':(180,130,140,52,'Nav2 路径跟随\nRPP / 速度平滑','run'),'f':(0,130,140,52,'最终激光安全门\n实际 cmd_vel','run'),'g':(180,20,140,52,'独立真值评估\nSDF + /map','eval'),'h':(360,20,140,52,'任务状态机\n双门槛 / 返航核验','eval')},[('a','b','感知'),('b','c','局部地图'),('c','d','候选'),('e','d',''),('f','e',''),('b','g','/map'),('g','h','只传指标'),('d','h','状态')],300),
 p('图中上方为在线决策链，下方绿色为实验评估/阶段控制链。执行顺序实际上为：目标派发→Nav2→速度平滑→安全门→机器人运动→新扫描→SLAM更新。图中横向连线只表示模块关联，具体话题方向见下一节。'),
 p('探索器只读 SLAM 地图、位姿、传感器与 Nav2 接口。独立评估器读取预先固定的世界几何，计算覆盖率，并把“是否达到返航门槛”交给状态机。它不把未知障碍的位置交给目标评分。场景审计插件读取实际模型位姿，只用于验证评估真值一致性。'),
 cite(A/'ros_runtime.py','on_evaluation'),cite(E/'node.py','EvaluatorNode')])

page('03 ROS 节点与话题：模块怎样接起来',[
 table(['数据 / 接口','发布方 → 使用方','作用'],[
 ('/robot1/scan','Gazebo 激光 → SLAM / 安全门 / 监督器','LaserScan，180束、3Hz、最大10m'),
 ('/robot1/odom','差速驱动 → TF / 导航 / 监督器','Odometry；本仿真使用 WORLD 来源'),
 ('/robot1/map','slam_toolbox → 探索监督器 / 静态层','OccupancyGrid，地图分辨率0.1m'),
 ('/map','探索监督器 → 独立评估器','单机为地图转发，不是双机融合结果'),
 ('/robot1/compute_path_to_pose','探索器 ↔ Nav2 规划器','ComputePathToPose 动作，返回路径长度'),
 ('/robot1/navigate_to_pose','监督器 ↔ bt_navigator','NavigateToPose 动作，执行目标'),
 ('cmd_vel_nav → cmd_vel_unchecked','控制器 → velocity_smoother → 安全门','导航速度先平滑，再进行最终激光过滤'),
 ('cmd_vel_recovery → cmd_vel','behavior_server → 安全门 → 驱动','新鲜恢复指令优先；安全门统一输出'),
 ('/v4/evaluation','独立评估器 → Mission','JSON 指标和 coverage_passed'),
 ('/tf、/tf_static','SLAM / 驱动 / 静态发布器 → 多个消费者','坐标转换；动态 map→odom 与固定机体外参分工不同')],[1.35,1.35,1.5]),
 p('探索器没有直接常态输出行驶速度。它发的是目标位姿；真正的连续速度由 Nav2 产生，最终只由 SafetyNode 写到机器人 cmd_vel。/robot1/plan 是规划器路径，而 Humble RPP 的 received_global_plan 在本实现中是已经变换后的路径；不能只凭话题名字判断坐标系。'),
 cite(A/'ros_runtime.py','__init__'),cite(A/'safety_node.py','SafetyNode')])

page('04 坐标与部署点：为什么返航不能只记一个 map 点',[
 p('坐标链：公共 map → robot1/map → robot1/odom → robot1/base_footprint → base_link / base_scan。公共 map 到 robot1/map 在这个已知坐标对齐的单机仿真中用单位静态关系；robot1/map 到 robot1/odom 由 SLAM 动态发布。'),
 table(['坐标系','含义','本版用途'],[
 ('map / robot1/map','SLAM 的全局参考，可随估计修正','frontier、Nav2 目标、覆盖率地图'),
 ('robot1/odom','局部连续里程计参考','记录首次实际部署位姿，核验返航误差'),
 ('base_footprint / base_scan','机器人地面投影 / 激光安装坐标','感知投影、足迹与控制'),
 ('SDF 世界坐标','仿真几何真值','只供离线场景生成和独立评估/审计')],[1.2,1.4,1.6]),
 p('二维刚体变换：x_map = tx + cos(θ)x_odom − sin(θ)y_odom；y_map = ty + sin(θ)x_odom + cos(θ)y_odom。将地图原点平移当成永不变化的常数，会在 SLAM 修正后把目标指向错误的物理位置。'),
 p('本版第一次收到有效 odom 时保存部署位姿 p_home_odom。每次返航请求前读取当前 map_from_odom，再转换成 Nav2 目标。目标坐标在每次返航请求时更新，并不是每个控制周期实时重写；因此动作完成后仍做部署误差核验。'),
 p('真实机器人若 odom 漂移或多机地图未配准，不能直接照搬仿真中的单位公共坐标关系。这里的 WORLD 里程计没有编码器漂移，返航误差是这一仿真条件下的位置距离。'),
 cite(A/'model.py','Transform2'),cite(A/'ros_runtime.py','on_odometry'),cite(A/'ros_runtime.py','schedule_return')])

page('05 SLAM 层：感知怎样变成可用地图',[
 p('slam_toolbox 是地图估计后端。激光通过 TF 转到机器人坐标，里程计提供运动关系；后端进行扫描匹配及地图维护，输出占据栅格与 map→odom 关系。探索器使用这些结果，并没有重写 SLAM 后端。[O2]'),
 table(['参数','冻结值','解释'],[
 ('激光','180束 / 3Hz / 10m','实际传感器；不能与评分用48射线混淆'),
 ('SLAM resolution','0.10m','地图每个栅格边长；不是局部代价地图的0.05m'),
 ('map_update_interval','2.0s','地图输出更新间隔；评估与地图变化绑定'),
 ('minimum_travel_distance / heading','0.25m / 0.25rad','SLAM 接收运动更新的门槛'),
 ('transform_publish_period / timeout','0.05s / 0.6s','动态变换发布和等待/时间裕量配置'),
 ('do_loop_closing','False','当前冻结配置关闭闭环检测；不能把主动回环收益写成已部署目标')],[1.6,.9,1.9]),
 p('栅格语义在规划器中明确划分：0～25 为空闲；65～100 为障碍；−1 为未知。26～64 的中间值不会直接当作安全空闲候选。未知不等于空闲，目标必须先落在已知可达区域。'),
 p('当前优化对象主要是地图探索和导航可靠性。它不显式维护“下一目标能减少多少定位协方差”，也没有把姿态图闭环约束数写入目标函数。即使 SLAM 库本身具备更多功能，也应按实际启用参数介绍本版。'),
 cite('scripts/run_test.py','make_configs'),cite(A/'planner.py','reachable_free')])

page('06 Frontier：从地图中找到下一片未知边界',[
 p('Frontier 是“已知空闲格与未知格相邻”的边界，不是障碍轮廓，也不是直接把机器人开进未知格。先从机器人当前所在空闲格做四邻域 BFS，得到连通的已知空闲集合，再在这一集合上找前沿。'),
 p('四邻域只包含上、下、左、右。一个可达空闲格只要有未知邻居，就加入 frontier 集合；再按四邻域连通性聚成簇。簇按大小降序与固定坐标顺序排序，为后续采样和复现提供稳定的输入顺序。'),
 table(['步骤','输入 → 输出','为什么需要'],[
 ('reachable_free','SLAM栅格 + 当前位姿 → 连通空闲格','排除与当前机器人不连通的已知区域'),
 ('frontier_clusters','连通空闲格 + 未知邻接关系 → 前沿簇','减少逐格无组织枚举'),
 ('簇内采样','每簇靠近质心的最多4格','控制候选生成量，同时保留少量不同观测入口'),
 ('观测点回退','前沿附近的已知安全格 → 位姿','frontier 格自身可能贴墙、处于膨胀区或不可导航')],[1,1.7,1.9]),
 p('在线配置最多检查前160个簇，每簇最多采4个前沿格，再在邻域中挑选观测格。这不是“仅选择最近前沿”；最终目标还要经过安全距离、代理收益与实际 Nav2 路径代价过滤。'),
 p('BFS 的连通性只是局部地图上的几何初筛，不包含完整机器人转弯与动力学可行性。最终仍必须向 Nav2 请求路径，不能把二维相邻格连通当作可执行的导航证明。'),
 cite(A/'planner.py','neighbors'),cite(A/'planner.py','frontier_clusters')])

page('07 安全观测位姿：目标为什么不直接落在黑边旁',[
 p('每个被采样的前沿格，在其周围寻找已知连通空闲格。0.1m 分辨率下，搜索偏移约为0.05～0.90m，优先选距前沿约0.45m的位置；并以障碍间隙作为次级排序因素。观测朝向指向被选前沿。'),
 table(['过滤项','实际门槛','作用与限制'],[
 ('障碍间隙','safe_radius_m = 0.50m','四邻域距离传播得到的栅格间隙；是近似量，不是精确圆形足迹证明'),
 ('未知边界间隙','至少 min(0.2,分辨率)，当前为0.10m','避免目标直接落在未知边缘'),
 ('距机器人位置','至少0.60m','减少立即成功却没有新视角的目标'),
 ('失败目标近邻','0.55m 半径内排除','失败位置记忆跨地图版本生效'),
 ('代理收益','至少2个可见未知边界格','剔除完全没有局部未知证据的目标'),
 ('Nav2 路径','有效、非空、有限且长度非负','将代价地图和导航可达性纳入最终过滤')],[1.1,1.25,2]),
 p('注意距离传播采用四邻域 BFS，斜向的距离数值可能大于欧氏距离。因此“0.50m 安全间隙”应按代码中的离散近似理解；真正执行还依赖 Nav2 足迹、障碍膨胀、RPP 碰撞预测和最终激光门。不能据此宣称零碰撞。'),
 p('当路径查询期间地图更新，派发前会在最新 SLAM 地图上重新确认目标仍为空闲，并绑定最新 map_version。这里重新核验的是目标格，并没有对整条旧路径做独立的全足迹重验证；Nav2 在执行时继续重规划。'),
 cite(A/'planner.py','plan'),cite(A/'ros_runtime.py','schedule_explore')])

page('08 信息收益：当前真正计算了什么',[
 p('当前 predicted_new_cells 由 visible_unknown 计算：以候选位姿为中心，在360°范围发48条评分射线，最大距离3.2m，每步约一个地图栅格。遇已知障碍停止；遇第一格未知时记入集合并立即停止该条射线。'),
 p('因此它估计的是“从这个观测点可接触到多少个不同的未知边界格”，每条射线至多贡献一个首个未知格；去重后的数量不超过48。它不是沿每条光线累计3.2m内所有未知面积，也不是实际10m激光扫描的完整可见区域。'),
 table(['指标','是否在本版计算','解释'],[
 ('射线首个未知格计数','是','局部信息收益代理，几何遮挡先由已知障碍截断'),
 ('真实新覆盖面积','只在独立评估/日志层观察','到达前无法直接由代理数量精确预知'),
 ('地图熵的期望下降','否','没有观测概率模型、熵积分或期望后验计算'),
 ('定位协方差下降 / 回环收益','否','没有把定位不确定性作为候选效用项')],[1.4,1,2]),
 p('严格的信息论收益常写作 IG(g)=H(Mt)−E[H(Mt+1)|g]。这需要地图/观测概率模型。本版没有计算这个期望，所以手册使用“信息收益代理”一词。不能把简单未知格数量命名为已经求出的地图熵下降。'),
 p('代理高不保证实际覆盖增量大：未知格可能是墙体边缘、不可达阴影，或在途中已被观测。已知障碍后的未知被遮挡剔除，但未知内部是否存在遮挡无法提前确认。由此可能出现多次目标成功、覆盖率增长很少的情况。'),
 cite(A/'planner.py','visible_unknown')])

page('09 目标评分与候选预算：收益怎样和路程结合',[
 p('候选先按 gain/(欧氏距离+1) 做便宜排序，再按2m×2m空间桶分散请求预算：各桶先取第1个，再取第2个。最终最多40个候选请求 Nav2 ComputePathToPose；欧氏距离只参与预筛，不代替可导航路径长度。'),
 p('实际路径长度 L(g) 为返回路径相邻位姿欧氏段长的总和。不可达、动作失败、超时或空路径都按无效处理，不使用直线距离填补失败的路径代价。'),
 p('实际效用：U(g) = gain(g) / ( L(g)/0.22 + 2 ) − 0.1 / max(c(g),0.1)。其中0.22m/s是评分用名义速度，不是控制器硬限速；c为障碍和未知边界距离的较小值。然后加上策略种子生成的至多±1%相对微扰。','code'),
 p('例：若 gain=20、L=4.4m、c=0.2m，则旅行代理为22s，原始得分约20/22−0.5=0.409。若另一候选 gain相同但L=8.8m，旅行代理42s，得分约−0.024；在其他条件一致时前者优先。这是启发式相对排序，不是有物理意义的期望累计奖励。'),
 p('本版没有将所有项统一归一化到[0,1]，没有在线学习权重，也没有单独的“转向角代价”或定位收益项。数值来自冻结实现，而不是把早期方案中的一般评分公式写成当前代码。'),
 cite(A/'planner.py','plan'),cite(A/'planner.py','seeded_score'),cite(A/'ros_runtime.py','query_path')])

page('10 区域策略与双机组件：已用和未用的边界',[
 p('本版的区域编号为 floor(x/2):floor(y/2)。这是一张固定2m空间分桶，并非语义房间识别、稀疏门口图、拓扑最短巡回或学习到的全局策略。分桶用于路径查询多样性和目标临时归属。'),
 table(['组件','代码中存在','当前单机执行情况'],[
 ('Allocator 贪心分配','按得分排序，机器人和区域各至多占一个目标','单机退化为为 robot1 选择一个有效候选'),
 ('Lease 临时归属','持有机器人、区域、地图版本和到期时刻','运行配置50s；地图版本变化也会令旧lease失效'),
 ('AlignmentFusion 双图融合','重采样、障碍优先、重叠/冲突门槛','单机分支绕过双图融合，直接转发本地地图到/map'),
 ('双机在线导航','源码保留多机数据结构','入口明确只允许single；并未完成本发布的双机验收'),
 ('HPHS / RangeTAP 完整算法','没有完整实现','仅能把局部采样、区域分桶和路径成本视为相关工程思路，不能称完整论文复现')],[1.3,1.7,1.8]),
 p('双图融合类本身要求两张地图和变换同时存在，按占据冲突比例、地图新鲜度和重叠数做检查；但这不等于实现了未知初始位姿下的地图配准。仿真公共坐标来自已知关系，真实多机需要另外验证配准与动态TF。'),
 p('当前没有匈牙利匹配、完整视野集合的双机器人去重、同时会车防死锁或已验收的同房间双机协同。介绍“整体V4架构”时必须把这些保留组件与单机已运行主链分开。'),
 cite(A/'allocator.py','Allocator'),cite(A/'fusion.py','AlignmentFusion'),cite(A/'ros_runtime.py','update_fusion')])

page('11 Nav2 执行层：规划路径与连续速度分工',[
 p('选中观测位姿后，监督器发送 NavigateToPose 动作。bt_navigator 运行冻结行为树；规划器计算一条路径，控制器跟踪路径，恢复行为处理局部失败。探索模块负责“去哪里”，Nav2负责“怎样沿已知可通行区域过去”。'),
 table(['模块','本版实际配置','功能'],[
 ('全局规划 GridBased','NavfnPlanner，use_astar=False','当前是NavFn的Dijkstra方式；不要描述为已启用A*'),
 ('未知通行','allow_unknown=False','规划路径不主动穿越未知区域'),
 ('全局代价地图','静态地图层 + 膨胀层，更新1Hz','SLAM地图作为基础，膨胀半径0.70m'),
 ('局部代价地图','障碍层 + 膨胀层，4m×4m，更新2Hz','用激光更新近距离障碍，膨胀半径0.65m'),
 ('代价地图几何','配置resolution=0.05m，robot_radius=0.22m','全局StaticLayer可能随输入地图尺寸/分辨率匹配，实际以发布头为准'),
 ('连续控制器','RPP，控制频率8Hz','跟踪前视点，结合曲率调速和碰撞预测'),
 ('速度平滑','20Hz，线速度上限0.26m/s','RPP期望0.28m/s不等于最后实际输出速度')],[1.25,1.8,1.9]),
 p('规划服务返回有效路径，不能保证整个未来执行过程永远成功。机器人运动、传感器噪声、地图更新或局部障碍仍可能导致控制器中止，因此需要后续看门狗、取消确认与重新选择目标。'),
 p('源码里的 query_path 发送请求等待上限6秒，等待结果上限8秒，使用线程事件的墙上时间。这些RPC等待与启动墙时保护说明整个软件并非完全只由仿真时间驱动；任务截止、前沿冷却和多数导航诊断使用仿真秒。'),
 cite('scripts/run_test.py','make_configs'),cite(A/'ros_runtime.py','query_path')])

page('12 RPP 路径跟随：为什么会旋转，如何避免配置陷阱',[
 p('RPP从已规划路径上取前视点，依据机器人与前视点的相对位置生成角速度/线速度，并按曲率与接近目标情况调节线速度。开启的碰撞预测会检查短时间运动是否与代价地图冲突。[O1]'),
 table(['参数','冻结值','含义'],[
 ('desired_linear_vel','0.28m/s','控制器期望；后续平滑上限0.26m/s'),
 ('min / max lookahead','0.45 / 0.70m','实际启用速度相关前视，静态lookahead_dist=0.40不是此时最小值'),
 ('rotate_to_heading_angular_vel','0.60rad/s','约34.4度/秒，短暂对准路径可正常发生'),
 ('use_collision_detection','True','预测碰撞，窗口上限1.2s，受前视点限制'),
 ('曲率调速 / 代价调速','True / False','不要把两种不同的速度调节开关混为一项'),
 ('最小受控速度 / 接近速度','0.08 / 0.05m/s','弯曲路径与接近终点时可显著慢于期望速度')],[1.5,1,2]),
 p('调试中出现过最小前视0.25m而探索XY容差0.35m的错误配置。Humble RPP 的目标朝向判断使用前视点距离，可能过早进入目标朝向旋转。本版以0.45m大于所有XY容差为约束，并在参数生成时自动拒绝冲突。'),
 p('正常转向与故障转圈要分开：对准路径、转弯与到达后的目标朝向校正有明确的后续平移/完成结果；长期无平移、路径/足迹时间戳冻结或超时才需要诊断。换RPP不代表消灭所有旋转，也不保证所有窄门都有可行轨迹。'),
 cite('scripts/run_test.py','validate_rpp_config'),cite(A/'navigation_health.py','navigation_fault')])

page('13 行为树与目标稳定性：谁来负责恢复',[
 p('冻结行为树的主链为 PipelineSequence：以1Hz重算当前目标的路径，再由 FollowPath 执行。全局规划失败时清全局代价地图并有限重试；控制失败时清局部代价地图并有限重试。'),
 p('外层 RecoveryNode 最多2次重试，恢复候选按 RoundRobin 使用等待1秒和后退0.25m（0.05m/s）。没有 Spin 恢复节点。这里的“无Spin恢复”不等于控制器不会为对准路径而旋转。'),
 table(['层级','本版实际行为','不能误写成'],[
 ('Nav2路径重规划','当前目标不变，约1Hz重算路径','每秒重新选择一个frontier目标'),
 ('探索目标重选','完成、失败、取消或阶段变化后再选择','不断在所有候选间每秒来回跳转'),
 ('外层调度冷却','最少7仿真秒启动一次候选规划，忙时不发新目标','固定每7秒强制取消当前目标'),
 ('Mission的20%切换接口','类中支持switch_margin=0.2和current_score','已部署每轮比较新旧目标并启用20%滞后')],[1.15,1.85,1.9]),
 p('关键源码事实：schedule_explore 跳过有活动目标的机器人，也没有向 Mission.dispatch 传 current_score。因此当前在线路径以“完成/失败后重选”为主，不能把类里存在的20%门槛当作已经启用的持续在线切换策略。'),
 p('失败后先取消旧动作、等终止结果/短暂保持，再派新目标；避免旧goal迟到接受或尚未取消时与新goal竞争。Nav2拥有主要运动恢复，监督器拥有诊断和目标生命周期，减少多个恢复模块互相抢控制。'),
 cite('assets/navigate_bounded.xml'),cite(A/'mission.py','dispatch'),cite(A/'ros_runtime.py','navigation_busy')])

page('14 最终速度安全门：防碰撞的最后一层',[
 p('SafetyNode以20Hz运行，订阅平滑后的导航速度、恢复速度和激光，最终发布cmd_vel。恢复指令在足够新鲜且非零时优先；否则使用新鲜导航指令；两者都旧则输出零。'),
 p('前向与后向各取±35°激光扇区最小距离。正向速度检查前方，倒车检查后方。停止距离的启发式为：d_stop = 0.19 + 0.10 + v²/(2×0.45)。在0.26m/s时约0.365m；小于等于停止距离就切掉平移，再往外0.35m的缓行区把线速度降到最多0.08m/s。','code'),
 table(['条件','输出/动作','说明'],[
 ('激光接收超过0.7s','零速度','这里按回调接收时间判新鲜度，并非所有地方都用消息原始头时间'),
 ('恢复指令年龄≤0.25s且非零','优先恢复速度','依旧经过激光过滤'),
 ('导航指令年龄≤0.5s','采用导航速度','未满足新鲜条件则idle'),
 ('导航hold为真','立即输出零并清理临时恢复','配合故障处理和生命周期重置'),
 ('纯旋转命令','允许角速度通过','不能将这个门描述为对非圆形足迹旋转提供完整碰撞证明')],[1.3,1.2,2]),
 p('安全门的圆形半径近似、前后扇区以及扫描采样都存在限制；Nav2 使用的0.22m足迹与这里启发式0.19m+0.10m不同。它是叠加保护而不是替代Nav2足迹检查。全部激光值无有效有限读数时，sector_min 返回无穷大，也不是独立的传感器健康证明。'),
 p('源码保留 escape/backtrack 接口，但当前主要失败分支没有主动发布 escape_request；不能把这段备用能力描述为每次卡住都会自动触发的主恢复流程。'),
 cite(A/'safety.py','safe_velocity'),cite(A/'safety_node.py','tick')])

page('15 防卡住监督：控制、任务、输入三层看门狗',[
 table(['保护层','冻结门槛','处理'],[
 ('Nav2 progress checker','12s内需约0.12m位置变化','控制器判无进展，进入有限行为树恢复'),
 ('外层平移监督','同一目标35s未产生0.12m净位移','判blocked，取消目标并重选；转向不会重置平移计时'),
 ('单目标预算','max(70,min(150,L/0.18+15))秒','到期按timeout处理，不能无限占用任务'),
 ('导航输入监督','goal年龄≥8s；局部图或足迹头时间落后>4s','记录fault、hold停止、取消并至多一次Nav2重置'),
 ('变换后路径监督','原计划新鲜<2.5s，但变换路径缺失或落后>5s','判控制器消费路径不新鲜'),
 ('取消卡住','等待终止超过8s','触发受限重置路径，避免反复重叠目标'),
 ('总体健康 / 总预算','就绪输入通常≤6s；不健康宽限10s；任务700s','无法恢复则明确FAILED，不持续假装探索')],[1.15,2,1.75]),
 p('外层35秒监督基于 map 位姿的净平移。它不是完整的轨迹环路检测器；小范围平移往返可能重置这个计时。distance_remaining 的0.25m改善值虽在反馈中记录，目前没有在tick中成为独立超时触发条件。'),
 p('失败位置在0.55m半径内抑制180仿真秒；若目标“成功”但起终位移小于0.35m，则抑制60秒，减少没有新观测视角的即时成功。失败ID和物理位置记忆分别处理，不只依赖会变化的地图版本号。'),
 p('运行构造器把max_retries设为20，覆盖Mission类默认值2；成功会清零，超过20次连续非成功才触发对应任务失败。Nav2重置次数仍最多1次，行为树外层重试仍为2次，这三个数字属于不同层级。'),
 cite(A/'ros_runtime.py','tick'),cite(A/'navigation_health.py','travel_goal_budget')])

page('16 永久停更根因：为什么换前沿也救不活死锁',[
 p('故障诊断曾出现：时钟和部分外部TF仍更新，但控制器内部足迹与路径时间戳冻结。独立GDB两次线程栈记录显示，一个线程持有定时器/请求映射锁并等待变换请求锁；另一个线程持有变换请求锁并在回调中等待前一把锁。'),
 table(['线程','持有','等待'],[
 ('激光/MessageFilter回调 → waitForTransform','timer_to_request_map_mutex_','transformable_requests_mutex_'),
 ('TF接收 → testTransformableRequests → 回调','transformable_requests_mutex_','timer_to_request_map_mutex_')],[1.65,1.5,1.5]),
 p('这是ABBA锁顺序死锁：两线程彼此等待，单纯增加旋转、修改frontier得分或缩短DDS发布间隔不能释放锁。重置也可能在清理时等住，因此必须先修复底层锁循环，再讨论局部导航性能。'),
 p('冻结版使用官方Humble修复tf2/tf2_ros 0.25.24，在提取满足条件的请求后释放锁，再执行相关回调。[O3] 官方DEB只解包到vendor，子进程设置本地库路径，不替换系统旧实验安装。'),
 p('验证不只看“这次没卡”：同一C++回调重入测试在旧0.25.23加载下确定性超时，在隔离0.25.24下立即通过；最终运行还保存过实际/proc进程库映射，确认SLAM和控制器加载本地修复库。'),
 p('该结论针对抓到的TF内部永久停更。地图目标不可达、局部足迹受阻或任务预算耗尽是其他故障类别，需要分别记录，不能全部归为TF或frontier问题。'),
 cite('src/tf_deadlock_regression/src/callback_reentry.cpp'),p('原始证据：ROOT_CAUSE.md、TF_DEADLOCK_REGRESSION.json、evidence/diagnostic_controller_threads.log、各次loaded_tf2_libraries.json。','small')])

page('17 任务状态机：从启动到结束的明确条件',[
 diagram({'a':(0,190,140,50,'STARTUP\n等待感知 / TF / Nav2','run'),'b':(180,190,140,50,'EXPLORE\n选择并执行观测目标','run'),'c':(360,190,140,50,'RETURN\n实际部署点返航','run'),'d':(360,65,140,50,'COMPLETE\n返航位置核验通过','eval'),'e':(90,65,170,50,'FAILED\n明确保存原因和当前地图','run')},[('a','b','就绪'),('b','c','双指标通过'),('c','d','返航成功'),('a','e','启动失败'),('b','e','超时 / 故障')],260),
 p('STARTUP：任务第一次tick记录sim_start_s，数据与Nav2动作服务就绪后进入EXPLORE。仿真启动预算90秒，额外还有120秒墙上启动保护。总体任务仿真计时包含启动，并不在导航重置后重新计时。'),
 p('EXPLORE：单机同一时刻只有一个活动目标；如果独立评估器报告coverage_passed，就清除探索活动目标并请求取消Nav2动作，切入RETURN。路径重规划仍由Nav2行为树负责。'),
 p('RETURN：查询当前位姿到动态换算部署点的可行路径，执行返航。已在0.35m范围内的机器人可直接记already_home；否则动作成功还需误差核验。完成后进入COMPLETE。'),
 p('FAILED：覆盖率超时、返航超时、定位不健康、无法恢复的导航故障等都保存分类。最终地图和日志仍导出。没有候选时会触发诊断并继续尝试，源码中的NO_FRONTIER枚举并不代表在线立即以这个原因退出。'),
 cite(A/'mission.py','Mission'),cite(A/'ros_runtime.py','finish')])

page('18 真值覆盖率与返航：两个百分比怎样算',[
 p('独立评估器从SDF读取与机器人高度相交的盒形碰撞几何，按机器人半径0.22m膨胀，在0.1m评估栅格上从部署点四邻域洪泛，固定真值可达空闲集合F。它没有通用的任意网格/mesh世界解析能力；当前随机生成器只支持room.world。'),
 p('探索率 C_free = 100 × |{c∈F : 0≤M(c)≤25}| / |F|。探索面积 A_free = 已识别可达空闲格数 × (0.1m)²。注意：这是SLAM分类与真值可达空闲格的重合比例，不是机器人车轮实际压过的面积。','code'),
 p('ROI集合 R = F ∪ B，其中B为与F四邻接的膨胀障碍边界格。ROI已知率 C_ROI = 100 × |{c∈R : M(c)≥0}| / |R|；空闲或障碍都算已知，未知不算。不同布局的固定真值分母可能略有不同。','code'),
 table(['指标','返航门槛','计数差别'],[
 ('可达空闲探索率','严格 >95%','真值空闲还需被SLAM判为空闲'),
 ('固定ROI已知率','严格 >90%','ROI内任何非未知分类都计已知'),
 ('返航位置','实际部署点误差 ≤0.35m','不依赖屏幕看起来很近或动作回报单独判断')],[1.25,1.1,2.2]),
 p('评估器随/map回调更新，并限制至少间隔约5秒；并不是严格每5秒一定有采样，地图不更新就没有新回调评估。因此表中的达标时间具有采样间隔粒度。返航途中仍可更新地图，最终覆盖率可能与触发返航时不同，曲线也不保证严格单调。'),
 p('“ROI已知率90%”不是原始地图外接矩形面积的90%，也不是所有墙体内部都必须扫描到。论文中必须明确分母，否则无法和其他算法的coverage对齐。'),
 cite(E/'truth.py','GroundTruth'),cite(E/'metrics.py','observable_roi'),cite(E/'metrics.py','evaluate')])

page('19 可靠返航：目标位置和完成结果双重核验',[
 p('部署点不是硬编码的地图点。首次有效里程计写入deployment_odom.json；每次返航前把这个点经当时的map_from_odom变换到SLAM地图，再请求ComputePathToPose验证可达性。'),
 p('g_home_map = T_map_from_odom(now_request) · p_home_odom\ne_home = sqrt((x_odom−x_home)² + (y_odom−y_home)²)','code'),
 table(['环节','实际处理','原因'],[
 ('返航路径查询','从当前位姿重查路径长度','路径未找到时计重试，不用直线导航替代'),
 ('返航行为树','沿用有限恢复树，换deployment_goal_checker','探索与返航允许不同目标容差'),
 ('Nav2目标检查','XY 0.20m，yaw 0.80rad','比探索0.35m位置容差更紧'),
 ('实际位置检查','动作成功后e_home需≤0.35m','动态SLAM修正可能令map目标成功但物理点偏离'),
 ('核验未通过','记录home_verification_failed并记home_not_reached','重新查询/转换目标，不伪造returned=true'),
 ('已在家','无活动返航目标且e_home≤0.35m','可直接完成，记录already_home')],[1.1,1.8,1.8]),
 p('目标朝向由初始部署yaw转换得到，但本次任务的额外实际核验主要是XY距离。这里不是严格要求精确重合到同一个数学点，而是明确的0.35m部署点容差。报告必须同时给出容差和实际误差。'),
 p('全局700秒预算在返航期间继续运行。单目标时限按路径计算不代表返航阶段自动获得额外700秒。若探索消耗过多，即使覆盖率达标也可能在回程超时，这类样本应保留为return_failed。'),
 cite(A/'ros_runtime.py','schedule_return'),cite(A/'ros_runtime.py','on_goal_done'),cite(A/'navigation_health.py','deployment_error')])

page('20 场景一致性：覆盖率评估为什么需要审计',[
 p('早期世界生成器挪动model/pose，却留下源文件保存的state。Gazebo加载state后把两个已有箱子覆盖回旧位置，而评估器读取model定义，导致实际场景与评估真值不同。这是数据有效性问题，不能靠漂亮的覆盖率曲线消除。'),
 p('本版生成器删除所有保存state，将两个原箱子设为静态，加上六个新增静态箱子；新增箱子边长0.45～0.70m、高0.60m，位置和角度由地图种子产生。构图检查按0.2m栅格验证可达自由区面积至少为原参考的95%，最多尝试50次。这个95%是生成器几何检查，不是任务探索率阈值。'),
 table(['检查','本版方式','数据隔离'],[
 ('实际障碍位姿','Gazebo服务器第一次世界更新读取8个Model::WorldPose','只读，不设位姿、不施力、不发导航目标'),
 ('模型静态属性','8个均须static=true','确保运行时不被机器人推移而改变真值'),
 ('坐标误差','XY≤0.005m，yaw≤0.01rad','与独立SDF定义比较'),
 ('场景存档','scene_actual_poses.json + scene_audit.json','原始实际采样和独立判定分别保存'),
 ('历史数据','旧场景不一致/CLI审计超时单独标记','不能混入最终真值通过率')],[1.1,2,1.8]),
 p('一次性原生审计替代了父版不稳定的gz model命令行请求链。插件验证场景，不给探索器提供未知地图。场景生成器和离线评估器使用真值做实验定义，与在线规划直接读取真值是不同的数据流。'),
 cite('scripts/map_variants.py','generate_room'),cite('src/gazebo_scene_audit/src/scene_pose_audit.cpp'),cite('scripts/audit_scene.py','compare_scene')])

page('21 一轮闭环的伪代码与时序',[
 p('下面为按源码整理的逻辑摘要，不是可直接替换运行代码的简化控制器。关键是保留“异步规划、动作生命周期、任务阶段和独立评估”四种状态。'),
 p('每1仿真秒 tick():\n  刷新位姿TF与 map_from_odom\n  如SLAM地图时间戳变化: 更新/map与版本号\n  检查就绪、足迹/路径原始头时间、取消状态\n  处理最多一次Nav2重置与健康超时\n  Mission.tick(): 启动 / 健康 / 全局预算\n  对过期或35秒无平移的活动目标: 取消并分类\n  EXPLORE且空闲: 异步生成候选 → Nav2路径查询\n  候选完成后: 最新图空闲重检 → 贪心选目标\n  RETURN且空闲: 转换实际部署点 → 查询路径 → 派发\n  每30秒及结束时: 导出当前地图与日志','code'),
 p('独立 on_map():\n  若距上次评估足够久: 统计C_free和C_ROI\n  发布 /v4/evaluation\n监督器 on_evaluation():\n  EXPLORE且严格双门槛通过 → RETURN并取消探索目标\n动作 on_goal_done():\n  普通成功/失败 → 更新目标状态、重试与失败记忆\n  返航成功 → 额外核验部署点误差\n  全部返回 → COMPLETE','code'),
 p('规划工作线程max_workers=1，使大量候选路径请求不直接阻塞ROS回调；生命周期重置有单独线程。虽然目标和多数超时使用仿真时间，RPC等待仍有墙时截止，所以机器过载可能改变服务返回/候选集合。'),
 cite(A/'ros_runtime.py','tick'),cite(A/'ros_runtime.py','plan_candidates'),cite(A/'ros_runtime.py','on_goal_accepted')])

page('22 参数总表与源码阅读路线',[
 table(['层','关键配置','源码入口'],[
 ('传感器 / SLAM','180束、3Hz、10m；栅格0.1m、地图2s、关闭loop closing','scripts/run_test.py::make_model / make_configs'),
 ('候选','最多160簇，每簇≤4样本；最多40条Nav2查询','planner.py::plan'),
 ('收益 / 评分','48评分射线、3.2m、首未知停止；v_score=0.22m/s','planner.py::visible_unknown / plan'),
 ('区域 / lease','2m分桶；lease50s；地图版本变化可释放','planner.py::region_id / allocator.py'),
 ('执行 / 平滑','NavFn Dijkstra；RPP8Hz；平滑20Hz、0.26m/s上限','run_test.py::make_configs + 系统模板'),
 ('安全 / 监督','激光门20Hz；scan接收0.7s；平移35s','safety_node.py / ros_runtime.py::tick'),
 ('预算 / 返回','任务700s；目标70～150s；返航XY0.20m / 核验0.35m','mission.py / navigation_health.py')],[1.0,2.1,2]),
 p('建议按以下顺序看代码：model.py理解数据结构 → mission.py理解阶段 → planner.py理解目标 → ros_runtime.py理解ROS拼装与异步回调 → run_test.py与launch理解真正启用的参数 → safety.py理解最终速度门 → evaluator理解真值口径 → audit插件与报告脚本理解证据链。'),
 p('不要只看类构造默认值或文件顶部注释：运行构造器可能覆盖默认值，某些注释保留双机描述，而入口已经限制单机。PDF中的数字以运行器覆盖值和本次生成YAML为准。'),
 cite('src/active_slam_v4/launch/v4_test.launch.py','generate_launch_description')])

# Reference data are copied for this companion guide; the frozen release is untouched.
import shutil
shutil.copy2(SRC/'validation_coverage_curves.png',ROOT/'figures/reference_coverage.png')
rows=list(csv.DictReader((SRC/'VALIDATION_RESULTS.csv').open(encoding='utf-8-sig')))
supp=list(csv.DictReader((SRC/'SUPPLEMENTARY_RESULTS.csv').open(encoding='utf-8-sig')))
page('23 已有实验结果：四组验收与一次补充测试',[
 p('以下数据来自冻结版原始CSV。原四组是预先固定的功能验收，额外一组是在冻结后随机选择种子的补充测试；两类数据分开统计。本次新开的484794/677270在后附章节单列。'),
 table(['地图/策略','探索率 / ROI','达标 / 总任务(s)','返航误差(m)'],[
 (f"{r['map_seed']}/{r['policy_seed']}",f"{float(r['exploration_pct']):.2f}% / {float(r['roi_known_pct']):.2f}%",f"{r['exploration_end_sim_s']} / {r['total_task_sim_s']}",f"{float(r['home_error_odom_m']):.3f}") for r in rows+supp],[1.2,1.6,1.4,1]),
 p('原四组的132次已记录导航结果全部成功，目标超时、输入故障、重置、Spin恢复请求均为0；最长同目标无0.12m净位移区间约4秒。该量由约1Hz记录估计，不是碰撞计数，也不包含所有可能的局部回旋行为。'),
 Image(str(ROOT/'figures/reference_coverage.png'),width=CW,height=CW*736/1920),
 p('曲线横轴为任务仿真时间，不是墙上时间。绿色101/501存在较长覆盖平台，但仍在预算内完成；这说明“可靠完成”与“始终保持最高探索速度”是两个不同的目标。原四组不构成多地图族、多重复种子的统计优势证明。','small'),
 p('来源：VALIDATION_RESULTS.csv、SUPPLEMENTARY_RESULTS.csv、各run/evaluation.csv、mission_events.jsonl。','small')])

example=SRC/rows[-1]['map_preview']
shutil.copy2(example,ROOT/'figures/reference_map202.png')
page('24 建图输出：地图图像应该怎样解读',[
 Image(str(ROOT/'figures/reference_map202.png'),width=365,height=365*1600/1608,hAlign='CENTER'),
 p('示例为已验收地图种子202的最终SLAM地图，显示方式与冻结版一致：浅蓝为空闲、深色为障碍、黄色为未知；8倍放大只影响显示，不增加地图空间精度。黄色也可能出现在障碍内部或被遮挡区域。'),
 p('PGM/YAML用于标准栅格地图存储，PNG是便于查看的统一配色预览。一个0.1m栅格即使放大8×8像素，真实边长仍然是0.1m。几何画布大小、已知区域大小和真值可达面积也不是同一个概念。'),
 p('95%探索率允许仍有约5%的真值可达空闲区未被SLAM判定为空闲，因此最终PNG不必完全去除黄色。反过来，一张看起来大部分浅蓝的图，也不能替代固定分母、真值坐标对齐和场景审计。'),
 cite(A/'ros_runtime.py','export_map'),cite(A/'preview.py','write_map_preview')])

page('25 工程贡献、算法边界与可改进项',[
 table(['类别','可据代码与证据说明的内容','当前不能直接推断'],[
 ('探索架构','SLAM前沿、安全观测位姿、实际Nav2路径成本、状态机串成闭环','前沿探索或RPP算法本身为本项目原创'),
 ('导航可靠性','TF死锁证据、本地修复、有限恢复、取消屏障和输入监督','任意障碍密度下永不碰撞或卡住'),
 ('任务闭环','双覆盖门槛、动态部署点转换、返航位置核验','真实机器人具有相同返航精度'),
 ('实验可审计性','实际障碍坐标核对、种子与哈希、失败原始记录、阶段时间分离','少量单模板测试代表普遍泛化优势'),
 ('研究创新','可作为系统集成与可靠性改进的工程贡献','未经文献对照就宣称新的强化学习/信息论主动SLAM算法')],[1.1,2.1,2.1]),
 p('明确的后续能力缺口：语义房间/稀疏拓扑层、路径访问历史和真实覆盖增量反馈、位姿不确定性/主动回环目标、动态障碍、未知初始对齐多机融合，以及同时双机导航的会车与死锁处理。它们是后续方向，没有在本次文档中伪装为已部署功能。'),
 p('现有机制也有可测量的局限：收益只统计首个未知边界，可能偏好低真实增量的目标；区域分桶不是全局最优路线；成功目标若移动足够远但新增覆盖极低，当前没有独立的“真实收益学习”更新。应先收集配对日志与消融结果，再决定是否新增模型。'),
 p('如果后续引入强化学习，需要明确状态、动作、奖励、Q/网络更新、训练和测试隔离；仅给启发式分数或累计收益命名为“奖励”，不会使现有代码自动成为强化学习。')])

page('26 冻结与复现：怎样让别人检查同一套系统',[
 p('冻结包标识为V4_optimized_frozen_2026-10-18。ZIP的SHA256为b971098c73c25c99b683b3534a3f8d9a954930543514d9ffc485d4a18eb03f00。核心源码和运行参数生成器与已验收协议一致；本PDF单独放在说明文档目录，没有改写原ZIP。','small'),
 p('参考环境：Ubuntu22.04 x86_64、Python3.10、ROS2 Humble、Gazebo Classic11.10.2、Nav2 1.1.20、slam_toolbox2.6.10。本地vendor固定tf2/tf2_ros0.25.24和Cyclone DDS。模型资源依赖TurtleBot3 Gazebo包。准确Debian构建版本见environment/。'),
 p('python3 scripts/verify_release.py\npython3 scripts/check_environment.py\nbash scripts/build_isolated.sh\nbash scripts/run_gui.sh --map-seed 7 --policy-seed 11\n# 原四组重新验收\npython3 scripts/run_validation_suite.py\npython3 scripts/export_reproduction_report.py','code'),
 p('固定两个种子、生成器、源世界和参数可以重建同一输入。策略种子对坐标字符串做BLAKE2b微扰；SLAM坐标或消息时序发生小变化，后续候选顺序也可能不同，因此相同种子不保证轨迹和耗时逐次相同。'),
 p('保存世界文件哈希、完整生成YAML、依赖版本和原始结果，报告重复运行的分布，才是可核查的复现。墙上时间受硬件/负载影响；某些RPC与启动保护还采用墙时截止，不能把运行器描述为完全硬件无关。'),
 p('每个新实验都有独立ROS domain、Gazebo master和UUID目录。报告工具写入reproduction_reports，保留发布参考表。运行失败与未运行组分别记录，不从成功率分母里删除。')])

page('27 数据文件索引与术语对照',[
 table(['文件','回答的问题'],[
 ('manifest.json','用了什么源文件、种子、参数生成器、运行库和哈希？'),
 ('world.sdf / scene_actual_poses.json','定义的障碍布局与Gazebo实际加载位置分别是什么？'),
 ('scene_audit.json','八个静态模型的实际坐标是否和独立评估几何一致？'),
 ('deployment_odom.json / result.json','实际部署点、最终位姿、覆盖率与终止原因是什么？'),
 ('evaluation.csv','覆盖率随仿真时间怎样变化？'),
 ('navigation_health.csv','路径/足迹输入是否新鲜，机器人是否移动，最后输出什么速度？'),
 ('mission_events.jsonl / safety_events.jsonl','目标何时分配/失败/取消、何时返航、安全门是否介入？'),
 ('fused_slam_map.pgm / yaml / preview.png','标准地图和统一8倍显示预览；不是SDF真值地图'),
 ('ROOT_CAUSE / RETURN_FIX / SCENE_FIX','死锁、返航控制及场景一致性的诊断与修改依据')],[1.5,2.8]),
 table(['术语','本版语境'],[
 ('frontier','已知可达空闲格与未知相邻的边界'),('观测位姿','已知可通行区内的位置+朝向'),('IG代理','48评分射线首个未知格的去重计数'),('Nav2 goal','要去的位置，不是要执行的速度动作'),('lease','临时区域归属，当前单机仅用于候选选择框架'),('策略种子','同分附近目标偏好，不是强化学习权重'),('RTF / 墙上时间','计算运行效率相关量，与探索路径效率分开')],[1.2,3])])

page('28 源码与官方参考',[
 p('本手册的主要依据是冻结包中的源码与实际生成参数。章节底部给出了相对路径、函数和起始行号，便于在VSCode定位。入口/模型参数以scripts/run_test.py和src/active_slam_v4/launch/v4_test.launch.py为准；接口类默认值可能被运行构造器覆盖。'),
 table(['编号','外部参考（只作为库接口与修复背景）'],[
 ('O1','Nav2 Humble RPP官方源码：github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp'),
 ('O2','slam_toolbox Humble README：github.com/SteveMacenski/slam_toolbox/blob/humble/README.md'),
 ('O3','geometry2 Humble ABBA死锁修复#990：github.com/ros2/geometry2/pull/990'),
 ('O4','Gazebo ROS差速驱动源码：github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp')],[.4,4]),
 p('这些上游链接的分支内容可能继续变化；复现实验优先对照冻结包的Debian版本、源文件哈希与实际参数快照。本文没有从上游文档推断本项目启用了全部库功能，也没有把未配置的闭环、A*或学习策略写成本版实现。'),
 p('证据分类：①代码直接执行的事实；②由运行数据支持的功能结果；③关于局限的工程分析。未来研究方向仅出现在边界/后续章节，不计入当前成功率或实现功能。'),
 p('文档生成日期按Asia/Shanghai（北京时间）记录。本文是配套技术手册，不替换冻结ZIP内的发布报告、原始数据或校验清单。')])

# Correct directional ports and replace the overview with a readable, two-lane
# vector diagram (all labels remain selectable PDF text).
def diagram(boxes,edges,height=280):
 d=Drawing(CW,height)
 for key,(x,y,w,h,lines,kind) in boxes.items():
  d.add(Rect(x,y,w,h,rx=5,ry=5,fillColor=colors.HexColor('#E3F2F0') if kind=='eval' else LIGHT,strokeColor=TEAL if kind=='eval' else colors.HexColor('#9AB2C3'),strokeWidth=.8))
  ls=lines.split('\n')
  for i,line in enumerate(ls):d.add(String(x+w/2,y+h/2+(len(ls)-1)*6-i*12,line,fontName='CN',fontSize=8.7,textAnchor='middle',fillColor=INK))
 for a,b,label in edges:
  ax,ay,aw,ah,*_=boxes[a];bx,by,bw,bh,*_=boxes[b]
  if abs((ax+aw/2)-(bx+bw/2))>max(aw,bw)*.55:
   if bx>ax:x1,y1=ax+aw,ay+ah/2;x2,y2=bx,by+bh/2
   else:x1,y1=ax,ay+ah/2;x2,y2=bx+bw,by+bh/2
  elif by>ay:x1,y1=ax+aw/2,ay+ah;x2,y2=bx+bw/2,by
  else:x1,y1=ax+aw/2,ay;x2,y2=bx+bw/2,by+bh
  d.add(Line(x1,y1,x2,y2,strokeColor=TEAL,strokeWidth=1));ang=math.atan2(y2-y1,x2-x1);r=5
  d.add(Polygon([x2,y2,x2-r*math.cos(ang-.45),y2-r*math.sin(ang-.45),x2-r*math.cos(ang+.45),y2-r*math.sin(ang+.45)],fillColor=TEAL,strokeColor=TEAL))
  if label:d.add(String((x1+x2)/2+3,(y1+y2)/2+3,label,fontName='CN',fontSize=7.3,fillColor=GRAY))
 return d
boxes={
 'a':(20,350,250,38,'激光 / 里程计 / TF 输入','run'),
 'b':(20,295,250,38,'slam_toolbox → SLAM 栅格','run'),
 'c':(20,240,250,38,'可达 frontier → 安全观测位姿','run'),
 'd':(20,185,250,38,'收益代理 + Nav2 路径代价 → 选目标','run'),
 'e':(20,130,250,38,'Nav2 / RPP → 速度平滑','run'),
 'f':(20,75,250,38,'最终激光安全门 → cmd_vel','run'),
 'g':(20,20,250,38,'Gazebo 机器人运动 → 新扫描','run'),
 'h':(330,260,170,53,'独立 SDF 真值 + /map\n固定分母覆盖率评估','eval'),
 'i':(330,165,170,53,'Mission 状态机\n双门槛 → 返航','eval'),
 'j':(330,65,170,60,'部署点 + 当前动态TF\n返航目标 / 实际误差核验','eval')}
d=diagram(boxes,[('a','b',''),('b','c',''),('c','d',''),('d','e','目标'),('e','f',''),('f','g',''),('b','h','地图'),('h','i','指标'),('i','j','返航'),('i','e','阶段控制')],405)
for x1,y1,x2,y2 in ((20,39,5,39),(5,39,5,369),(5,369,20,369)):d.add(Line(x1,y1,x2,y2,strokeColor=TEAL,strokeWidth=1))
d.add(Polygon([20,369,15,372,15,366],fillColor=TEAL,strokeColor=TEAL))
PAGES[1][1][0]=d
PAGES[1][1][1]=p('左侧是在线自主探索闭环；右侧是独立实验评估与任务阶段控制。评估器只传覆盖率/是否达标，不把未知几何给候选选择。返航同样交给Nav2执行，但目标依据真实部署记录和当前动态TF计算。')
# Rebuild the state drawing using the corrected directional helper.
PAGES[16][1][0]=diagram({'a':(0,190,140,50,'STARTUP\n等待感知 / TF / Nav2','run'),'b':(180,190,140,50,'EXPLORE\n观测目标闭环','run'),'c':(360,190,140,50,'RETURN\n实际部署点返航','run'),'d':(360,65,140,50,'COMPLETE\n返航位置核验通过','eval'),'e':(90,65,170,50,'FAILED\n保存原因与当前地图','run')},[('a','b','就绪'),('b','c','双门槛通过'),('c','d','返回'),('a','e','失败'),('b','e','超时 / 故障')],260)

# The new user-requested run is appended separately from frozen historical data.
rp=RUN/'result.json'
new_result=json.loads(rp.read_text()) if rp.exists() else {}
raw_events=[json.loads(x) for x in (RUN/'mission_events.jsonl').read_text().splitlines()] if (RUN/'mission_events.jsonl').exists() else []
audit=json.loads((RUN/'scene_audit.json').read_text()) if (RUN/'scene_audit.json').exists() else {}
latest=[]
if (RUN/'evaluation.csv').exists():
 with (RUN/'evaluation.csv').open() as f:latest=list(csv.DictReader(f))
metric=new_result.get('evaluation') or (latest[-1] if latest else {})
now_cn=datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M:%S')
current=[p(f'本次观察测试：地图种子484794，策略种子677270；窗口启动后独立保存，未更改冻结版本。记录时刻：{now_cn}（北京时间）。'),
 table(['项目','本次记录'],[
 ('任务状态',new_result.get('status','运行中，尚无终止结果')),
 ('探索率 / ROI',f"{float(metric.get('exploration_pct',0)):.5f}% / {float(metric.get('roi_known_pct',0)):.5f}%"),
 ('任务仿真时间',str(new_result.get('sim_seconds','运行中，以最终result为准'))+' 秒'),
 ('返航位置误差',(f"{new_result['home_error_odom_m']['robot1']:.6f} 米" if new_result else '未结束')),
 ('场景审计','通过' if audit.get('passed',False) else '未通过'),
 ('已记录导航成功 / 非成功',str(sum(e.get('result')=='success' for e in raw_events if e['event']=='goal_result'))+' / '+str(sum(e.get('result')!='success' for e in raw_events if e['event']=='goal_result'))),
 ('输入故障 / 重置',str(sum(e['event']=='navigation_input_fault' for e in raw_events))+' / '+str(sum(e['event']=='navigation_reset_started' for e in raw_events)))],[1.5,3]),
 p('本次已实际完成探索与返航：最终result为COMPLETE、双覆盖率符合标准、部署点误差小于0.35米，场景审计通过。记录的36次导航结果全部成功，无输入故障或导航重置。该运行作为新的独立测试附录，原四组验收数据和发布ZIP保持冻结。' if new_result.get('status')=='COMPLETE' else '本次仍在运行，成功与否以最终result.json和部署点核验为准。')]
if new_result:
 for name in ('result.json','manifest.json','scene_audit.json','evaluation.csv','navigation_health.csv','mission_events.jsonl','fused_slam_map_preview.png','fused_slam_map.pgm','fused_slam_map.yaml','world.sdf','robot1.sdf','robot1_nav2.yaml','robot1_slam.yaml','navigate_bounded.xml','navigate_return.xml','scene_actual_poses.json','deployment_odom.json','launch.log','requested_random_test.json'):
  if (RUN/name).is_file():
   (ROOT/'current_test').mkdir(exist_ok=True);shutil.copy2(RUN/name,ROOT/'current_test'/name)
if (RUN/'fused_slam_map_preview.png').exists() and new_result:
 shutil.copy2(RUN/'fused_slam_map_preview.png',ROOT/'figures/current_test_map.png')
 current.append(Image(str(ROOT/'figures/current_test_map.png'),width=235,height=235,hAlign='CENTER'))
page('29 本次随机观察测试记录',current)

class GuideDoc(BaseDocTemplate):
 def __init__(self,path):
  super().__init__(str(path),pagesize=A4,leftMargin=M,rightMargin=M,topMargin=51,bottomMargin=49,title='V4 主动 SLAM 探索系统：整体算法架构与实现详解',author='V4 项目技术说明',subject='冻结单机版源码、算法闭环、导航安全、覆盖率与复现')
  frame=Frame(M,49,CW,H-100,id='main',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
  self.addPageTemplates(PageTemplate(id='main',frames=[frame],onPage=self.header))
 def header(self,c,doc):
  if doc.page>1:
   c.setStrokeColor(TEAL);c.setLineWidth(.7);c.line(M,H-35,W-M,H-35)
   c.setFillColor(GRAY);canvas_text(c,M,H-28,'V4 主动 SLAM 探索系统  |  单机优化冻结版 · 源码核对说明')
   canvas_text(c,M,29,'配套手册 · 2026-10-18 · Asia/Shanghai');canvas_text(c,W-M,29,str(doc.page),right=True)
 def afterFlowable(self,f):
  if isinstance(f,Paragraph) and f.style.name=='h1' and f.getPlainText()[:2].isdigit():
   text=f.getPlainText();key='section'+str(self.seq.nextf('section'));self.canv.bookmarkPage(key);self.canv.addOutlineEntry(text,key,0,False);self.notify('TOCEntry',(0,font_html(text),self.page,key))

def image_md(flow):
 if isinstance(flow,Paragraph):return flow.getPlainText()
 if isinstance(flow,Table):
  lines=[]
  for i,row in enumerate(flow._cellvalues):
   lines.append('| '+' | '.join(c.getPlainText().replace('\n',' ') if isinstance(c,Paragraph) else str(c) for c in row)+' |')
   if i==0:lines.append('| '+' | '.join('---' for _ in row)+' |')
  return '\n'.join(lines)
 if isinstance(flow,Image):return f'![图示]({Path(flow.filename).relative_to(ROOT)})'
 if isinstance(flow,Drawing):return '【PDF中为可选中文字的矢量结构图】'
 return ''

def main():
 for _,items in PAGES:
  for item in items:
   if isinstance(item,Drawing):fix_drawing_fonts(item)
 story=[Spacer(1,55),p('V4 主动 SLAM\n探索系统','cover'),p('整体算法架构与实现详解','h1'),p('从激光、地图和前沿目标，到安全导航、覆盖率评估与实际部署点返航。'),Spacer(1,18),table(['文档基准','说明'],[('冻结发布','V4_optimized_frozen_2026-10-18'),('当前范围','单机版本；双机组件单独说明边界'),('依据','实际源码、生成YAML、原始运行记录'),('包含','29节详细说明、闭环结构图、状态图、公式、表格、曲线、地图及源码索引'),('生成时间',now_cn+' 北京时间')],[1.1,3]),Spacer(1,24),p('先读第01～04节建立整体认识；第06～10节看探索决策；第11～20节看执行、可靠性和评估；第23～29节看结果、复现与本次随机测试。'),PageBreak()]
 toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc0',fontName='Latin',fontSize=9.3,leading=12.5,spaceBefore=0,spaceAfter=0,textColor=INK,leftIndent=0,firstLineIndent=0)]
 story.extend([p('目录','h1'),toc,PageBreak()])
 for title,items in PAGES:
  story.append(p(title,'h1'));story.extend(items);story.append(PageBreak())
 if isinstance(story[-1],PageBreak):story.pop()
 output=ROOT/'V4_algorithm_architecture_detailed_2026-10-18.pdf'
 GuideDoc(output).multiBuild(story)
 md=['# V4 主动 SLAM 探索系统：整体算法架构与实现详解','',f'生成时间：{now_cn}（北京时间）。以冻结单机版实际源码为准。','']
 for title,items in PAGES:
  md.extend(['## '+title,'']+[image_md(f)+'\n' for f in items])
 (ROOT/'V4_algorithm_architecture_detailed_2026-10-18.md').write_text('\n'.join(md))
 metadata={'pdf':output.name,'generated_beijing':now_cn,'sections':len(PAGES),'frozen_release_sha256':hashlib.sha256(SRC.with_suffix('.zip').read_bytes()).hexdigest(),'source_release':SRC.name,'current_test_run':str(RUN),'current_test_status':new_result.get('status','RUNNING'),'source_files_sha256':{str(f.relative_to(SRC)):hashlib.sha256(f.read_bytes()).hexdigest() for folder in ('src','scripts') for f in (SRC/folder).rglob('*') if f.is_file() and '__pycache__' not in str(f)}}
 (ROOT/'DOCUMENT_MANIFEST.json').write_text(json.dumps(metadata,indent=2));print(json.dumps(metadata|{'source_files_sha256':'recorded'},indent=2))
if __name__=='__main__':main()
