from pathlib import Path
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
import json,csv,numpy as np
from PIL import Image,ImageOps,ImageDraw,ImageFont
O=Path(__file__).resolve().parents[1];font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';fp=FontProperties(fname=font)
plt.rcParams.update({'font.family':fp.get_name(),'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
from matplotlib import font_manager;font_manager.fontManager.addfont(font)
colors=['#087f8c','#3157a4','#c86628'];fig,axs=plt.subplots(1,2,figsize=(10,4.1),sharex=True)
for j,seed in enumerate([29,7,13]):
 rows=list(csv.DictReader((O/f'data/final_r003_seed{seed}/evaluation.csv').open()));x=[float(r['sim_time']) for r in rows]
 for ax,k in zip(axs,['exploration_pct','roi_known_pct']):ax.step(x,[float(r[k]) for r in rows],where='post',label=f'种子{seed}',color=colors[j],lw=1.6)
 gate=next(r for r in rows if float(r['exploration_pct'])>95 and float(r['roi_known_pct'])>90)
 axs[0].axvline(float(gate['sim_time']),color=colors[j],ls=':',alpha=.55)
for ax,title,thresh in zip(axs,['可达空闲区探索率','固定ROI已知率'],[95,90]):
 ax.set(title=title,xlabel='仿真时间 / s',ylabel='覆盖率 / %',ylim=(0,103));ax.axhline(thresh,color='#555',ls='--',lw=.8);ax.grid(alpha=.18);ax.legend(loc='lower right')
fig.tight_layout();fig.savefig(O/'figures/formal_curves.png');fig.savefig(O/'figures/formal_curves.svg');plt.close(fig)
fig,ax=plt.subplots(figsize=(10,3.1))
for d,label,c in [('clock_fix_r001_seed29','r001：覆盖未达标，双车返回','#a14b42'),('final_r003_seed29','r003：完整通过','#087f8c')]:
 rows=list(csv.DictReader((O/f'data/{d}/evaluation.csv').open()));ax.step([float(r['sim_time']) for r in rows],[float(r['exploration_pct']) for r in rows],where='post',label=label,color=c,lw=1.8)
ax.axhline(95,color='#666',ls='--',lw=.8);ax.set(xlabel='仿真时间 / s',ylabel='探索率 / %',ylim=(0,103));ax.grid(alpha=.18);ax.legend();fig.tight_layout();fig.savefig(O/'figures/failure_tail.png');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(10,3.2)); ax[0].bar(['完成返航','返航失败','超时'],[15,8,21],color=['#087f8c','#c86628','#a14b42']);ax[0].set(title='V3：44组，旧ROI协议',ylabel='运行次数')
ax[1].bar(['r028','r029'],[26,34],color=['#6582aa','#087f8c']);ax[1].bar(['r028','r029'],[10,2],bottom=[26,34],color='#e2d4cb',label='未成功');ax[1].set(title='V5：相同36项，含基础设施失败',ylim=(0,40),ylabel='运行次数')
for a,vals in [(ax[0],[15,8,21]),(ax[1],[26,34])]:
 for i,v in enumerate(vals):a.text(i,v+.3,str(v),ha='center')
fig.tight_layout();fig.savefig(O/'figures/historical_results.png');plt.close(fig)
# Architecture draws own code diagram; no generated bitmap assets needed.
fig,ax=plt.subplots(figsize=(11,7));ax.set(xlim=(0,11),ylim=(0,7));ax.axis('off')
def box(x,y,w,h,text,color='#eaf3f5',edge='#286773'):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.08,rounding_size=.08',fc=color,ec=edge,lw=1.1));ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=10)
def arrow(a,b,dash=False):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=12,lw=1.2,color='#466372',linestyle='--' if dash else '-'))
for x,n in [(.25,'R1'),(4.1,'R2')]:
 box(x,5.8,3.25,.65,n+' 激光 / 近地观测 / WORLD里程计')
 box(x,4.65,3.25,.65,'建图队友滤波 → slam_toolbox\n本车地图 + 动态TF')
 box(x,3.5,3.25,.65,'frontier → 完整足迹安全位姿\nNav2路径 / 收益 / 返航预算')
 box(x,1.05,3.25,.7,'Nav2 Smac Hybrid-A* + MPPI\n安全速度门 → 机器人运动')
 arrow((x+1.625,5.8),(x+1.625,5.3));arrow((x+1.625,4.65),(x+1.625,4.15));arrow((x+1.625,3.5),(x+1.625,3.02));arrow((x+1.625,2.15),(x+1.625,1.75))
box(.25,2.23,7.1,.7,'P2Runtime：D_joint / 条件推进 / token / 租约 / 通道路权\n每车状态与规划独立；取消确认、有限恢复、双车返航',color='#dcebed')
box(7.9,4.65,2.8,.7,'公共team_map融合\n已知初始对齐 / 来源健康')
arrow((7.35,4.98),(7.82,4.98));arrow((9.3,4.65),(7.35,3.85))
ax.plot([3.5,3.78,3.78,9.3],[4.98,4.98,5.53,5.53],color='#466372',lw=1.1);arrow((9.3,5.53),(9.3,5.35))
ax.plot([9.3,9.3,1.875],[4.65,4.4,4.4],color='#466372',lw=1.1);arrow((1.875,4.4),(1.875,4.15))
box(7.9,2.23,2.8,1.25,'独立评价与审计\n固定真值 / ROI\n接触 / 物理轨迹 / 时间',color='#fff1da',edge='#a57a32')
arrow((9.3,4.65),(9.3,3.48),True);arrow((7.9,2.7),(7.35,2.7),True)
ax.text(8,1.65,'仅达标信号进入阶段控制\n真值不进入选点/评分/脱困',fontsize=10,color='#825f24')
ax.text(.3,.25,'运动 → 新传感器 → 地图更新 → 新目标：持续闭环\n历史Q表/RPP未接入本次r003决策；定位熵与未知配准尚未实现',fontsize=10,color='#425968')
fig.tight_layout();fig.savefig(O/'figures/architecture.png',bbox_inches='tight');fig.savefig(O/'figures/architecture.svg',bbox_inches='tight');plt.close(fig)
# Keep exact palette, no recoloring, fit preview panels.
fontp=ImageFont.truetype(font,26);canvas=Image.new('RGB',(1500,560),'white');draw=ImageDraw.Draw(canvas)
for i,seed in enumerate([29,7,13]):
 im=Image.open(O/f'data/final_r003_seed{seed}/fused_slam_map_preview.png').convert('RGB');im.thumbnail((490,490),Image.NEAREST);canvas.paste(im,(i*500+(500-im.width)//2,50+(500-im.height)//2));draw.text((i*500+160,5),f'正式种子 {seed}',font=fontp,fill='#193748')
canvas.save(O/'figures/map_panel.png')
print('figures built')
