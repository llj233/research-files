from pathlib import Path
import hashlib,json,csv,shutil,zipfile
R=Path('/home/lemuel/Downloads'); O=R/'毕设阶段汇报_2026-10-29'; B=R/'V6_P2_V3Map_Regression_2026-10-29'; F=B/'repairs/r003_preflight_clock'; G=R/'V6_P2_r003_GUI_V3_2026-10-29/20261029T134417Z_9982e5e2'; C=B/'reports/optimization_closure_2026-10-29'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
paths=['毕设版本索引.md','V3/README.md','V3/ACTIVE_SLAM_V3.md','V3/ACTIVE_SLAM_V3_RESULTS.md','V3/ACTIVE_SLAM_POST44.md','V3/ACTIVE_SLAM_V3_OPT.md','V3/experiments/active_slam_opt/reports/phase44_2026-10-16/phase44_report.md','V3/experiments/active_slam_opt/reports/phase44_2026-10-16/phase44_results.csv','V4_optimized_frozen_2026-10-18/VALIDATION_REPORT.md','V4_optimized_frozen_2026-10-18/VALIDATION_RESULTS.csv','V4_optimized_frozen_2026-10-18/ALL_ATTEMPTS.csv','V4_optimized_frozen_2026-10-18/ROOT_CAUSE.md','V4_optimized_frozen_2026-10-18/RETURN_FIX.md','V5_FINAL_r039_2026-10-27/README.md','V5_FINAL_r039_2026-10-27/全部7次结果.csv','V5_r029_实验归档与后续方案_2026-10-24/reports/实验结果复核与诊断.md','V5_r028_实验复核与后续优化方案_2026-10-23/统计与诊断.json','V6_dual_r001_2026-10-27/reports/P0_阶段运行报告.md','V6_dual_r004_p2_2026-10-27/reports/P2_最终验收报告.md','V6_dual_r004_p2_2026-10-27/reports/P2_最终结果.csv']
paths += [str(p.relative_to(R)) for p in C.glob('*') if p.suffix in ('.md','.csv','.json','.patch')]
paths += [str(p.relative_to(R)) for p in [F/'VERIFIED_GROUP.json',F/'VERIFIED_SOURCE_HASHES.json',F/'protocol/V3_REGRESSION.json',G/'observation_final_verification.json',G/'result.json',G/'summary.json',G/'config/parameter_identity.json',G/'config/frozen_source_hashes.json',G/'final_pose_queries_raw.json',G/'可视化例行测试报告.md']]
# Correct P1 report lookup by content/name rather than infer filename.
paths += [str(p.relative_to(R)) for p in (R/'V6_dual_r002_p1_2026-10-27/reports').glob('*.md')]
inventory=[];missing=[]
for rel in dict.fromkeys(paths):
 p=R/rel
 if not p.is_file():missing.append(rel);continue
 q=O/'sources/local'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 inventory.append({'source_path':rel,'size':p.stat().st_size,'sha256':sha(p),'copy':str(q.relative_to(O))})
rows=list(csv.DictReader((C/'V3地图回归_结果汇总.csv').open(encoding='utf-8-sig')))
for row in rows:
 d=Path(row['run_dir']);target=O/'data'/f"{row['role']}_seed{row['seed']}";target.mkdir(exist_ok=True)
 for name in ['evaluation.csv','result.json','summary.json','manifest.json']:
  p=d/name
  if p.exists():shutil.copy2(p,target/name);inventory.append({'source_path':str(p.relative_to(R)),'size':p.stat().st_size,'sha256':sha(p),'copy':str((target/name).relative_to(O))})
 for name in ['team/fused_slam_map_preview.png','team/fused_slam_map.json']:
  p=d/name
  if p.exists():shutil.copy2(p,target/p.name)
 shutil.copy2(d/'evaluation.csv',target/'evaluation.csv')
 q=target/'evaluation.csv';samples=list(csv.DictReader(q.open()));print(row['role'],row['seed'],'columns',list(samples[0]));
final=O/'data/GUI_seed29';final.mkdir(exist_ok=True)
for n in ['evaluation.csv','observation_final_verification.json','summary.json','result.json','config/parameter_identity.json']:
 p=G/n;shutil.copy2(p,final/p.name)
for n in ['final_rviz.png','final_gazebo.png']:shutil.copy2(G/'screenshots'/n,O/'figures'/n)
shutil.copy2(G/'team/fused_slam_map_preview.png',O/'figures/GUI_建图_原8倍显示.png')
hashes=json.loads((F/'VERIFIED_SOURCE_HASHES.json').read_text());gh=json.loads((G/'config/frozen_source_hashes.json').read_text());bad=[]
for rel,h in hashes.items():
 p=F/rel
 if not p.exists() or sha(p)!=h:bad.append(rel)
check={'source_snapshot_id':'b4c0ee7639e06a23','source_file_count':len(hashes),'current_mismatches':bad,'GUI_hash_manifest_exactly_equals_formal':hashes==gh,'GUI_normalized_config_receipt':json.loads((G/'config/parameter_identity.json').read_text()),'formal_group':json.loads((F/'VERIFIED_GROUP.json').read_text()),'checked_date_Asia_Shanghai':'2026-10-29'}
write(O/'data/版本与配置复核.json',check);write(O/'sources/本地证据索引.json',inventory);write(O/'sources/读取缺失项.json',missing)
# Code references: exact files/definitions, line numbers and hashes.
refs=[]
for pkg in ['active_slam_v6/active_slam_v6','active_slam_v4/active_slam_v4','v4_evaluator/v4_evaluator']:
 for p in (F/'src'/pkg).glob('*.py'):
  for i,line in enumerate(p.read_text().splitlines(),1):
   if line.startswith(('class ','def ','    def ')):refs.append({'path':str(p.relative_to(F)),'line':i,'definition':line.strip(),'sha256':sha(p)})
with (O/'sources/代码定位.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['path','line','definition','sha256']);w.writeheader();w.writerows(refs)
write(O/'data/汇报用正式数据.json',rows)
print('Evidence files',len(inventory),'frozen check',len(hashes),'mismatches',bad,'missing',missing)
