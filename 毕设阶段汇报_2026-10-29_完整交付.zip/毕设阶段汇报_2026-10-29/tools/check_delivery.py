from pathlib import Path
import json,csv,hashlib,subprocess,xml.etree.ElementTree as ET,zipfile,re,collections
O=Path(__file__).resolve().parents[1];R=O.parent;checks=[]
def check(name,ok,detail=None):
 checks.append({'check':name,'passed':bool(ok),'detail':detail});assert ok,(name,detail)
def rows(p):return list(csv.DictReader(Path(p).open(encoding='utf-8-sig')))
v3=rows(R/'V3/experiments/active_slam_opt/reports/phase44_2026-10-16/phase44_results.csv');cnt=collections.Counter(x['status'] for x in v3);check('V3原表44行',len(v3)==44,dict(cnt));check('V3结局15/8/21',cnt.get('completed')==15 and cnt.get('return_failed')==8 and cnt.get('timeout')==21)
v5=rows(O/'data/V5_r028_r029_36次配对结果与诊断.csv');counts=[sum(x[k]=='True' for x in v5) for k in ['old_success','new_success','valid_r029']];check('V5配对36行与26/34/35分母',len(v5)==36 and counts==[26,34,35],counts)
reg=json.loads((O/'data/汇报用正式数据.json').read_text());check('旧图完整任务保留2失败3成功',len(reg)==5 and sum(x['accepted']=='True' for x in reg)==3)
for r in reg:
 if r['role']!='final_r003':continue
 data=rows(O/f"data/final_r003_seed{r['seed']}/evaluation.csv");last=data[-1];gate=next(x for x in data if float(x['exploration_pct'])>95 and float(x['roi_known_pct'])>90)
 check('正式种子'+r['seed']+'覆盖/门槛与原CSV一致',all(abs(float(last[k])-float(r[q]))<1e-8 for k,q in [('exploration_pct','exploration_pct'),('roi_known_pct','roi_pct')]) and abs(float(gate['sim_time'])-float(r['T95_sim_s']))<1e-8,{'gate':gate,'final':last})
 check('正式种子'+r['seed']+'固定覆盖分母',int(last['reachable_free_total'])==33742 and int(last['roi_total_cells'])==35771)
 check('正式种子'+r['seed']+'双返回与接触',r['robot1_returned']=='True' and r['robot2_returned']=='True' and max(float(r['robot1_home_error_m']),float(r['robot2_home_error_m']))<=.35 and r['environment_contact_episodes']=='0' and r['peer_contact_recorded']=='False' and r['all_contact_sensors']=='True')
F=R/'V6_P2_V3Map_Regression_2026-10-29/repairs/r003_preflight_clock';G=R/'V6_P2_r003_GUI_V3_2026-10-29/20261029T134417Z_9982e5e2'
ha=json.loads((F/'VERIFIED_SOURCE_HASHES.json').read_text());bad=[p for p,h in ha.items() if hashlib.sha256((F/p).read_bytes()).hexdigest()!=h];check('冻结174文件未改动',len(ha)==174 and not bad,bad);check('GUI与正式源清单相同',ha==json.loads((G/'config/frozen_source_hashes.json').read_text()));check('GUI10个关键配置归一化一致',json.loads((G/'config/parameter_identity.json').read_text())['identical_to_validated_seed29_except_run_paths'])
g=json.loads((G/'observation_final_verification.json').read_text());summary=json.loads((G/'summary.json').read_text());check('GUI审计告警原样保留',g['original_audit_export_task_success'] is False and g['continuous_physical_trajectory_available'] is False and summary['task_success'] is False)
check('GUI观察数值匹配',abs(g['exploration_pct']-99.07533637602987)<1e-10 and g['T95_sim_s']==152.005 and g['total_task_sim_s']==258.805 and g['environment_contact_episodes']==g['peer_contact_episodes']==0)
for name in ['毕业设计中文阶段汇报报告','汇报讲稿与导师问答']:
 pdf=O/(name+'.pdf');txt=subprocess.check_output(['pdftotext',str(pdf),'-']).decode();info=subprocess.check_output(['pdfinfo',str(pdf)]).decode();pages=int(re.search(r'Pages:\s*(\d+)',info).group(1));check(name+'可提取中文且无替换字符',len(re.findall('[\u4e00-\u9fff]',txt))>1000 and '\ufffd' not in txt,{'pages':pages,'Chinese_characters':len(re.findall('[\u4e00-\u9fff]',txt))})
 if name.startswith('毕业'):check('正式报告26页',pages==26)
for name,images in [('毕业设计中文阶段汇报报告',6),('汇报讲稿与导师问答_可编辑',0)]:
 with zipfile.ZipFile(O/(name+'.docx')) as z:
  check(name+'Word包完整',z.testzip() is None);doc=ET.fromstring(z.read('word/document.xml'));rels=ET.fromstring(z.read('word/_rels/document.xml.rels'));check(name+'图片全部嵌入',sum(n.startswith('word/media/') for n in z.namelist())==images and not any(x.get('TargetMode')=='External' for x in rels));extent=doc.findall('.//{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}extent');check(name+'图表宽度在版心内',all(int(x.get('cx'))<=504*12700+1 for x in extent))
# Inspect PDF extracted word bounds. Footer/title margins are intentionally included.
bbox=O/'quality/正文边界.html'
if bbox.exists():
 root=ET.fromstring(bbox.read_bytes());outside=[]
 for page_i,page in enumerate(root.findall('.//{http://www.w3.org/1999/xhtml}page'),1):
  for w in page.findall('.//{http://www.w3.org/1999/xhtml}word'):
   if float(w.get('xMin'))<35 or float(w.get('xMax'))>562 or float(w.get('yMin'))<20 or float(w.get('yMax'))>824:outside.append((page_i,''.join(w.itertext()),w.attrib))
 check('PDF文字均在页面安全边界内',not outside,outside[:10])
lecture=(O/'汇报讲稿与导师问答.md').read_text().split('# 导师可能追问')[0];chinese=len(re.findall('[\u4e00-\u9fff]',lecture));check('讲稿5至8分钟参考长度',1200<=chinese<=2400,{'Chinese_characters':chinese,'note':'按个人语速与指图停顿约6—7分钟，需现场试讲，不冒称已计时录音。'})
q={'status':'passed','date_Asia_Shanghai':'2026-10-29','checks':checks,'visual_inspection':'查看26页缩略总览及摘要/架构/实验告警页，中文显示、表格/图像与分页正常；页脚字体已修正。','warnings_preserved':['GUI continuous physical audit missing, original summary false','V5 r039 N04 speed regression','V3 historical failures','Current old-map 3-seed scope only'],'algorithm_or_original_record_mutations':False}
(O/'quality/交付质量核验.json').write_text(json.dumps(q,ensure_ascii=False,indent=2));print('all',len(checks),'checks passed; lecture CJK',chinese)
