"""Generate self-contained editable OOXML with bounded tables/images."""
from pathlib import Path
import json,zipfile,html
from PIL import Image
O=Path(__file__).resolve().parents[1]
def esc(t):return html.escape(str(t),quote=True)
def run(text,size=21,bold=False,color='263B48'):
 return '<w:r><w:rPr><w:rFonts w:ascii="DejaVu Sans" w:hAnsi="DejaVu Sans" w:eastAsia="Noto Sans CJK SC"/><w:sz w:val="'+str(size)+'"/><w:szCs w:val="'+str(size)+'"/><w:color w:val="'+color+'"/>'+('<w:b/>' if bold else '')+'</w:rPr><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r>'
def para(text,size=21,bold=False,color='263B48',before=False,keep=False,after=120):
 return '<w:p><w:pPr><w:spacing w:after="'+str(after)+'" w:line="320" w:lineRule="auto"/>'+('<w:pageBreakBefore/>' if before else '')+('<w:keepNext/>' if keep else '')+'</w:pPr>'+('<w:r><w:br/></w:r>'.join(run(x,size,bold,color) for x in str(text).split('\n')) )+'</w:p>'
def build(sections,name):
 body=[];media={};rels=[];rid=1;picid=1
 for i,s in enumerate(sections):
  body.append(para(s['title'],34,True,'163D52',before=bool(i),keep=True,after=240))
  for b in s['blocks']:
   typ=b['type']
   if typ in ('p','h','equation','code'):
    body.append(para(b['text'],{'h':25,'equation':20,'code':17}.get(typ,21),typ=='h','087F8C' if typ=='h' else '263B48',keep=typ=='h'))
   elif typ=='table':
    ws=b.get('widths') or [1/len(b['heads'])]*len(b['heads']);widths=[int(10080*v) for v in ws]
    tab=['<w:tbl><w:tblPr><w:tblW w:w="10080" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:bottom w:val="single" w:sz="4" w:color="C4D4DC"/><w:insideH w:val="single" w:sz="2" w:color="E4EDF1"/></w:tblBorders><w:tblCellMar><w:top w:w="80" w:type="dxa"/><w:left w:w="85" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/><w:right w:w="85" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>']
    tab+=['<w:gridCol w:w="'+str(w)+'"/>' for w in widths];tab.append('</w:tblGrid>')
    for j,row in enumerate([b['heads']]+b['rows']):
     tab.append('<w:tr><w:trPr><w:cantSplit/>'+('<w:tblHeader/>' if j==0 else '')+'</w:trPr>')
     for w,x in zip(widths,row):
      tab.append('<w:tc><w:tcPr><w:tcW w:w="'+str(w)+'" w:type="dxa"/><w:shd w:fill="'+('DCEBF0' if j==0 else 'F4F8FA' if j%2 else 'FFFFFF')+'"/><w:vAlign w:val="top"/></w:tcPr>'+para(x,17,j==0,after=20)+'</w:tc>')
     tab.append('</w:tr>')
    tab.append('</w:tbl>');body.extend(tab);body.append(para('',after=30))
   elif typ=='figure':
    path=O/'figures'/b['file'];im=Image.open(path);w,h=im.size;scale=min(504/w,b.get('height',240)/h);cx=int(w*scale*12700);cy=int(h*scale*12700)
    target='media/'+path.name;media['word/'+target]=path.read_bytes();rels.append(f'<Relationship Id="rId{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="{esc(target)}"/>')
    body.append(f'<w:p><w:pPr><w:jc w:val="center"/><w:keepNext/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="{picid}" name="{esc(path.name)}"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="{picid}" name="{esc(path.name)}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>')
    body.append(para(b['caption'],17,color='526B78'));rid+=1;picid+=1
 rels.append('<Relationship Id="rFooter" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>')
 body.append('<w:sectPr><w:footerReference w:type="default" r:id="rFooter"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="850" w:right="880" w:bottom="1050" w:left="880" w:header="400" w:footer="500"/></w:sectPr>')
 document='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>'+''.join(body)+'</w:body></w:document>'
 files={'word/document.xml':document,'word/_rels/document.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(rels)+'</Relationships>','_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rDoc" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>','[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>','word/footer1.xml':'<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'+para('毕业设计阶段汇报 · 2026-10-29 · 证据核验版',16,color='526B78')+'</w:ftr>'}
 with zipfile.ZipFile(O/(name+'.docx'),'w',zipfile.ZIP_DEFLATED) as z:
  for path,data in {**files,**media}.items():z.writestr(path,data)
 print(name,'embedded',len(media))
ss=json.loads((O/'report_content.json').read_text());build(ss,'毕业设计中文阶段汇报报告')
# Reuse lecture parsing from render module logic, preserving supplied Markdown.
sp=[];cur=None;lines=(O/'汇报讲稿与导师问答.md').read_text().splitlines();i=0
while i<len(lines):
 ln=lines[i]
 if ln.startswith('# '):cur={'title':ln[2:],'blocks':[]};sp.append(cur)
 elif cur is not None and ln.startswith('## '):cur['blocks'].append({'type':'h','text':ln[3:]})
 elif cur is not None and ln.startswith('|'):
  table=[]
  while i<len(lines) and lines[i].startswith('|'):table.append([x.strip() for x in lines[i].strip('|').split('|')]);i+=1
  cur['blocks'].append({'type':'table','heads':table[0],'rows':table[2:],'widths':[.33,.67]});continue
 elif cur is not None and ln.strip():cur['blocks'].append({'type':'p','text':ln})
 i+=1
build(sp,'汇报讲稿与导师问答_可编辑')
