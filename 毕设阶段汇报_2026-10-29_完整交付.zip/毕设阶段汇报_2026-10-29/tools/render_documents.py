from pathlib import Path
import json,re,html
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,KeepTogether
from reportlab.lib.utils import ImageReader
O=Path(__file__).resolve().parents[1]
pdfmetrics.registerFont(TTFont('CN','/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf'))
pdfmetrics.registerFont(TTFont('Latin','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
W,H=A4;MW=W-88
styles={
 'p':ParagraphStyle('p',fontName='CN',fontSize=10.3,leading=17,spaceAfter=8,wordWrap='CJK',textColor=colors.HexColor('#263b48')),
 'h':ParagraphStyle('h',fontName='CN',fontSize=12.4,leading=20,spaceBefore=8,spaceAfter=7,textColor=colors.HexColor('#087f8c'),keepWithNext=True),
 'title':ParagraphStyle('title',fontName='CN',fontSize=18,leading=27,spaceAfter=17,textColor=colors.HexColor('#163d52'),keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='CN',fontSize=8.1,leading=12.5,wordWrap='CJK',spaceAfter=0),
 'caption':ParagraphStyle('caption',fontName='CN',fontSize=8.5,leading=13,spaceAfter=9,textColor=colors.HexColor('#526b78'),wordWrap='CJK'),
 'eq':ParagraphStyle('eq',fontName='CN',fontSize=9.6,leading=16,spaceAfter=9,spaceBefore=3,wordWrap='CJK',backColor=colors.HexColor('#edf5f6'),borderPadding=7),
 'code':ParagraphStyle('code',fontName='Latin',fontSize=8,leading=12,wordWrap='CJK',spaceAfter=8,backColor=colors.HexColor('#f2f4f5'),borderPadding=6)
}
def marked(text):
 out=[]
 # Pick font per character run. Chinese font lacks many Latin glyphs.
 for token in re.findall(r'[\x00-\x7f\u00a0-\u024f\u0370-\u03ff\u2000-\u22ff]+|[^\x00-\x7f\u00a0-\u024f\u0370-\u03ff\u2000-\u22ff]+',text):
  f='Latin' if ord(token[0])<0x250 or 0x370<=ord(token[0])<=0x3ff or 0x2000<=ord(token[0])<=0x22ff else 'CN'
  out.append('<font name="'+f+'">'+html.escape(token).replace('\n','<br/>')+'</font>')
 return ''.join(out)
def para(text,style='p'):return Paragraph(marked(text),styles[style])
page_titles=[]
def footer(c,doc):
 c.saveState();c.setStrokeColor(colors.HexColor('#b7cbd3'));c.line(44,40,W-44,40)
 c.setFont('CN',8);c.setFillColor(colors.HexColor('#526b78'));c.drawString(44,27,'毕业设计阶段汇报');c.setFont('Latin',8);c.drawString(130,27,'2026-10-29');c.setFont('CN',8);c.drawString(192,27,'证据核验版');c.setFont('Latin',8);c.drawRightString(W-44,27,str(doc.page));c.restoreState()
def build_pdf(sections,name):
 story=[]
 for i,s in enumerate(sections):
  if i:story.append(PageBreak())
  story.append(para(s['title'],'title'))
  for b in s['blocks']:
   typ=b['type']
   if typ in ('p','h','equation','code'):story.append(para(b['text'],{'equation':'eq'}.get(typ,typ)))
   elif typ=='table':
    content=[[para(str(x),'cell') for x in row] for row in [b['heads']]+b['rows']];weights=b.get('widths') or [1/len(b['heads'])]*len(b['heads']);table=Table(content,colWidths=[MW*x for x in weights],repeatRows=1,hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dcebf0')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f4f8fa'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#9ab7c3')),('LINEBELOW',(0,-1),(-1,-1),.3,colors.HexColor('#c4d4dc'))]));story.extend([table,Spacer(1,10)])
   elif typ=='figure':
    path=O/'figures'/b['file'];iw,ih=ImageReader(str(path)).getSize();scale=min(MW/iw,b.get('height',240)/ih);story.append(KeepTogether([Image(str(path),width=iw*scale,height=ih*scale),Spacer(1,4),para(b['caption'],'caption')]))
 doc=SimpleDocTemplate(str(O/(name+'.pdf')),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=43,bottomMargin=54,title=name,author='毕业设计阶段材料核验与汇报',allowSplitting=1)
 doc.build(story,onFirstPage=footer,onLaterPages=footer)
def export_source(sections,name):
 md=[];ht=['<!DOCTYPE html><html lang="zh-CN"><meta charset="utf-8"><title>'+name+'</title><style>@page{size:A4;margin:20mm}body{font-family:"Noto Sans CJK SC","Droid Sans Fallback",sans-serif;color:#263b48;font-size:11pt;line-height:1.65}h1{font-size:20pt;color:#163d52;page-break-before:always}h1:first-of-type{page-break-before:auto}h2{font-size:14pt;color:#087f8c}table{border-collapse:collapse;width:100%;font-size:9pt;margin:10pt 0}td,th{border:1px solid #c4d4dc;padding:6pt;vertical-align:top}th{background:#dcebf0}img{max-width:100%;max-height:380pt}p{margin:8pt 0}pre{white-space:pre-wrap;font-size:9pt}.caption{font-size:9pt;color:#526b78}</style><body>']
 for s in sections:
  md.append('# '+s['title']);ht.append('<h1>'+html.escape(s['title'])+'</h1>')
  for b in s['blocks']:
   k=b['type']
   if k in ('p','h','equation','code'):
    tx=b['text'];md.append(('## ' if k=='h' else '')+('```bash\n'+tx+'\n```' if k=='code' else tx));tag={'p':'p','h':'h2','equation':'p','code':'pre'}[k];ht.append(f'<{tag}>'+html.escape(tx).replace('\n','<br>')+f'</{tag}>')
   elif k=='table':
    md.append('| '+' | '.join(b['heads'])+' |\n| '+' | '.join(['---']*len(b['heads']))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in b['rows']));ht.append('<table><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in b['heads'])+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in r)+'</tr>' for r in b['rows'])+'</table>')
   elif k=='figure':
    md.append('!['+b['caption']+'](figures/'+b['file']+')');ht.append('<p style="text-align:center"><img src="figures/'+b['file']+'"></p><p class="caption">'+html.escape(b['caption'])+'</p>')
 ht.append('</body></html>');(O/(name+'.md')).write_text('\n\n'.join(md));(O/(name+'.html')).write_text('\n'.join(ht))
if __name__=='__main__':
 ss=json.loads((O/'report_content.json').read_text());build_pdf(ss,'毕业设计中文阶段汇报报告');export_source(ss,'毕业设计中文阶段汇报报告')
 # Parse speech/QA as structured sections, shorter pages for live notes.
 lines=(O/'汇报讲稿与导师问答.md').read_text().splitlines();sp=[];cur=None;i=0
 while i<len(lines):
  ln=lines[i]
  if ln.startswith('# '):
   cur={'title':ln[2:],'blocks':[]};sp.append(cur)
  elif cur is not None and ln.startswith('## '):cur['blocks'].append({'type':'h','text':ln[3:]})
  elif cur is not None and ln.startswith('|'):
   table=[]
   while i<len(lines) and lines[i].startswith('|'):
    table.append([x.strip() for x in lines[i].strip('|').split('|')]);i+=1
   cur['blocks'].append({'type':'table','heads':table[0],'rows':table[2:],'widths':[.33,.67]});continue
  elif cur is not None and ln.strip():cur['blocks'].append({'type':'p','text':ln})
  i+=1
 build_pdf(sp,'汇报讲稿与导师问答');export_source(sp,'汇报讲稿与导师问答_可编辑')
 print('PDF / Markdown / HTML built')
