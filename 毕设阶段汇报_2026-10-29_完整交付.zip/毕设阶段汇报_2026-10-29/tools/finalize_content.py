from pathlib import Path
import json,csv,shutil,hashlib
O=Path(__file__).resolve().parents[1];p=O/'report_content.json';ss=json.loads(p.read_text())
for s in ss:
 for b in s['blocks']:
  if b['type'] in ('p','h'):b['text']=b['text'].replace('LocalPlanner','CandidatePlanner')
  if b['type']=='table':b['rows']=[[str(x).replace('LocalPlanner','CandidatePlanner') for x in r] for r in b['rows']]
# Additional references are a design mapping, never a claim of implementation or published gains.
extra={'title':'附录C｜方案参考论文与实际实现的对应边界','blocks':[
{'type':'p','text':'本次已核对research-files/main目录，V5六图方案Markdown已只读下载，V6方案PDF的Git blob为fbcff00479c3dcd14acd2620c3dd91508c489409。本地留存V6方案第25—26节列明相关论文。本报告只引用其可对应的设计思想，不能把方案的引用清单写成已复现算法。'},
{'type':'table','heads':['来源与版本','本项目可对应思想','尚不能声称'], 'rows':[
['Meng等，A Hierarchical Region-Based Approach for Efficient Multi-Robot Exploration，arXiv:2503.12876v1（2025-03-17）；本次核对作者原始摘要页。','按区域组织探索、降低全局规划频率；本项目采用2m粗区域与异步规划。','RegionGraph对未知区域的完整建模与论文20%收益没有在本系统复现。'],
['URGE，V6本地方案R1；Bi等，IEEE T-RO 42:3028–3047，2026，作者项目页nku-mobfly-robotics.github.io/urge_webpage/。','未知区域协同作为方案背景；当前做共同信息键去重与任务归属。','没有移植URGE完整分布式通信、区域表示或其正式基准；本次未重审论文全文。'],
['IR2，arXiv:2409.04730v3；方案R8；marmotlab/IR2-Multi-Robot-RL-Exploration。','说明学习型多机探索是一条可另立的路线。','当前无IR2策略模型、训练过程、通信约束或权重，不能写为本系统已使用RL。'],
['HPHS / RangeTAP，用户历史路线截图。','候选筛选、层次探索、路径成本分配作为设计启发。','本次证据不足以绑定论文确切版本与全部实现；不列为完整复现成果。']], 'widths':[.42,.29,.29]},
{'type':'p','text':'参考链接：RegionGraph https://arxiv.org/abs/2503.12876v1 ；IR2 https://arxiv.org/abs/2409.04730v3 。历史方案的其他近期论文保留在sources/V6研发方案_本地留存.txt，不在缺少实现对应时扩充“已采用算法”名单。Q-learning期刊网页本次返回Client Challenge，不能记为正文已读取；基本公式的直接证据为本地Q表更新源码。'},
{'type':'p','text':'导航技术说明以冻结配置和Humble源码为准；本次另保存ros-navigation/navigation2/humble/nav2_mppi_controller/README.md原文，校对其为模型预测控制。网页访问状态、文件SHA256和失败响应均保留，避免引用来源不可核实而隐去。'}]}
ss[-1]['title']='附录D｜资料缺口与完整性声明';ss.insert(-1,extra)
p.write_text(json.dumps(ss,ensure_ascii=False,indent=2))
# Duplicate raw paired table for readily auditable statistics.
source=Path('/home/lemuel/Downloads/V5_r029_实验归档与后续方案_2026-10-24/data/36次配对结果与诊断.csv');shutil.copy2(source,O/'data/V5_r028_r029_36次配对结果与诊断.csv')
versions=[['V1','2026-10-13','双车Q-learning+安全覆盖动作','访问格不是SLAM覆盖','已实现/核心测试/运行快照','归档BASELINE与core'],['V2','2026-10-14','共享Q-learning+占据图+前沿辅助','95.0543%;842.5s;seed7','单次功能通过/未统计验收','归档BASELINE与结果'],['V3','2026-10-16至17','双SLAM/Nav2+Q朝向/B0-B4','44:15完成8返航失败21超时','已测试/未全面稳定','phase44_results.csv'],['V4','2026-10-18','单机TF修复/RPP/返航锚点','四组通过/无独立接触计数','有限协议验收通过','VALIDATION_RESULTS.csv'],['V5 r028/r029','2026-10-22至24','单机反馈/足迹/Smac+MPPI','26/36到34/36;效率未同步提高','配对已测/目标未全面通过','36次配对CSV'],['V5 r032','2026-10-24','提速控制基线','冻结e80d5aa90517fece','保留比较基线','r032代码/说明'],['V5 r039','2026-10-27冻结','event_fast+反馈记忆','候选3/3;N04慢12.2%','用户选择冻结/提速验收未通过','564c0e22aed4bfd1'],['V6 P0','2026-10-27','双机启动/单机回归','单机3/3','阶段验收','d8bfff7f80a196ed'],['V6 P1','2026-10-27','双机实际闭环','N04 seed29完成','单次工程验收','c3436527ffa7600a'],['V6 P2父版','2026-10-27至29','联合分配/租约/窄路/安全','N04两起点及专项六门','P2工程验收通过','fab1b03d57fd6b46'],['旧图r001','2026-10-29','队友建图时序修复','94.6328%;双返回但FAILED','覆盖未通过','61b8f00bbe49152f'],['旧图r002','2026-10-29','条件推进/低收益冷却','启动探针超时;无完整任务','未完成整任务','e5848487ceb29f6c'],['旧图r003','2026-10-29','r002在线不变/修启动检查','29/7/13通过','旧图固定组验收','b4c0ee7639e06a23'],['GUI r003','2026-10-29','冻结算法/新GUI生命周期','COMPLETE但原summary审计false','观察完成带审计告警','同174冻结文件']]
with (O/'data/版本证据与状态清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['版本','日期','算法','结果','证据状态','标识或来源']);w.writerows(versions)
# Mark challenge response truthfully.
p=O/'sources/外部技术来源访问记录.json';d=json.loads(p.read_text())
for x in d:
 if x['id']=='q_learning':x['status']='challenge_page_not_article';x['note']='HTTP返回正文是Client Challenge，未读到论文正文。'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
print('final sections',len(ss))
