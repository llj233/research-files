from pathlib import Path
import zipfile,xml.etree.ElementTree as ET
from urllib.parse import urlparse,unquote
O=Path(__file__).resolve().parents[1]
for p in O.glob('*.docx'):
 with zipfile.ZipFile(p) as z:files={n:z.read(n) for n in z.namelist()}
 ns='http://schemas.openxmlformats.org/package/2006/relationships'; rel=ET.fromstring(files['word/_rels/document.xml.rels']);count=0
 for item in rel:
  if item.attrib.get('Type','').endswith('/image') and item.attrib.get('TargetMode')=='External':
   src=Path(unquote(urlparse(item.attrib['Target']).path));assert src.is_relative_to(O)
   name='media/'+src.name;files['word/'+name]=src.read_bytes();item.set('Target',name);del item.attrib['TargetMode'];count+=1
 files['word/_rels/document.xml.rels']=ET.tostring(rel,encoding='utf-8',xml_declaration=True)
 # Office drawing/VML: convert linked images to embedded references.
 doc=files['word/document.xml'].decode();doc=doc.replace('r:link=','r:embed=');files['word/document.xml']=doc.encode()
 types=ET.fromstring(files['[Content_Types].xml']);ctns='http://schemas.openxmlformats.org/package/2006/content-types'
 if count and not any(e.attrib.get('Extension')=='png' for e in types):ET.SubElement(types,'{'+ctns+'}Default',{'Extension':'png','ContentType':'image/png'})
 files['[Content_Types].xml']=ET.tostring(types,encoding='utf-8',xml_declaration=True)
 # Explicit Chinese Word run defaults, ensure editable text instead of raster pages.
 styles=files.get('word/styles.xml',b'').decode();styles=styles.replace('w:eastAsia="Noto Sans CJK SC"','w:eastAsia="Noto Sans CJK SC"');files['word/styles.xml']=styles.encode()
 q=p.with_suffix('.tmp')
 with zipfile.ZipFile(q,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in files.items():z.writestr(n,b)
 q.replace(p);print(p.name,'newly embedded',count,'total images',len([n for n in files if n.startswith('word/media/')]))
