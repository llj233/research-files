# 毕业设计阶段汇报交付说明

日期：2026年10月29日（北京时间）。本次只整理证据与生成文档，没有修改算法、历史记录或启停仿真。

- `毕业设计中文阶段汇报报告.pdf`：26页A4正式中文报告，第一页为阶段摘要，含版本演进、架构、算法、失败诊断、覆盖曲线、建图、实验与下一阶段计划。
- `毕业设计中文阶段汇报报告.docx`：可编辑Word；正文与表格为文字，6张图嵌入包内，可独立发送。
- 同名`.md`、`.html`及`report_content.json`：可编辑排版源；HTML/Markdown图片使用相邻figures目录。
- `汇报讲稿与导师问答.pdf`：5—8分钟汇报参考稿、18问答。另有Markdown、HTML与可编辑Word。
- `data/版本证据与状态清单.csv`、正式逐轮结果与原始评价曲线、V5 36项配对表，方便在答辩现场回查。
- `sources/本地证据索引.json`：原材料路径与SHA256；`代码定位.csv`为函数/类定位与文件哈希；外部访问记录和本地方案文本独立保存。
- `quality/交付质量核验.json`：数值、分母、哈希、PDF与Word完整性核查；页面截图、抽取文本与Word兼容检查副本。
- `tools/`：证据收集、绘图、生成PDF/源文件、Word和核查脚本。主报告的固定内容以report_content.json为准，重新排版不必重新访问算法目录。

## 必须保留的结论边界

当前r003源码b4c0ee7639e06a23在V3旧图的29/7/13三个指定种子全部通过，仅支持旧图回归。当前V6为启发式SLAM驱动协同探索，不是新训练的RL模型，也未验证定位不确定性驱动的严格主动SLAM。V5 r039的N04退化、V3历史失败、r001覆盖未达标与r002启动失败均保留。

GUI seed29有连续物理轨迹审计缺失：主体result为COMPLETE，但原summary的task_success=false保持；暂停后原生独立位置查询单列。该次不是新的正式完整验收，不替代三种子结果，也不列为无条件最佳成绩。

## 重新生成报告

在报告目录执行以下操作仅写报告目录，不启动仿真：

```bash
MPLCONFIGDIR=/tmp/thesis-report-mpl python3 tools/draw_figures.py
python3 tools/render_documents.py
python3 tools/build_docx.py
python3 tools/check_delivery.py
```

依赖本机Python3、ReportLab、Matplotlib、Pillow、DroidSansFallbackFull和NotoSansCJK字体；PDF检查还需要poppler的pdftotext/pdfinfo。源文件可在Word或文本编辑器中修改。需从最初模板重建正文时，再执行write_content.py与finalize_content.py；最终定稿应优先使用已有report_content.json，避免覆盖人工编辑。

全部原始仿真日志体量较大，本包复制关键结果/曲线/参数/证据索引；完整原日志仍在报告列出的隔离运行目录，不声称本包包含全部历史ROS日志或可独立启动所有版本。
