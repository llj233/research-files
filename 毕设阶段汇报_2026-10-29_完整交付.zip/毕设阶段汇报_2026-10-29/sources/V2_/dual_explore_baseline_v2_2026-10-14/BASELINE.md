# Baseline v2：双机器人 Q-learning＋前沿导航辅助地图探索

冻结日期：2026-10-14。**当前实验基线为 v2**。2026-10-13 的 v1 是历史基线，仍独立保存，不覆盖或改写。

## 版本定义

- 两台 TurtleBot3 共用一张表格 Q 表，使用共享奖励；动作是前进、左转、右转。
- 两车激光各自建立局部占据证据，用出生位置与里程计估算位姿对齐，融合到共同栅格。
- 当融合图过去 30 仿真秒新增空闲格少于 30 个时，前沿导航辅助沿已知空闲区规划到未知边界。避障和沿墙脱困也可接管动作；接管动作不训练 Q 表。
- Gazebo SDF 真值只用于计算可达空闲格覆盖率和 95% 自动停止条件；导航和奖励不读真值。
- 这属于**混合式强化学习地图探索**，不是纯 Q-learning 的单独成绩，也不是具备回环检测和漂移校正的 SLAM。

## 固定试验和结果

地图 `room`，种子 7，共享奖励，前沿导航辅助开启，关闭相机订阅；每车从空 Q 表开始。控制间隔 0.5 仿真秒，地图分辨率 0.2 m。输出隔离在 `experiments/long_gui_room_seed7_target95_frontier_v4/`，其中的 `plan.json` 和 `run_config.json` 记录源码、模型、世界文件哈希及运行参数。

| 结果 | 数值 |
|---|---:|
| 达标停止覆盖率 | 95.0543%（8495 / 8937 个真值可达空闲格） |
| 探索仿真时间 | 842.5 秒，1686 步 |
| 实际耗时 | 842.729 秒 |
| 团队累计奖励 | 69.18，共享奖励只计一次 |
| 机器人 1 / 机器人 2 覆盖率 | 65.682% / 48.4391% |

`runs.csv` 是最终表，`reward_coverage.csv` 包含每步奖励－覆盖率曲线，`fused_map.pgm/yaml` 是最终融合图。该结果来自一个地图和一个种子，尚不能作为独立奖励与共享奖励的统计比较。

## 在 ROS 2 Humble 虚拟机复现

```bash
cd ~/single_ros2_prototype
source /opt/ros/humble/setup.bash
colcon build --symlink-install --packages-select dual_explore
source install/setup.bash
DISPLAY=:0 python3 scripts/run_experiments.py --maps room --seeds 7 --groups shared --steps 0 --target-coverage 95 --timeout 0 --gui --frontier-assist --output experiments/reproduce_baseline_v2_room_seed7
```

`--steps 0 --timeout 0` 表示没有步数和实际时间上限，只有达到 95% 才会自动结束。重新运行可能因为 Gazebo 物理调度、传感器时序而与这次结果不逐位相同。选择新的输出目录以免覆盖证据；结果会自动导出 `runs.csv` 和 `reward_coverage.csv`。
