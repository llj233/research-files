# 最终交付

预定V3旧图验证组29/7/13已全部通过，源快照b4c0ee7639e06a23。主报告为优化闭环_最终验收报告.pdf / .md。

在线代码：/home/lemuel/Downloads/V6_P2_V3Map_Regression_2026-10-29/repairs/r003_preflight_clock/src/active_slam_v6/active_slam_v6/

准确入口：

```bash
cd /home/lemuel/Downloads/V6_P2_V3Map_Regression_2026-10-29/repairs/r003_preflight_clock
bash scripts/build_v6.sh
./START_REGRESSION.sh
```

入口重跑物理/启动门再顺序跑29/7/13；每次新建UUID目录，失败立即保留并停止该验证组。不要同时运行其他Gazebo实验。同次双车在同一ROS domain和Gazebo世界中互通，跨次独立路径和网络标识。参数、地图、真值、出生点、安全与成功判据见protocol/V3_REGRESSION.json及每次manifest。

原P2、V3原图、初始回归、r001和r002失败保留。r003相对r002在线源码相同；相对r001的在线差异与完整相对原P2差异均已交付patch。不能把不同版本的最佳结果混合统计。

交付文件：

- V3地图回归_结果汇总.csv：逐轮5次完整任务，含2次历史失败和最终同版本3次成功。
- 全部阶段与失败记录.csv：物理、启动与完整任务台账，包括r002启动失败。
- 逐候选评分与状态审计.csv：454条候选评分/记忆排名/队友重叠/租约及新鲜度。
- 条件推进_目标结果与实际收益.json：5次实际推进链，其中种子13一次低收益目标触发临时冷却。
- V3地图回归_覆盖率曲线.png / 前600秒曲线.png：保留全部失败和长时间等待。
- maps/：所有完整任务原始融合栅格及全画布8倍图；未观测区仍未知。
- 输入参数一致性核验.json：三次输入、参数、模型、导航与物理插件一致，只有种子/运行路径不同。
- FINAL_VERIFICATION.json、最终验证组.json、单元检查.txt：接受证据。

从已保存原始数据重建报告：

```bash
cd /home/lemuel/Downloads/V6_P2_V3Map_Regression_2026-10-29
python3 reports/optimization_closure_2026-10-29/tools/export_all_rounds.py
python3 reports/optimization_closure_2026-10-29/tools/build_closure_report.py
python3 reports/optimization_closure_2026-10-29/tools/export_score_audit.py
python3 reports/optimization_closure_2026-10-29/tools/build_closure_pdf.py
```

仅为该旧地图的小样本功能验证，不声称全部地图泛化。更改算法后须新建副本并重跑受影响组，不改本组已验证源码。
