# 永久停更故障：定位与修复依据

本机系统 tf2/tf2_ros 为 0.25.23，Nav2 1.1.20。独立 GDB 诊断运行在地图 7/策略 11 复现了永久停更：时钟约 406 和 409 秒两次线程快照中，激光回调与 TF 接收线程在同一对锁上相互等待，期间路径和足迹时间戳冻结。完整原始栈见 [evidence/diagnostic_controller_threads.log](evidence/diagnostic_controller_threads.log)，短摘要见 [evidence/thread_excerpt.txt](evidence/thread_excerpt.txt)。这次诊断运行是失败样本，保留在 evidence 及原诊断目录，不算作修复版成功运行。

| 线程 | 当前调用链 | 已持有的锁 | 等待的锁 |
|---|---|---|---|
| 激光/局部代价地图回调 | MessageFilter → Buffer::waitForTransform → BufferCore::addTransformableRequest | timer_to_request_map_mutex_ | transformable_requests_mutex_ |
| TF 接收 | TransformListener → setTransform → testTransformableRequests → tf2_ros 回调 | transformable_requests_mutex_ | timer_to_request_map_mutex_ |

两条线程相互持有对方所需的锁，形成 ABBA 死锁。TF 发布节点仍能正常发布，其他独立节点也能看到新 TF，但被卡住的 Nav2 内部 Buffer 停止推进，导致控制路径和足迹使用旧数据。重置随后等待相关线程清理，所以增加旋转次数、换 frontier 或直接改 DDS 都不能消除这一锁等待。

上述加锁顺序可在上游 [0.25.23 Buffer::waitForTransform](https://github.com/ros2/geometry2/blob/0.25.23/tf2_ros/src/buffer.cpp) 与 BufferCore 源码核对，也与 [Humble 故障 #995](https://github.com/ros2/geometry2/issues/995) 描述和线程栈吻合。

官方 [Humble 修复 #990](https://github.com/ros2/geometry2/pull/990) 在 [tf2 0.25.24](https://github.com/ros2/geometry2/blob/0.25.24/tf2/CHANGELOG.rst) 中发布。它先提取已满足的请求，再在释放请求锁后执行回调，从根本上打断该锁循环。本版本将 tf2/tf2_ros 0.25.24 官方 DEB 解包到 `vendor/root`，只为本次子进程设置动态库路径。系统和旧实验仍使用原安装，`vendor/PACKAGES.json` 锁定包版本及哈希。

为避免只凭日志推断，新增 C++ 程序 `tf_deadlock_regression/callback_reentry`：在变换请求回调里注册新请求。同一个二进制加载系统 0.25.23 时确定性超时，加载本版本 0.25.24 后立即返回通过，记录见 [TF_DEADLOCK_REGRESSION.json](TF_DEADLOCK_REGRESSION.json)。修复版首组还读取了控制器和 SLAM 的实际进程库映射，确认二者加载的是本目录库，而非系统旧库。

此结论针对本次抓到的永久 TF 停更，不将所有未来的障碍受阻或单目标超时都归为这一问题。完整任务验收另见最终实验报告。
