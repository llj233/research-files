# 返航与局部通行修改

TF 死锁修复解决了永久输入停更，但父版 101/501 在探索率 98.30% 后仍返航失败。该次返航探测得到：控制器路径和 TF 新鲜，机器人位于约 (-3.89,-0.95)，前方激光约 0.87 米，导航持续给出角速度而几乎没有平移；最后因总任务预算耗尽失败。这属于 TF 死锁之外的局部通行问题。

本版用 Nav2 Humble 的 RPP 代替 DWB，仍由 Nav2 全局规划器生成路径，前沿模块只决定观测目标。RPP 使用短前视点、曲率调速和开启的碰撞预测来跟随路径，行为树保留有限等待/后退，未添加盲目旋转恢复。这里是整套执行与返航修正，未做 RPP 单因素消融，不能只用本轮结果宣称控制器普遍优于 DWB。

调试中间版曾出现配置错误：最小前视 0.25 米小于探索位置容差 0.35 米。[Humble RPP 源码](https://github.com/ros-navigation/navigation2/blob/humble/nav2_regulated_pure_pursuit_controller/src/regulated_pure_pursuit_controller.cpp) 中的目标朝向判断使用前视点距离，这会过早进入旋转。该次运行有 configuration_abort.json 记录显式配置中止；退出时原始 result.json 为 FAILED/runtime_error，两份证据均保留。当前最小前视为 0.45 米，启动前自动检查它必须大于所有位置容差，测试覆盖错误配置会被拒绝。

返航位置由启动时第一次有效里程计记录固定，保存于 `deployment_odom.json`。每次返航请求使用当时的动态 TF 转成 map 坐标：

`home_in_map = current_map_from_odom.apply(deployment_pose_in_odom)`

因此 SLAM 修正 map→odom 后，不会继续把固定的旧 map 坐标当部署点。返航单独使用 0.20 米 Nav2 目标位置容差；Nav2 成功之后仍检查 odom 中距部署点是否 ≤0.35 米，未通过会记录 `home_verification_failed` 并重新请求。最终位姿和误差进入 `result.json`，轨迹/目标/指令进入 `navigation_health.csv`。

当前 Gazebo 差速驱动未显式设置 `odometry_source`，使用该插件默认的 WORLD=1，它由世界位姿产生里程计，[插件源码](https://github.com/ros-simulation/gazebo_ros_pkgs/blob/ros2/gazebo_plugins/src/gazebo_ros_diff_drive.cpp) 可核对。因此本仿真中的 odom 部署点距离可用作仿真位置误差；本轮没有加入编码器噪声或里程计漂移，不能据此断言真实机器人返航精度相同。

单目标时间由 Nav2 路径长度计算，至少 70、最多 150 秒；总任务预算仍为 700 秒。这解决了父版部分长路径仍有进展却被固定 70 秒取消的问题。它不延长任务总预算，也不降低探索率 >95% 与 ROI 已知率 >90% 的返航门槛。
