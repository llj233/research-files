# V3 主动探索效率实验（隔离分支）

原 `active_slam_v3.launch.py`、`coordinator.py`、`planning.py` 和 V3 历史结果保持原样。优化入口是 `active_slam_opt.launch.py`、`coordinator_opt.py`、`optimization.py` 和 `scripts/run_active_slam_opt.py`。继续使用两个 `slam_toolbox`、公共地图、Nav2、同一部署点及 V2 的共享 Q 表实现；`--reward-mode independent` 仅改变奖励来源，Q 表存储逻辑与 V3 一致。仿真使用已知世界坐标对齐局部地图，真实机器人需单独实现动态 TF 与地图配准。

## 逐级消融

| 组 | 新增行为 |
|---|---|
| B0 | V3 选择与执行语义，添加完整记录 |
| B1 | 限定 Nav2 路径探测候选数量，按可见未知格、实际路径长度、转向、障碍余量和重叠评分；地图占据格未变化时沿用候选缓存 |
| B2 | 失败目标两次后暂时过滤；地图变化、目标持续至少 10 秒且剩余可见未知格低于原估计 40% 时，新目标预评分高 25% 才取消旧目标重规划 |
| B3 | 两机器人对粗区域进行临时贪心分配，另一机器人持有目标的区域会被占用 |
| B4 | 在公共已知空闲格建立 2 米区域连通图，优先剩余候选多、连接性好、路径较短的区域，失败区暂时降权 |

区域图只是房间/走廊的可解释近似，不是语义房间分割。B2 的预比较使用直线距离，真正派发目标前仍通过 Nav2 路径确认。信息收益是射线可见未知格数代理，并非精确信息增益。算法不读取真值地图；真值只进入评估器。

## 单次运行

先在终端加载 ROS 与本工作区：

```bash
source /opt/ros/humble/setup.bash
source /home/lemuel/single_ros2_prototype/install/setup.bash
cd /home/lemuel/single_ros2_prototype
python3 scripts/run_active_slam_opt.py --world worlds/fast/room.world --seed 7 --reward-mode shared --ablation B4 --stage pilot --gui true --max-wall-seconds 900
```

每次运行的目录为 `experiments/active_slam_opt/{pilot|formal}/{map}/seed_{seed}/{shared|independent}/B{0..4}/{UTC_ID}`，其中 `manifest.json` 冻结地图、配置、源码 SHA、域 ID 和 Gazebo 端口。不会复用已有运行目录。两种 95% 门槛仍须同时达到，然后两车回原部署点；`result.json` 分别保存探索结束时间和含返程的任务时间。

每个目录含 `metrics.csv`、`profile.csv`（约五秒采样，两条覆盖率曲线、路径、重复路程、停滞及连续静止超过 10 秒的事件数、规划/融合耗时及仿真与墙上时间比）、`decisions.csv`（路径探测、分数、选中目标、Nav2 结果和该时段全队新增已知格）、`opt_summary.csv`、`result.json`、`q_table.json`、融合地图 PGM/YAML 及统一配色的 8 倍 PNG。`decisions.csv` 的 `frontiers` 是前沿格数量，`clusters` 是聚类数量；`visible_unknown_proxy` 仍是代理收益。连续静止是卡住代理，不代表已检测到碰撞。没有到达门槛的超时运行保留在比较表中。

## 正式配对实验

```bash
python3 scripts/run_v3_opt_matrix.py --worlds room corridor loop --seeds 7 13 29 --reward-modes shared independent --ablations B0 B1 B2 B3 B4 --max-wall-seconds 900 --gui false
```

脚本逐个运行，避免 Gazebo/ROS 资源竞争。每结束一组会更新 `experiments/active_slam_opt/paired_results.csv` 和 `coverage_curves.csv`。也可用 `--collect-only` 重建汇总。默认矩阵共 90 组，最长 22.5 小时加启动开销，正式结论须等它完成并检查地图质量、Nav2 失败率与覆盖率曲线。低帧率先看 `profile.csv` 的仿真/墙上比和规划/融合耗时；Gazebo、SLAM、Nav2 的独立 CPU profile 仍需另采。

## 持续监控

`python3 scripts/monitor_v3_opt.py --interval 30` 每 30 秒更新 `experiments/active_slam_opt/monitor_status.json` 和 `monitor_alerts.csv`，标记运行失败、指标长时间不更新、超出预算、单车连续停滞和覆盖率平台。`--once` 可立即刷新一次。监控程序只读各组数据，不改变运行中的算法或结果。若正式矩阵被中断，重启矩阵命令会跳过已有 `result.json` 的组；中断且没有结果的目录需要先检查并移出正式树，避免重复组污染统计。被隔离的试验记录保存在 `experiments/active_slam_opt/aborted_launcher/`。
