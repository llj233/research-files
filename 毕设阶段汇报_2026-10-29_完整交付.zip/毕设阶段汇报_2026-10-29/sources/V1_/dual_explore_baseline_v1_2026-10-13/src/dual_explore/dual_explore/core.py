"""算法层：把传感器压成状态，计算团队奖励，并更新共享 Q 表。

本文件不调用 ROS；阅读顺序建议从 ACTIONS、state_from_sensors、
SharedLearner 开始，再看 scan_bins、safe_motion 和 EscapeNavigator。
"""
import json
import math
import random

# 三个离散动作，元组依次为 (直线速度 m/s, 角速度 rad/s)。
# 索引 0=前进、1=左转、2=右转；Q 表的三个数也按此顺序排列。
ACTIONS = ((0.18, 0.0), (0.0, 0.9), (0.0, -0.9))


def image_signature(data, width, height, step, encoding):
    """取图像中的 9 个像素，得到很粗的红/绿/蓝颜色特征。"""
    # 只处理每像素三个通道的 rgb8/bgr8；step 是图像每行的字节数。
    if encoding not in ('rgb8', 'bgr8') or width < 1 or height < 1 or step < width * 3:
        return None
    # 图像数据不完整时不读取，避免数组越界。
    if len(data) < step * height:
        return None
    samples = []
    # 在高、宽的 1/4、1/2、3/4 处各取 3 个点，总共 9 点。
    for y in (height // 4, height // 2, 3 * height // 4):
        for x in (width // 4, width // 2, 3 * width // 4):
            # 把二维像素坐标换成一维字节偏移。
            i = y * step + x * 3
            r, g, b = data[i:i + 3]
            if encoding == 'bgr8':
                # bgr8 的首尾通道颠倒，统一转换成 RGB 顺序。
                r, b = b, r
            # 若某种颜色强于另外两种的 1.3 倍，则该颜色记 1。
            samples.append((int(r > g * 1.3 and r > b * 1.3),
                            int(g > r * 1.3 and g > b * 1.3),
                            int(b > r * 1.3 and b > g * 1.3)))
    # 三种颜色分别计数，再除以 3；这不是目标识别或视觉建图。
    return tuple(sum(s[k] for s in samples) // 3 for k in range(3))


def scan_bins(ranges, range_min, range_max):
    """把 0～2π 的 360° 激光按方向汇总成 7 个距离。"""
    # Gazebo 中这款激光的第 0 束朝前；无效扫描不参与控制。
    if not ranges or not math.isfinite(range_max) or range_max <= range_min:
        return None
    n = len(ranges)

    def sector(lo, hi):
        # 在指定角度区间中取最近的有效障碍；正无穷表示无遮挡。
        vals = [float(v) if math.isfinite(v) else range_max for v in ranges[lo:hi]
                if (math.isfinite(v) and range_min <= v <= range_max) or math.isinf(v) and v > 0]
        return min(vals) if vals else range_max

    # 前四个距离为宽扇区，保持既有 Q 学习状态的含义。
    front = min(sector(0, max(1, n // 8)), sector(7 * n // 8, n))
    left = sector(n // 8, 3 * n // 8)
    right = sector(5 * n // 8, 7 * n // 8)
    rear = sector(3 * n // 8, 5 * n // 8)
    # 后三个是较窄扇区：正前方 ±15°、左侧/右侧各约 ±15°。
    # 窄前方可看到门洞中间，避免门框落入宽前方扇区后误判为死路。
    ahead = min(sector(0, max(1, n // 24)), sector(23 * n // 24, n))
    side_left = sector(5 * n // 24, 7 * n // 24)
    side_right = sector(17 * n // 24, 19 * n // 24)
    # 顺序在 node.py 中也会用到，不能随意交换。
    return front, left, right, rear, ahead, side_left, side_right


def safe_motion(scan, action, turn_direction=0):
    """安全层：必要时覆盖学习动作；返回速度、持续转向方向和模式。"""
    _, left, right, rear, front, _, _ = scan
    # 已在转向时沿用原方向；刚遇障碍时转向空旷的一侧。
    direction = turn_direction or (1 if left >= right else -1)
    # 正前方太近且后方有空间，先小幅倒车。
    if front < 0.28 and rear > 0.42:
        return (-0.08, 0.0), direction, 'back'
    # 0.55 m 内开始避障；进入转向后直到 0.80 m 才退出，防止来回摆动。
    if front < 0.55 or (turn_direction and front < 0.80):
        return (0.0, direction * 0.9), direction, 'turn'
    # 安全时才执行 Q 表选出的前进/左转/右转。
    return ACTIONS[action], 0, 'learn'


class EscapeNavigator:
    """局部脱困：先找墙、沿墙走，遇到侧面开口便转进去。"""

    def __init__(self, hand=-1):
        self.hand = hand  # -1 沿右手侧墙；+1 沿左手侧墙。
        self.phase = 'seek_wall'
        self.wall_seen = False  # 是否曾在选定的一侧看到墙。
        self.turn_ticks = 0  # 看见侧面开口后，剩余的转向控制周期数。
        self.cross_ticks = 0  # 转入开口后，剩余的穿门前进周期数。

    def step(self, scan):
        """根据最新激光返回本周期的 (直线速度, 角速度) 与日志模式。"""
        _, _, _, rear, front, left, right = scan
        side = right if self.hand == -1 else left
        # 紧贴障碍时只在后方足够空旷的情况下后退。
        if front < 0.28 and rear > 0.42:
            return (-0.08, 0.0), 'escape_back'
        # 已发现侧面开口：连续转约 3 个 0.5 秒周期，朝开口对齐。
        if self.turn_ticks:
            self.turn_ticks -= 1
            return (0.0, self.hand * 0.9), 'escape_gap_turn'
        # 转好方向后短距离前进，尽量越过门槛；前方受阻则取消。
        if self.cross_ticks:
            if front < 0.50:
                self.cross_ticks = 0
                self.phase = 'follow_wall'
            else:
                self.cross_ticks -= 1
                return (0.16, 0.0), 'escape_cross'
        # 起初还没遇到墙，就向前寻找一面可跟随的墙。
        if self.phase == 'seek_wall' and front >= 0.70:
            return (0.18, 0.0), 'escape_seek'
        self.phase = 'follow_wall'
        # 墙挡住前进方向时，朝远离所跟随墙的一侧转。
        if front < 0.50:
            return (0.0, -self.hand * 0.9), 'escape_wall_turn'
        # 先看见近墙，之后侧面忽然变空，才把它认作门洞。
        if side < 0.90:
            self.wall_seen = True
        if self.wall_seen and side > 1.20 and front > 0.65:
            self.wall_seen = False
            self.turn_ticks = 2
            self.cross_ticks = 12
            return (0.0, self.hand * 0.9), 'escape_gap_turn'
        # 没贴上墙时先继续向前，不在空地里绕小圈。
        if not self.wall_seen:
            return (0.16, 0.0), 'escape_seek'
        # 靠近墙就往外修正，远离墙就往里修正，目标侧距约 0.55 m。
        correction = max(-0.35, min(0.35, 0.8 * (side - 0.55)))
        return (0.15, self.hand * correction), 'escape_follow'


def state_from_sensors(scan, image_sig):
    """构造 Q 表的 6 维离散状态：前/左/右距离档位 + 3 个颜色量。"""
    front, left, right = scan[:3]
    # 把连续的米数压缩为 0=近、1=中、2=远。
    def q(v): return 0 if v < 0.35 else 1 if v < 0.8 else 2
    # 图像不支持时颜色默认为 0；这里没有位姿或地图变量。
    return (q(front), q(left), q(right), *(image_sig or (0, 0, 0)))


class SharedLearner:
    """两台机器人共用的一张表格 Q 策略与团队探索统计。"""

    def __init__(self, alpha=0.2, gamma=0.9, epsilon=0.2, seed=7):
        # alpha=学习率；gamma=未来奖励折扣；epsilon=随机探索概率。
        self.alpha, self.gamma, self.epsilon = alpha, gamma, epsilon
        self.rng = random.Random(seed)
        self.q = {}  # 状态元组 -> [前进价值, 左转价值, 右转价值]。
        self.visited = set()  # 两台机器人共用的 0.5 m 网格集合。
        self.images = set()  # 两台机器人共用的视觉颜色签名集合。

    def choose(self, state, train=True):
        # epsilon-greedy：训练时以 20% 概率试一个随机动作。
        if train and self.rng.random() < self.epsilon:
            return self.rng.randrange(len(ACTIONS))
        # 未见过的状态按三个动作价值全为 0 处理。
        values = self.q.get(tuple(state), [0.0] * len(ACTIONS))
        return max(range(len(ACTIONS)), key=lambda i: values[i])

    def learn(self, state, action, reward, next_state):
        # 表格 Q-learning：更新一次“上一状态、上一动作”的价值。
        old = self.q.setdefault(tuple(state), [0.0] * len(ACTIONS))
        future = max(self.q.get(tuple(next_state), [0.0] * len(ACTIONS)))
        # Q(s,a) <- Q(s,a) + alpha * [reward + gamma*max Q(s',.) - Q(s,a)]。
        old[action] += self.alpha * (reward + self.gamma * future - old[action])

    def reward(self, x, y, image_sig, front):
        # 单机器人情况复用双机器人团队奖励的实现。
        return self.reward_batch(((x, y, image_sig, front),))

    def reward_batch(self, observations):
        """一轮把所有机器人观测合并为一个团队奖励。"""
        reward = -0.01
        for x, y, image_sig, front in observations:
            # 里程计近似的世界坐标按 0.5 m 划格；它不是占据地图。
            cell = (math.floor(x / 0.5), math.floor(y / 0.5))
            if cell not in self.visited:
                self.visited.add(cell)
                reward += 1.0
            # 首次遇见一个颜色签名，团队加 0.1。
            if image_sig is not None and image_sig not in self.images:
                self.images.add(image_sig)
                reward += 0.1
            # 任一机器人过于靠近障碍，都扣在同一个团队奖励上。
            if front < 0.25:
                reward -= 1.0
        return reward

    def save(self, path):
        # JSON 只保存 Q 表；visited/images 下次启动会重新计数。
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'q': {','.join(map(str, k)): v for k, v in self.q.items()}}, f)

    def load(self, path):
        # JSON 对象的键必须是字符串，因此加载时把逗号分隔键还原为整数元组。
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        self.q = {tuple(map(int, k.split(','))): v for k, v in data['q'].items()}
